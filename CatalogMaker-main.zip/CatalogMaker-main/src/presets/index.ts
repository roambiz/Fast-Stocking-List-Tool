import { a4StandardSeries } from './a4-standard';
import { a3StandardSeries } from './a3-standard';
import { PresetSeries, LayoutPreset } from './types';

export const allSeries: PresetSeries[] = [
  a4StandardSeries,
  a3StandardSeries,
];

export const getLayoutById = (id: string): LayoutPreset | undefined => {
  for (const series of allSeries) {
    const layout = series.layouts.find(l => l.id === id);
    if (layout) return layout;
  }
  return undefined;
};

export const getSeriesByLayoutId = (layoutId: string): PresetSeries | undefined => {
  return allSeries.find(s => s.layouts.some(l => l.id === layoutId));
};

export const getDefaultLayout = (): LayoutPreset => {
  return a4StandardSeries.layouts[0];
};

export const getDefaultLayoutForPageSize = (pageSize: 'A4' | 'A3'): LayoutPreset => {
  const series = allSeries.find(s => s.pageSize === pageSize);
  return series?.layouts[0] ?? a4StandardSeries.layouts[0];
};

export const getDefaultLayoutForSeries = (seriesId: string): LayoutPreset => {
  const series = allSeries.find(s => s.id === seriesId);
  return series?.layouts[0] ?? a4StandardSeries.layouts[0];
};
