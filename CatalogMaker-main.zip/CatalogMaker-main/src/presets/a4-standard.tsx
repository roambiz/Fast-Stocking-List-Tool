import React from 'react';
import { PresetSeries, LayoutPreset } from './types';
import { Item, GlobalConfig, getBadgeColorClass } from '../types';
import clsx from 'clsx';
import i18n from '../i18n';

const renderA4V1Item = (item: Item, isSelected: boolean, onClick: (e: React.MouseEvent, item: Item) => void, globalConfig?: GlobalConfig) => {
  const isBlue = globalConfig?.theme !== 'black';
  const baseClasses = clsx(
    "relative bg-white flex flex-col overflow-hidden cursor-pointer transition-all h-full w-full min-h-0 min-w-0 rounded-xl border",
    isSelected ? (isBlue ? "ring-2 ring-blue-500 border-transparent shadow-md" : "ring-2 ring-zinc-800 border-transparent shadow-md") : (isBlue ? "border-gray-200 hover:border-blue-300 hover:shadow-md" : "border-gray-200 hover:border-zinc-400 hover:shadow-md")
  );

  const imageClass = clsx(
    "w-full h-full",
    globalConfig?.imageFit === 'contain' ? "object-contain" : "object-cover",
    globalConfig?.imagePadding && "p-2"
  );

  return (
    <div key={item.id} onClick={(e) => onClick(e, item)} className={baseClasses}>
      {item.image ? (
        <img src={item.image} alt="Product" className={imageClass} />
      ) : (
        <div className="w-full h-full flex items-center justify-center text-gray-400 text-xs">{i18n.t('common.noImage')}</div>
      )}
      {item.badge && (
        <div className={clsx("absolute top-2.5 left-2.5 text-white text-[10px] font-bold px-3 py-1 rounded-full shadow-sm whitespace-nowrap overflow-hidden max-w-full", getBadgeColorClass(item))}>
          {item.badge}
        </div>
      )}
      {(item.number?.trim() || item.price?.trim()) ? (
        <div className="absolute bottom-2.5 left-1/2 -translate-x-1/2 bg-white/90 backdrop-blur-sm px-3 py-1.5 flex justify-center items-center gap-2 rounded-full shadow-sm border border-gray-100 whitespace-nowrap">
          <span className="text-xs font-bold text-gray-900">{item.number}</span>
          {item.price && <span className="text-xs font-bold text-[#C99A0B]">{item.price}</span>}
        </div>
      ) : null}
    </div>
  );
};

const renderA4V2Item = (item: Item, isSelected: boolean, onClick: (e: React.MouseEvent, item: Item) => void, globalConfig?: GlobalConfig) => {
  const isBlue = globalConfig?.theme !== 'black';
  const baseClasses = clsx(
    "relative bg-white flex flex-col overflow-hidden cursor-pointer transition-all h-full w-full min-h-0 min-w-0 rounded-xl border",
    isSelected ? (isBlue ? "ring-2 ring-blue-500 border-transparent shadow-md" : "ring-2 ring-zinc-800 border-transparent shadow-md") : (isBlue ? "border-gray-200 hover:border-blue-300 hover:shadow-md" : "border-gray-200 hover:border-zinc-400 hover:shadow-md")
  );

  const imageClass = clsx(
    "w-full h-full",
    globalConfig?.imageFit === 'contain' ? "object-contain" : "object-cover",
    globalConfig?.imagePadding && "p-2"
  );

  return (
    <div key={item.id} onClick={(e) => onClick(e, item)} className={baseClasses}>
      {item.image ? (
        <img src={item.image} alt="Product" className={imageClass} />
      ) : (
        <div className="w-full h-full flex items-center justify-center text-gray-400 text-xs">{i18n.t('common.noImage')}</div>
      )}
      {item.badge && (
        <div className={clsx("absolute top-2.5 right-2.5 text-white text-[10px] font-bold px-2 py-1 rounded shadow-sm whitespace-nowrap overflow-hidden max-w-full", getBadgeColorClass(item))}>
          {item.badge}
        </div>
      )}
      {(item.number?.trim() || item.price?.trim()) ? (
        <div className="absolute bottom-2.5 left-2.5 bg-white/90 backdrop-blur-sm px-2 py-1 flex justify-center items-center gap-2 rounded shadow-sm border border-gray-100 whitespace-nowrap">
          <span className="text-xs font-bold text-gray-900">{item.number}</span>
          {item.price && <span className="text-xs font-bold text-[#C99A0B]">{item.price}</span>}
        </div>
      ) : null}
    </div>
  );
};

const renderA4V3Item = (item: Item, isSelected: boolean, onClick: (e: React.MouseEvent, item: Item) => void, globalConfig?: GlobalConfig) => {
  const isBlue = globalConfig?.theme !== 'black';
  const baseClasses = clsx(
    "relative bg-white flex flex-col overflow-hidden cursor-pointer transition-all h-full w-full min-h-0 min-w-0 rounded-xl border p-2",
    isSelected ? (isBlue ? "ring-2 ring-blue-500 border-transparent shadow-md" : "ring-2 ring-zinc-800 border-transparent shadow-md") : (isBlue ? "border-gray-200 hover:border-blue-300 hover:shadow-md" : "border-gray-200 hover:border-zinc-400 hover:shadow-md")
  );

  const imageClass = clsx(
    "w-full h-full rounded-lg",
    globalConfig?.imageFit === 'contain' ? "object-contain" : "object-cover",
    globalConfig?.imagePadding && "p-2"
  );

  return (
    <div key={item.id} onClick={(e) => onClick(e, item)} className={baseClasses}>
      <div className="flex-1 relative overflow-hidden rounded-lg mb-2">
        {item.image ? (
          <img src={item.image} alt="Product" className={imageClass} />
        ) : (
          <div className="w-full h-full flex items-center justify-center text-gray-400 text-xs">{i18n.t('common.noImage')}</div>
        )}
        {item.badge && (
          <div className={clsx("absolute top-2 right-2 text-white text-[10px] font-bold px-2 py-1 rounded-md shadow-sm whitespace-nowrap overflow-hidden max-w-[85%]", getBadgeColorClass(item, true))}>
            {item.badge}
          </div>
        )}
      </div>
      {(item.number?.trim() || item.price?.trim()) ? (
        <div className="flex flex-nowrap justify-between items-center gap-1 px-1 min-w-0">
          <span className="text-sm font-bold text-gray-900 truncate shrink-0 max-w-[50%]">{item.number}</span>
          {item.price && <span className="text-sm font-bold text-[#C99A0B] truncate shrink-0 max-w-[50%]">{item.price}</span>}
        </div>
      ) : null}
    </div>
  );
};

export const a4StandardSeries: PresetSeries = {
  id: 'a4-standard',
  name: 'A4 - 标准目录',
  nameKey: 'sidebar.seriesA4Standard',
  pageSize: 'A4',
  layouts: [
    {
      id: 'a4-v1',
      name: '卡片风格',
      description: '16个产品，胶囊标签',
      nameKey: 'layouts.a4V1Name',
      descriptionKey: 'layouts.a4V1Desc',
      pageSize: 'A4',
      maxItems: 16,
      gridClassName: 'grid-cols-4 grid-rows-4 gap-4',
      renderItem: renderA4V1Item,
    },
    {
      id: 'a4-v2',
      name: '便签风格',
      description: '16个产品，方块标签',
      nameKey: 'layouts.a4V2Name',
      descriptionKey: 'layouts.a4V2Desc',
      pageSize: 'A4',
      maxItems: 16,
      gridClassName: 'grid-cols-4 grid-rows-4 gap-4',
      renderItem: renderA4V2Item,
    },
    {
      id: 'a4-v3',
      name: '相片风格',
      description: '16个产品，白色边框',
      nameKey: 'layouts.a4V3Name',
      descriptionKey: 'layouts.a4V3Desc',
      pageSize: 'A4',
      maxItems: 16,
      gridClassName: 'grid-cols-4 grid-rows-4 gap-4',
      renderItem: renderA4V3Item,
    },
  ],
};
