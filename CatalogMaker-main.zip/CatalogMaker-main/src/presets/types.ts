import React from 'react';
import { Item, Page, PageSize, GlobalConfig } from '../types';

export interface LayoutPreset {
  id: string;
  name: string;
  description: string;
  nameKey?: string;
  descriptionKey?: string;
  pageSize: PageSize;
  maxItems: number;
  gridClassName: string;
  renderItem: (item: Item, isSelected: boolean, onClick: (e: React.MouseEvent, item: Item) => void, globalConfig?: GlobalConfig) => React.ReactNode;
  renderPageExtra?: (page: Page) => React.ReactNode;
}

export interface PresetSeries {
  id: string;
  name: string;
  nameKey?: string;
  pageSize: PageSize;
  layouts: LayoutPreset[];
}
