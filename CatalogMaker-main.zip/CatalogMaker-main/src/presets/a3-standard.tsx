import React from 'react';
import { PresetSeries, LayoutPreset } from './types';
import { Item, GlobalConfig, getBadgeColorClass } from '../types';
import clsx from 'clsx';
import i18n from '../i18n';

/** A3 角标 - 斜切角标：紧凑型，少占内容区 */
const A3CornerBadge: React.FC<{ text: string; colorClass: string }> = ({ text, colorClass }) => {
  return (
    <div className="absolute top-0 right-0 pointer-events-none z-10">
      <div
        className={clsx(
          'pl-3 pr-2 pt-1.5 pb-3 text-white text-[10px] font-bold',
          'whitespace-nowrap overflow-hidden text-ellipsis shadow-sm',
          colorClass
        )}
        style={{
          clipPath: 'polygon(0 0, 100% 0, 100% 100%, 32% 100%, 0 32%)',
        }}
      >
        {text}
      </div>
    </div>
  );
};

const renderA3V1Item = (item: Item, isSelected: boolean, onClick: (e: React.MouseEvent, item: Item) => void, globalConfig?: GlobalConfig) => {
  const isBlue = globalConfig?.theme !== 'black';
  const baseClasses = clsx(
    "relative bg-white flex flex-row overflow-hidden cursor-pointer transition-all h-full w-full min-h-0 min-w-0 rounded-xl border",
    isSelected ? (isBlue ? "ring-2 ring-blue-500 border-transparent shadow-md" : "ring-2 ring-zinc-800 border-transparent shadow-md") : (isBlue ? "border-gray-200 hover:border-blue-300 hover:shadow-md" : "border-gray-200 hover:border-zinc-400 hover:shadow-md")
  );

  const imageClass = clsx(
    "w-full h-full",
    globalConfig?.imageFit === 'contain' ? "object-contain" : "object-cover",
    globalConfig?.imagePadding && "p-2"
  );

  return (
    <div key={item.id} onClick={(e) => onClick(e, item)} className={baseClasses}>
      {/* 60% 图片 */}
      <div className={clsx("w-[60%] h-full relative shrink-0 border-r border-gray-100", globalConfig?.imageFit !== 'contain' && "bg-gray-50")}>
        {item.image ? (
          <img src={item.image} alt="Product" className={imageClass} />
        ) : (
          <div className="w-full h-full flex items-center justify-center text-gray-400 text-xs">{i18n.t('common.noImage')}</div>
        )}
        {item.badge && <A3CornerBadge text={item.badge} colorClass={getBadgeColorClass(item)} />}
      </div>
      {/* 40% 文字：编号、多行详情、价格 */}
      <div className="w-[40%] p-3 flex flex-col justify-between bg-white min-w-0 shrink-0">
        <div className="min-w-0 min-h-0 flex flex-col gap-1">
          <div className="text-sm font-bold text-gray-900 whitespace-nowrap truncate">{item.number}</div>
          {item.description && (
            <div className="text-xs text-gray-500 leading-relaxed whitespace-pre-wrap break-words overflow-y-auto flex-1 min-h-0">
              {item.description}
            </div>
          )}
        </div>
        {item.price && <div className="text-sm font-bold text-[#C99A0B] whitespace-nowrap truncate shrink-0">{item.price}</div>}
      </div>
    </div>
  );
};

/** 解析参数行：支持 "参数名: 值" 或 "参数名：值" 格式 */
const parseParamLine = (line: string): { label: string; value: string } | null => {
  const sep = line.includes('：') ? '：' : line.includes(':') ? ':' : null;
  if (!sep) return null;
  const idx = line.indexOf(sep);
  const label = line.slice(0, idx).trim();
  const value = line.slice(idx + 1).trim();
  return label && value ? { label, value } : null;
};

const renderA3V2Item = (item: Item, isSelected: boolean, onClick: (e: React.MouseEvent, item: Item) => void, globalConfig?: GlobalConfig) => {
  const isBlue = globalConfig?.theme !== 'black';
  const baseClasses = clsx(
    "relative bg-white flex flex-row overflow-hidden cursor-pointer transition-all h-full w-full min-h-0 min-w-0 rounded-xl border",
    isSelected ? (isBlue ? "ring-2 ring-blue-500 border-transparent shadow-md" : "ring-2 ring-zinc-800 border-transparent shadow-md") : (isBlue ? "border-gray-200 hover:border-blue-300 hover:shadow-md" : "border-gray-200 hover:border-zinc-400 hover:shadow-md")
  );

  const imageClass = clsx(
    "w-full h-full",
    globalConfig?.imageFit === 'contain' ? "object-contain" : "object-cover",
    globalConfig?.imagePadding && "p-2"
  );

  const paramLines = item.description
    ? item.description.split('\n').filter(Boolean).map(parseParamLine)
    : [];

  return (
    <div key={item.id} onClick={(e) => onClick(e, item)} className={baseClasses}>
      {/* 55% 图片 */}
      <div className={clsx("w-[55%] h-full relative shrink-0 border-r border-gray-100", globalConfig?.imageFit !== 'contain' && "bg-gray-50")}>
        {item.image ? (
          <img src={item.image} alt="Product" className={imageClass} />
        ) : (
          <div className="w-full h-full flex items-center justify-center text-gray-400 text-xs">{i18n.t('common.noImage')}</div>
        )}
        {item.badge && <A3CornerBadge text={item.badge} colorClass={getBadgeColorClass(item)} />}
      </div>
      {/* 45% 参数区：白底，编号、参数表、价格 */}
      <div className="w-[45%] p-2.5 flex flex-col justify-between bg-white min-w-0 shrink-0">
        <div className="min-w-0 min-h-0 flex flex-col gap-1">
          <div className="text-sm font-bold text-gray-900 whitespace-nowrap truncate">{item.number}</div>
          {paramLines.length > 0 ? (
            <div className="flex flex-col overflow-y-auto flex-1 min-h-0 text-[11px] divide-y divide-gray-200">
              {paramLines.map((p, i) => p && (
                <div key={i} className="flex gap-2 py-0.5 min-w-0 first:pt-0">
                  <span className="text-gray-500 shrink-0 w-14 truncate" title={p.label}>{p.label}:</span>
                  <span className="text-gray-800 flex-1 min-w-0 truncate" title={p.value}>{p.value}</span>
                </div>
              ))}
            </div>
          ) : item.description ? (
            <div className="text-[11px] text-gray-500 leading-relaxed whitespace-pre-wrap break-words overflow-y-auto flex-1 min-h-0">
              {item.description}
            </div>
          ) : null}
        </div>
        {item.price && <div className="text-sm font-bold text-[#C99A0B] whitespace-nowrap truncate shrink-0">{item.price}</div>}
      </div>
    </div>
  );
};

const renderA3V3Item = (item: Item, isSelected: boolean, onClick: (e: React.MouseEvent, item: Item) => void, globalConfig?: GlobalConfig) => {
  const isBlue = globalConfig?.theme !== 'black';
  const baseClasses = clsx(
    "relative bg-white flex flex-col overflow-hidden cursor-pointer transition-all h-full w-full min-h-0 min-w-0 rounded-xl border",
    isSelected ? (isBlue ? "ring-2 ring-blue-500 border-transparent shadow-md" : "ring-2 ring-zinc-800 border-transparent shadow-md") : (isBlue ? "border-gray-200 hover:border-blue-300 hover:shadow-md" : "border-gray-200 hover:border-zinc-400 hover:shadow-md")
  );

  const imageClass = clsx(
    "w-full h-full",
    globalConfig?.imageFit === 'contain' ? "object-contain" : "object-cover",
    globalConfig?.imagePadding && "p-2"
  );

  return (
    <div key={item.id} onClick={(e) => onClick(e, item)} className={baseClasses}>
      {/* 上方 80% 图片 */}
      <div className={clsx("flex-[0.8] w-full min-h-0 relative shrink-0 border-b border-gray-100", globalConfig?.imageFit !== 'contain' && "bg-gray-50")}>
        {item.image ? (
          <img src={item.image} alt="Product" className={imageClass} />
        ) : (
          <div className="w-full h-full flex items-center justify-center text-gray-400 text-xs">{i18n.t('common.noImage')}</div>
        )}
        {/* 图片左下角价格标签 */}
        {item.price && (
          <div className="absolute bottom-2 left-2 px-2.5 py-1 bg-[#C99A0B] text-white text-xs font-bold rounded shadow-sm truncate max-w-[85%] pointer-events-none">
            {item.price}
          </div>
        )}
        {item.badge && <A3CornerBadge text={item.badge} colorClass={getBadgeColorClass(item)} />}
      </div>
      {/* 下方 20% 文本：左 27% 编号，右 73% 两段文本 */}
      <div className="flex-[0.2] flex flex-row min-h-0 shrink-0 border-t border-gray-100">
        <div className="w-[27%] p-2 flex flex-col justify-center shrink-0 border-r border-gray-100">
          <div className="text-[11px] font-bold text-gray-900 whitespace-nowrap truncate">{item.number}</div>
        </div>
        <div className="w-[73%] p-2 flex flex-col justify-center gap-0.5 min-w-0 shrink-0">
          {(() => {
            const segments = (item.description || '').split('\n').filter(Boolean);
            return (
              <>
                {segments[0] && <div className="text-[11px] text-gray-600 truncate leading-tight">{segments[0]}</div>}
                {segments[1] && <div className="text-[11px] text-gray-500 truncate leading-tight">{segments[1]}</div>}
              </>
            );
          })()}
        </div>
      </div>
    </div>
  );
};

export const a3StandardSeries: PresetSeries = {
  id: 'a3-standard',
  name: 'A3 - 横版目录',
  nameKey: 'sidebar.seriesA3Standard',
  pageSize: 'A3',
  layouts: [
    {
      id: 'a3-v1',
      name: '卖点风格',
      description: '16个产品，带详情，突出卖点。',
      nameKey: 'layouts.a3V1Name',
      descriptionKey: 'layouts.a3V1Desc',
      pageSize: 'A3',
      maxItems: 16,
      gridClassName: 'grid-cols-4 grid-rows-4 gap-6',
      renderItem: renderA3V1Item,
    },
    {
      id: 'a3-v2',
      name: '参数风格',
      description: '16个产品，带详情，突出参数。',
      nameKey: 'layouts.a3V2Name',
      descriptionKey: 'layouts.a3V2Desc',
      pageSize: 'A3',
      maxItems: 16,
      gridClassName: 'grid-cols-4 grid-rows-4 gap-6',
      renderItem: renderA3V2Item,
    },
    {
      id: 'a3-v3',
      name: '亮点风格',
      description: '16个产品，带详情，突出亮点。',
      nameKey: 'layouts.a3V3Name',
      descriptionKey: 'layouts.a3V3Desc',
      pageSize: 'A3',
      maxItems: 16,
      gridClassName: 'grid-cols-4 grid-rows-4 gap-6',
      renderItem: renderA3V3Item,
    },
  ],
};
