import type { Page, GlobalConfig } from '../types';

/** 导出 schema 版本；globalConfig 在 v1.2+ 可含可选字段 pdfMetadata* */
export const SCHEMA_VERSION = 1;

export interface ProjectExport {
  schemaVersion: number;
  exportedAt: string;
  projectName: string;
  pages: Page[];
  globalConfig: GlobalConfig;
  defaultSeriesId: string;
  theme: 'blue' | 'black';
}

export interface SettingsExport {
  schemaVersion: number;
  exportedAt: string;
  globalConfig: GlobalConfig;
  defaultSeriesId: string;
  theme: 'blue' | 'black';
}

export function isValidProjectExport(data: unknown): data is ProjectExport {
  if (!data || typeof data !== 'object') return false;
  const d = data as Record<string, unknown>;
  return (
    typeof d.schemaVersion === 'number' &&
    typeof d.exportedAt === 'string' &&
    (typeof d.projectName === 'string' || d.projectName == null) &&
    Array.isArray(d.pages) &&
    d.globalConfig != null &&
    typeof d.defaultSeriesId === 'string' &&
    (d.theme === 'blue' || d.theme === 'black')
  );
}

export function isValidSettingsExport(data: unknown): data is SettingsExport {
  if (!data || typeof data !== 'object') return false;
  const d = data as Record<string, unknown>;
  return (
    typeof d.schemaVersion === 'number' &&
    typeof d.exportedAt === 'string' &&
    d.globalConfig != null &&
    typeof d.defaultSeriesId === 'string' &&
    (d.theme === 'blue' || d.theme === 'black')
  );
}
