export type PageSize = 'A4' | 'A3';

export type ItemType = 'product' | 'subtitle';

export type BadgeColor = 'blue' | 'red' | 'green' | 'black';

export const BADGE_COLOR_CLASSES: Record<BadgeColor, string> = {
  blue: 'bg-blue-700',       // #1d4ed8 商务
  red: 'bg-red-700',         // #b91c1c 促销/热销
  green: 'bg-emerald-700',   // #047857 新品/有货
  black: 'bg-neutral-950',    // 限量/尊享
};

export const BADGE_COLOR_CLASSES_60: Record<BadgeColor, string> = {
  blue: 'bg-blue-700/60',
  red: 'bg-red-700/60',
  green: 'bg-emerald-700/60',
  black: 'bg-neutral-950/60',
};

export function getBadgeColorClass(item: { badgeColor?: string }, opacity60?: boolean): string {
  const c = item.badgeColor === 'purple' ? 'black' : (item.badgeColor || 'blue');
  const map = opacity60 ? BADGE_COLOR_CLASSES_60 : BADGE_COLOR_CLASSES;
  return map[c as BadgeColor] ?? (opacity60 ? BADGE_COLOR_CLASSES_60.blue : BADGE_COLOR_CLASSES.blue);
}

export interface Item {
  id: string;
  type: ItemType;
  image?: string;
  /** 原始图片 dataURL，用于「恢复原图」；上传或批量添加时设置 */
  imageOriginal?: string;
  title?: string;
  description?: string;
  badge?: string;
  badgeColor?: BadgeColor;
  number?: string;
  price?: string;
}

export type HtmlContentSlotIndex = 0 | 1 | 2;

export interface Page {
  id: string;
  layoutId: string;
  pageSize: PageSize;
  items: Item[];
  pageSubtitles: string[];
  type?: 'standard' | 'cover-block';
  htmlContent?: string;
  htmlContentSlots?: [string, string, string];
  htmlContentActiveSlot?: HtmlContentSlotIndex;
  headerSubtitle?: string;
  imageFit?: 'cover' | 'contain';
  imagePadding?: boolean;
  pageNumber?: string;
}

export interface GlobalConfig {
  header: string;
  footer: string;
  website: string;
  email?: string;
  whatsapp?: string;
  startNumber: number;
  prefix: string;
  showEmptySlots: boolean;
  logo?: string;
  imagePadding: boolean;
  autoNumbering: boolean;
  imageFit?: 'cover' | 'contain';
  theme?: 'blue' | 'black';
  headerFooterStyle?: 'standard' | 'fashion' | 'brand';
  /** 开启文档和图片压缩，影响 PDF、ZIP 页图、单页 JPG 导出；默认 true，关闭时为无损模式 */
  pdfCompressionEnabled?: boolean;
  /** JPEG 质量：0.97 标准，0.88 极致压缩（关闭压缩时无效） */
  pdfJpegQuality?: number;
  /** PDF 流压缩效率：'FAST' 标准，'SLOW' 极致（关闭压缩时无效） */
  pdfStreamCompression?: 'FAST' | 'SLOW';
  /** 为导出 PDF 写入文档属性（Title/Subject/Author/Keywords）；默认 false 时仅写 Creator/Producer */
  pdfMetadataInjectionEnabled?: boolean;
  pdfMetadataTitle?: string;
  pdfMetadataSubject?: string;
  pdfMetadataAuthor?: string;
  pdfMetadataKeywords?: string;
}
