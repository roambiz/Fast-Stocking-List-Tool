/**
 * 图片旋转工具：将 dataURL 旋转 90° 并烘焙到位图。
 * 使用 Canvas 实现，保证导出 PDF/JPG 方向一致。
 * 保守方案：使用较高 JPEG 质量 (0.95) 减少画质损失。
 */

const JPEG_QUALITY = 0.95;

function loadImageFromDataUrl(dataUrl: string): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => resolve(img);
    img.onerror = () => reject(new Error('Failed to load image'));
    img.src = dataUrl;
  });
}

function getOutputFormat(dataUrl: string): 'image/jpeg' | 'image/png' {
  if (dataUrl.startsWith('data:image/png')) {
    return 'image/png';
  }
  return 'image/jpeg';
}

/**
 * 将 dataURL 图片旋转 90 度。
 * @param dataUrl 原始图片 dataURL
 * @param direction 'left' 逆时针 90°，'right' 顺时针 90°
 * @returns 旋转后的 dataURL，失败时返回原 dataUrl
 */
export async function rotateImage(
  dataUrl: string,
  direction: 'left' | 'right'
): Promise<string> {
  const img = await loadImageFromDataUrl(dataUrl);
  const canvas = document.createElement('canvas');
  const ctx = canvas.getContext('2d');
  if (!ctx) {
    return dataUrl;
  }

  const angle = direction === 'left' ? -90 * (Math.PI / 180) : 90 * (Math.PI / 180);

  if (direction === 'left') {
    canvas.width = img.height;
    canvas.height = img.width;
  } else {
    canvas.width = img.height;
    canvas.height = img.width;
  }

  ctx.translate(canvas.width / 2, canvas.height / 2);
  ctx.rotate(angle);
  ctx.drawImage(img, -img.width / 2, -img.height / 2, img.width, img.height);
  ctx.setTransform(1, 0, 0, 1, 0, 0);

  const format = getOutputFormat(dataUrl);
  if (format === 'image/png') {
    return canvas.toDataURL('image/png');
  }
  return canvas.toDataURL('image/jpeg', JPEG_QUALITY);
}
