const MAX_SIDE = 256;

export async function compressAndCropLogoToBase64(file: File): Promise<string> {
  const img = await loadImage(file);
  const size = Math.min(img.width, img.height);
  const canvas = document.createElement('canvas');
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext('2d');
  if (!ctx) {
    return fallbackToDataUrl(file);
  }
  const srcSize = Math.min(img.width, img.height);
  const sx = (img.width - srcSize) / 2;
  const sy = (img.height - srcSize) / 2;
  ctx.drawImage(img, sx, sy, srcSize, srcSize, 0, 0, size, size);
  const outputSize = Math.min(size, MAX_SIDE);
  if (outputSize < size) {
    const scaled = document.createElement('canvas');
    scaled.width = outputSize;
    scaled.height = outputSize;
    const scaledCtx = scaled.getContext('2d');
    if (scaledCtx) {
      scaledCtx.drawImage(canvas, 0, 0, size, size, 0, 0, outputSize, outputSize);
      return scaled.toDataURL('image/png');
    }
  }
  return canvas.toDataURL('image/png');
}

function loadImage(file: File): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const url = URL.createObjectURL(file);
    const img = new Image();
    img.onload = () => {
      URL.revokeObjectURL(url);
      resolve(img);
    };
    img.onerror = () => {
      URL.revokeObjectURL(url);
      reject(new Error('Failed to load image'));
    };
    img.src = url;
  });
}

function fallbackToDataUrl(file: File): Promise<string> {
  return readFileAsDataURL(file);
}

/**
 * 将 File 读取为 Data URL 字符串。
 * 供组件统一使用，避免重复实现。
 */
export function readFileAsDataURL(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result as string);
    reader.onerror = () => reject(new Error('Failed to read file'));
    reader.readAsDataURL(file);
  });
}
