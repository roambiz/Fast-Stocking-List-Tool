/**
 * 简单格式化 HTML：压缩空白后按标签缩进，便于阅读与编辑。
 */
export function formatHtmlSimple(html: string): string {
  if (!html.trim()) return html;
  let result = '';
  let indent = 0;
  const raw = html.replace(/>\s+</g, '><').trim();
  let i = 0;
  const len = raw.length;
  while (i < len) {
    if (raw.slice(i, i + 2) === '</') {
      const closeEnd = raw.indexOf('>', i);
      if (closeEnd === -1) break;
      indent = Math.max(0, indent - 1);
      result += '\n' + '  '.repeat(indent) + raw.slice(i, closeEnd + 1);
      i = closeEnd + 1;
    } else if (raw[i] === '<' && raw[i + 1] !== '/') {
      const tagEnd = raw.indexOf('>', i);
      if (tagEnd === -1) break;
      const tag = raw.slice(i, tagEnd + 1);
      const isSelfClose = /<\w+[^>]*\/\s*>/.test(tag) || ['br', 'img', 'hr'].some((n) => tag.startsWith(`<${n}`));
      result += '\n' + '  '.repeat(indent) + tag;
      if (!isSelfClose) indent++;
      i = tagEnd + 1;
    } else {
      const nextTag = raw.indexOf('<', i);
      if (nextTag === -1) {
        result += raw.slice(i).trim();
        break;
      }
      const text = raw.slice(i, nextTag).trim();
      if (text) result += text;
      i = nextTag;
    }
  }
  return result.trimStart();
}
