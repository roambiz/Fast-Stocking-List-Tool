import type { ProjectExport, SettingsExport } from '../schema/projectSchema';
import { SCHEMA_VERSION } from '../schema/projectSchema';

export function buildSettingsExport(
  globalConfig: SettingsExport['globalConfig'],
  defaultSeriesId: string,
  theme: 'blue' | 'black'
): SettingsExport {
  return {
    schemaVersion: SCHEMA_VERSION,
    exportedAt: new Date().toISOString(),
    globalConfig,
    defaultSeriesId,
    theme,
  };
}

export function buildProjectExport(
  projectName: string,
  pages: ProjectExport['pages'],
  globalConfig: ProjectExport['globalConfig'],
  defaultSeriesId: string,
  theme: 'blue' | 'black'
): ProjectExport {
  return {
    schemaVersion: SCHEMA_VERSION,
    exportedAt: new Date().toISOString(),
    projectName,
    pages,
    globalConfig,
    defaultSeriesId,
    theme,
  };
}

export function downloadJson(data: object, filename: string) {
  const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  setTimeout(() => URL.revokeObjectURL(url), 100);
}
