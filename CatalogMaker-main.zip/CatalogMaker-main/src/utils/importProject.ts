import { v4 as uuidv4 } from 'uuid';
import { useStore } from '../store';
import i18n from '../i18n';
import {
  isValidProjectExport,
  isValidSettingsExport,
  type ProjectExport,
  type SettingsExport,
} from '../schema/projectSchema';
import { getLayoutById, getDefaultLayoutForSeries, getSeriesByLayoutId } from '../presets';
import type { Page } from '../types';
import { normalizeCoverBlockType, COVER_LAYOUT_ID, processCoverHtmlForImport } from './pageUtils';

const VALID_HEADER_FOOTER_STYLES = ['standard', 'fashion', 'brand'] as const;

function migrateGlobalConfig(cfg: Record<string, unknown>): Record<string, unknown> {
  const m = { ...cfg };
  if (m.pdfJpegQuality == null && m.pdfCompress != null) {
    m.pdfJpegQuality = m.pdfCompress ? 0.88 : 0.97;
    delete m.pdfCompress;
  }
  if (m.pdfStreamCompression == null) {
    m.pdfStreamCompression = 'FAST';
  }
  if (m.pdfCompressionEnabled == null && m.pdfLossless != null) {
    m.pdfCompressionEnabled = !m.pdfLossless;
    delete m.pdfLossless;
  }
  if (m.headerFooterStyle != null && !VALID_HEADER_FOOTER_STYLES.includes(m.headerFooterStyle as (typeof VALID_HEADER_FOOTER_STYLES)[number])) {
    m.headerFooterStyle = 'standard';
  }
  const inj = m.pdfMetadataInjectionEnabled;
  if (typeof inj === 'string') {
    m.pdfMetadataInjectionEnabled = inj === 'true' || inj === '1';
  } else if (inj != null && typeof inj !== 'boolean') {
    m.pdfMetadataInjectionEnabled = false;
  }
  const metaStrKeys = ['pdfMetadataTitle', 'pdfMetadataSubject', 'pdfMetadataAuthor', 'pdfMetadataKeywords'] as const;
  for (const key of metaStrKeys) {
    const v = m[key];
    if (v != null && typeof v !== 'string') {
      m[key] = '';
    }
  }
  return m;
}

export function importSettings(data: unknown): string | null {
  if (!isValidSettingsExport(data)) {
    return 'importExport.importSettingsInvalid';
  }
  const store = useStore.getState();
  const payload = data as SettingsExport;
  store.updateGlobalConfig(migrateGlobalConfig(payload.globalConfig as unknown as Record<string, unknown>) as unknown as typeof payload.globalConfig);
  store.setDefaultSeriesId(payload.defaultSeriesId);
  store.setTheme(payload.theme);
  return null;
}

export function importProject(data: unknown): string | null {
  if (!isValidProjectExport(data)) {
    return 'importExport.importProjectInvalid';
  }
  const payload = data as ProjectExport;
  const store = useStore.getState();

  const targetLayout = getDefaultLayoutForSeries(payload.defaultSeriesId);
  const targetSeriesId = payload.defaultSeriesId;

  let coverHtmlTruncated = false;
  const pages: Page[] = payload.pages.map((p) => {
    const normalizedType = normalizeCoverBlockType(p.type) ?? (p.layoutId === COVER_LAYOUT_ID ? 'cover-block' : undefined);
    if (normalizedType != null) {
      const hasSlots = p.htmlContentSlots != null && Array.isArray(p.htmlContentSlots) && p.htmlContentSlots.length === 3;
      let slots: [string, string, string];
      if (hasSlots) {
        const [s0, s1, s2] = p.htmlContentSlots;
        const r0 = processCoverHtmlForImport(s0 ?? '');
        const r1 = processCoverHtmlForImport(s1 ?? '');
        const r2 = processCoverHtmlForImport(s2 ?? '');
        if (r0.wasTruncated || r1.wasTruncated || r2.wasTruncated) coverHtmlTruncated = true;
        slots = [r0.html, r1.html, r2.html];
      } else {
        const rawHtml = p.htmlContent ?? '';
        const { html: processedHtml, wasTruncated } = processCoverHtmlForImport(rawHtml);
        if (wasTruncated) coverHtmlTruncated = true;
        slots = [processedHtml, '', ''];
      }
      const activeSlot = (p.htmlContentActiveSlot === 0 || p.htmlContentActiveSlot === 1 || p.htmlContentActiveSlot === 2)
        ? p.htmlContentActiveSlot
        : 0;
      return {
        ...p,
        type: 'cover-block' as const,
        layoutId: COVER_LAYOUT_ID,
        pageSize: targetLayout.pageSize,
        items: p.items ?? [],
        pageSubtitles: p.pageSubtitles ?? [],
        htmlContent: slots[0],
        htmlContentSlots: slots,
        htmlContentActiveSlot: activeSlot,
      };
    }
    const pageSeries = getSeriesByLayoutId(p.layoutId);
    const sameSeries = pageSeries?.id === targetSeriesId;
    const layoutId = sameSeries && getLayoutById(p.layoutId) ? p.layoutId : targetLayout.id;
    const pageSize = targetLayout.pageSize;
    return {
      ...p,
      layoutId,
      pageSize,
      items: p.items ?? [],
      pageSubtitles: p.pageSubtitles ?? ['Subtitle 1', 'Subtitle 2'],
    };
  });

  store.updateGlobalConfig(migrateGlobalConfig(payload.globalConfig as unknown as Record<string, unknown>) as unknown as typeof payload.globalConfig);
  store.setDefaultSeriesId(payload.defaultSeriesId);
  store.setTheme(payload.theme);
  store.setProjectName(payload.projectName ?? 'Untitled Catalog');
  store.setSelectedItem(null);
  store.setActivePage(pages[0]?.id ?? null);
  if (coverHtmlTruncated) {
    store.showToast(i18n.t('importExport.coverHtmlTruncatedOnImport'), 'warning');
  }

  const fallbackLayout = getDefaultLayoutForSeries(payload.defaultSeriesId);
  useStore.setState({
    pages:
      pages.length > 0
        ? pages
        : [
            {
              id: uuidv4(),
              layoutId: fallbackLayout.id,
              pageSize: fallbackLayout.pageSize,
              items: [],
              pageSubtitles: ['Subtitle 1', 'Subtitle 2'],
            },
          ],
  });

  return null;
}
