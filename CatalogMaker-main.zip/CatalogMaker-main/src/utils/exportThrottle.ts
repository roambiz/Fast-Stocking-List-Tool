/**
 * 导出功能防滥用：限频机制
 * 降低爬虫与自动化工具批量导出对服务器的消耗
 */

const STORAGE_KEY = 'catalogmaker:export_timestamps';
const WINDOW_MS = 10 * 60 * 1000; // 10 分钟
const MAX_COUNT = 15; // 每窗口内最多允许的导出次数（PDF/ZIP 等重型导出）

function getTimestamps(): number[] {
  try {
    const raw = sessionStorage.getItem(STORAGE_KEY);
    if (raw == null) return [];
    const arr = JSON.parse(raw);
    return Array.isArray(arr) ? arr : [];
  } catch {
    return [];
  }
}

function saveTimestamps(list: number[]): void {
  try {
    sessionStorage.setItem(STORAGE_KEY, JSON.stringify(list));
  } catch {
    // ignore
  }
}

/**
 * 检查是否允许本次导出。
 * 若允许，会记录一次；若超出限制，返回 false。
 */
export function checkAndRecordExport(): boolean {
  const now = Date.now();
  const list = getTimestamps();
  const windowStart = now - WINDOW_MS;
  const recent = list.filter((t) => t > windowStart);

  if (recent.length >= MAX_COUNT) {
    return false;
  }

  recent.push(now);
  saveTimestamps(recent);
  return true;
}
