import type { jsPDF } from 'jspdf';
import type { GlobalConfig } from '../types';
import { APP_VERSION } from '../version';
import { isValidEmailFormat } from './emailFormat';

/**
 * jsPDF 的 TypeScript DocumentProperties 未声明 producer，但 setProperties 运行时可接受。
 * 部分阅读器仍可能显示库自带的 Producer（如 jsPDF 版本）；无稳定、公开的覆盖方式则保持现状。
 */
function setDocProperties(pdf: jsPDF, props: Record<string, string>): void {
  (pdf as jsPDF & { setProperties(p: Record<string, string>): void }).setProperties(props);
}

export const PDF_METADATA_CREATOR = 'https://roambiz.com/';

export const PDF_METADATA_LIMITS = {
  title: 32,
  subject: 128,
  author: 32,
  keywords: 512,
} as const;

function localDateYmd(): string {
  const d = new Date();
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${y}-${m}-${day}`;
}

/**
 * 导出用净化：trim、换行转空格、可选压空白、截断。不写回 store。
 */
export function sanitizePdfMetadataString(raw: string | undefined, maxLen: number): string {
  if (raw == null) {
    return '';
  }
  let s = String(raw).replace(/\r\n/g, '\n').replace(/\r/g, '\n').replace(/\n/g, ' ');
  s = s.trim();
  s = s.replace(/\s+/g, ' ');
  if (s.length > maxLen) {
    s = s.slice(0, maxLen);
  }
  return s;
}

function defaultPdfTitle(): string {
  return `Product Catalog ${localDateYmd()}`;
}

/**
 * 将净化后的元数据写入 PDF。标题空则用默认日期标题；作者空且邮箱合法则用邮箱；主题/关键词空则不注入。
 * 故意不用下载文件名作标题：用户很少改文件名，易变成无意义默认名。
 */
export function applyPdfDocumentMetadata(pdf: jsPDF, globalConfig: GlobalConfig): void {
  const producer = `CatalogMaker ${APP_VERSION}`;
  const injectionOn = globalConfig.pdfMetadataInjectionEnabled === true;

  if (!injectionOn) {
    setDocProperties(pdf, {
      creator: PDF_METADATA_CREATOR,
      producer,
    });
    return;
  }

  const L = PDF_METADATA_LIMITS;
  const titleSan = sanitizePdfMetadataString(globalConfig.pdfMetadataTitle, L.title);
  const subjectSan = sanitizePdfMetadataString(globalConfig.pdfMetadataSubject, L.subject);
  const authorSan = sanitizePdfMetadataString(globalConfig.pdfMetadataAuthor, L.author);
  const keywordsSan = sanitizePdfMetadataString(globalConfig.pdfMetadataKeywords, L.keywords);

  const titleFinal = titleSan.length > 0 ? titleSan : defaultPdfTitle();

  let authorFinal: string | undefined;
  if (authorSan.length > 0) {
    authorFinal = authorSan;
  } else {
    const emailRaw = globalConfig.email ?? '';
    if (isValidEmailFormat(emailRaw)) {
      authorFinal = emailRaw.trim();
    }
  }

  const props: Record<string, string> = {
    title: titleFinal,
    creator: PDF_METADATA_CREATOR,
    producer,
  };

  if (subjectSan.length > 0) {
    props.subject = subjectSan;
  }
  if (authorFinal != null && authorFinal.length > 0) {
    props.author = authorFinal;
  }
  if (keywordsSan.length > 0) {
    props.keywords = keywordsSan;
  }

  setDocProperties(pdf, props);
}
