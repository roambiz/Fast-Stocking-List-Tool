/**
 * PDF 页脚链接工具：校验 href 语法、计算链接注解坐标
 */

export function isPdfLinkValid(href: string): boolean {
  if (!href || href === '#') return false;
  const h = href.trim();
  return (
    h.startsWith('https://') ||
    h.startsWith('http://') ||
    h.startsWith('mailto:')
  );
}

export interface FooterLinkAnnotation {
  url: string;
  x: number;
  y: number;
  w: number;
  h: number;
}

/**
 * 获取页脚链接的 PDF 坐标注解。
 * 需在 transform = 'none' 状态下调用，确保与 toJpeg 捕获布局一致。
 */
export function getFooterLinkAnnotations(
  el: HTMLElement,
  pdfWidthMm: number,
  pdfHeightMm: number
): FooterLinkAnnotation[] {
  const elRect = el.getBoundingClientRect();
  const footerLinks = el.querySelectorAll('a[href]');
  const result: FooterLinkAnnotation[] = [];

  footerLinks.forEach((anchor) => {
    const a = anchor as HTMLAnchorElement;
    const url = a.href;
    if (!isPdfLinkValid(url)) return;

    const linkRect = (a as HTMLElement).getBoundingClientRect();
    const scaleX = pdfWidthMm / elRect.width;
    const scaleY = pdfHeightMm / elRect.height;

    const x = (linkRect.left - elRect.left) * scaleX;
    const y = (linkRect.top - elRect.top) * scaleY;
    const w = linkRect.width * scaleX;
    const h = linkRect.height * scaleY;

    result.push({ url, x, y, w, h });
  });

  return result;
}
