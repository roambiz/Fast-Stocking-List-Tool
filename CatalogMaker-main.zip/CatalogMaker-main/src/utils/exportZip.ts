import JSZip from 'jszip';
import * as htmlToImage from 'html-to-image';
import {
  buildSettingsExport,
  buildProjectExport,
} from './exportProject';
import { getPixelRatio } from './exportImageConfig';
import { useStore } from '../store';
import i18n from '../i18n';

export async function exportAsZip(
  projectName: string,
  onProgress?: (message: string) => void,
  onError?: (message: string) => void
): Promise<void> {
  const store = useStore.getState();
  const { pages, globalConfig, defaultSeriesId, theme } = store;
  const compressionEnabled = globalConfig.pdfCompressionEnabled ?? true;
  const pixelRatio = getPixelRatio(compressionEnabled);

  const zip = new JSZip();

  const settings = buildSettingsExport(globalConfig, defaultSeriesId, theme);
  const project = buildProjectExport(projectName, pages, globalConfig, defaultSeriesId, theme);

  zip.file('settings.json', JSON.stringify(settings, null, 2));
  zip.file('project.json', JSON.stringify(project, null, 2));

  const pageElements = document.querySelectorAll('.pdf-page');
  const initialPageCount = pages.length;
  if (pageElements.length === 0 || pageElements.length !== initialPageCount) {
    const msg = pageElements.length === 0 ? i18n.t('topNav.noPagesToExport') : i18n.t('topNav.exportSyncError');
    onError?.(msg);
    throw new Error(msg);
  }

  await new Promise((r) => requestAnimationFrame(() => requestAnimationFrame(r)));

  for (let i = 0; i < pageElements.length; i++) {
    const freshPages = useStore.getState().pages;
    if (freshPages.length !== initialPageCount) {
      const msg = i18n.t('topNav.exportSyncError');
      onError?.(msg);
      throw new Error(msg);
    }
    onProgress?.(`Capturing page ${i + 1}/${pageElements.length}...`);
    const el = pageElements[i] as HTMLElement;
    const originalTransform = el.style.transform;
    const originalBoxShadow = el.style.boxShadow;
    el.style.transform = 'none';
    el.style.boxShadow = 'none';

    const captureOptions = {
      pixelRatio,
      backgroundColor: '#ffffff',
      cacheBust: true,
      style: { transform: 'none', boxShadow: 'none' },
    };
    let dataUrl: string;
    let ext: string;
    let dataPrefix: string;
    if (compressionEnabled) {
      const jpegQuality = globalConfig.pdfJpegQuality ?? 0.97;
      dataUrl = await htmlToImage.toJpeg(el, { ...captureOptions, quality: jpegQuality });
      ext = 'jpg';
      dataPrefix = 'data:image/jpeg;base64,';
    } else {
      dataUrl = await htmlToImage.toPng(el, captureOptions);
      ext = 'png';
      dataPrefix = 'data:image/png;base64,';
    }

    el.style.transform = originalTransform;
    el.style.boxShadow = originalBoxShadow;

    const base64 = dataUrl.startsWith(dataPrefix) ? dataUrl.slice(dataPrefix.length) : dataUrl.replace(/^data:image\/[^;]+;base64,/, '');
    zip.file(`page_${i + 1}.${ext}`, base64, { base64: true });
  }

  onProgress?.('Creating ZIP...');
  const blob = await zip.generateAsync({ type: 'blob' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = `${projectName || 'catalog'}_export.zip`;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  setTimeout(() => URL.revokeObjectURL(url), 100);
}
