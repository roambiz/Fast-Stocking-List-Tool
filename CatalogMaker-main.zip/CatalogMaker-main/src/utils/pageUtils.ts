import DOMPurify from 'dompurify';
import type { Page, Item } from '../types';

export const COVER_LAYOUT_ID = 'cover-layout';

export const HTML_CONTENT_MAX_LENGTH = 50 * 1024;

const COVER_HTML_ALLOWED_TAGS = ['div', 'p', 'span', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'a', 'img', 'strong', 'em', 'br', 'ul', 'ol', 'li'];
const COVER_HTML_ALLOWED_ATTR = ['href', 'src', 'alt', 'style', 'target', 'rel'];

export function sanitizeCoverHtml(html: string): string {
  return DOMPurify.sanitize(html, { ALLOWED_TAGS: COVER_HTML_ALLOWED_TAGS, ALLOWED_ATTR: COVER_HTML_ALLOWED_ATTR });
}

export function processCoverHtmlForImport(html: string): { html: string; wasTruncated: boolean } {
  const sanitized = sanitizeCoverHtml(html);
  if (sanitized.length <= HTML_CONTENT_MAX_LENGTH) {
    return { html: sanitized, wasTruncated: false };
  }
  return { html: sanitized.slice(0, HTML_CONTENT_MAX_LENGTH), wasTruncated: true };
}

export const COVER_BLOCK_TYPE = 'cover-block' as const;

const LEGACY_COVER_TYPES = ['cover', 'back-cover', 'poster', 'cover-block-front', 'cover-block-back', 'cover-block-poster'];

export function normalizeCoverBlockType(type: string | undefined): string | undefined {
  if (type == null) return undefined;
  if (LEGACY_COVER_TYPES.includes(type)) return COVER_BLOCK_TYPE;
  if (type === COVER_BLOCK_TYPE) return COVER_BLOCK_TYPE;
  return undefined;
}

export function isCoverBlockPage(page: { type?: string }): boolean {
  return page.type === COVER_BLOCK_TYPE;
}

const DEFAULT_COVER_HTML = `<div style="display: flex; flex-direction: column; align-items: center; justify-content: center; height: 100%; font-family: sans-serif; background-color: #f8fafc;">
  <h1 style="font-size: 4rem; font-weight: bold; color: #0f172a; margin-bottom: 1rem; text-align: center;">202X NEW PRODUCT CATALOGUE</h1>
  <p style="font-size: 1.5rem; color: #64748b;">Latest Collection</p>
</div>`;

export function getDefaultCoverBlockHtml(): string {
  return DEFAULT_COVER_HTML;
}

export function getCoverHtmlSlots(page: Page): [string, string, string] {
  if (page.htmlContentSlots != null) {
    return page.htmlContentSlots;
  }
  const slot0 = page.htmlContent ?? '';
  return [slot0, '', ''];
}

export function getCoverActiveSlot(page: Page): 0 | 1 | 2 {
  const slot = page.htmlContentActiveSlot;
  if (slot === 0 || slot === 1 || slot === 2) return slot;
  return 0;
}

export function getCoverCurrentHtml(page: Page): string {
  const slots = getCoverHtmlSlots(page);
  const idx = getCoverActiveSlot(page);
  return slots[idx] ?? '';
}

export function findItemInPages(pages: Page[], itemId: string | null): Item | null {
  if (itemId == null) return null;
  for (const page of pages) {
    const item = page.items.find((i) => i.id === itemId);
    if (item) return item;
  }
  return null;
}
