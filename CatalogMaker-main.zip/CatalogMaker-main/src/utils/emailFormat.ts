/**
 * 与 Sidebar 联系邮箱校验一致，供 PDF 作者回退等复用。
 */
const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

export function isValidEmailFormat(value: string): boolean {
  const s = value.trim();
  if (s.length === 0) {
    return false;
  }
  return EMAIL_RE.test(s);
}
