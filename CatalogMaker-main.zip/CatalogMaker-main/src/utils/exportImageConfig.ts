/**
 * 导出图片（PDF/ZIP/JPG）的采样与格式配置
 * - 启用压缩：pixelRatio 2.5，JPEG
 * - 关闭压缩：pixelRatio 3，PNG（无损，更清晰）
 */

/** 启用压缩时的采样比例 */
export const PIXEL_RATIO_COMPRESSED = 2.5;

/** 关闭压缩时的采样比例（配合 PNG 无损导出） */
export const PIXEL_RATIO_UNCOMPRESSED = 3;

/** @deprecated 使用 getPixelRatio 或上述常量 */
export const PIXEL_RATIO = PIXEL_RATIO_COMPRESSED;

export function getPixelRatio(compressionEnabled: boolean): number {
  return compressionEnabled ? PIXEL_RATIO_COMPRESSED : PIXEL_RATIO_UNCOMPRESSED;
}
