import packageJson from '../package.json';

/** 与 package.json version 同步，供 PDF Producer 等展示 */
export const APP_VERSION = packageJson.version;
