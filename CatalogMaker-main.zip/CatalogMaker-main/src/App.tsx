import React, { useEffect } from "react";
import { useTranslation } from "react-i18next";
import { Loader2 } from "lucide-react";
import { TopNav } from "./components/TopNav";
import { Sidebar } from "./components/Sidebar";
import { MainCanvas } from "./components/MainCanvas";
import { Filmstrip } from "./components/Filmstrip";
import { CellEditor } from "./components/CellEditor";
import { Toast } from "./components/Toast";
import { Alert } from "./components/Alert";
import { ConfirmDialog } from "./components/ConfirmDialog";
import { useStore } from "./store";

export default function App() {
  const { t } = useTranslation();
  const { pages, activePageId, setActivePage, previewMode, isExporting } = useStore();

  useEffect(() => {
    if (pages.length > 0 && !activePageId) {
      setActivePage(pages[0].id);
    }
  }, [pages, activePageId, setActivePage]);

  return (
    <div className="h-screen w-full flex flex-col bg-slate-200 overflow-hidden">
      <Alert />
      <ConfirmDialog />
      <Toast />
      {isExporting && (
        <div
          className="fixed inset-0 z-[9998] flex items-center justify-center bg-black/40 backdrop-blur-[2px]"
          aria-live="assertive"
          role="status"
          aria-label={t('common.exportingOverlay')}
        >
          <div className="flex flex-col items-center gap-3 bg-white px-8 py-6 rounded-xl shadow-xl">
            <Loader2 size={28} className="animate-spin text-blue-600" />
            <p className="text-gray-800 font-medium">{t('common.exportingOverlay')}</p>
          </div>
        </div>
      )}
      <TopNav />
      <div className="flex-1 flex overflow-hidden">
        <Sidebar />
        <div className="flex-1 flex flex-col min-w-0">
          <MainCanvas />
          <Filmstrip />
        </div>
        {!previewMode && <CellEditor />}
      </div>
    </div>
  );
}
