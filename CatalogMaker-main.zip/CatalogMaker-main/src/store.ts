import { create } from 'zustand';
import { v4 as uuidv4 } from 'uuid';
import { Item, Page, GlobalConfig, PageSize } from './types';
import { getLayoutById, getDefaultLayout, getDefaultLayoutForSeries, allSeries } from './presets';
import { SCHEMA_VERSION } from './schema/projectSchema';
import i18n from './i18n';
import { isCoverBlockPage, COVER_LAYOUT_ID, getDefaultCoverBlockHtml, HTML_CONTENT_MAX_LENGTH, getCoverHtmlSlots, getCoverActiveSlot } from './utils/pageUtils';
import type { HtmlContentSlotIndex } from './types';

interface Store {
  pages: Page[];
  globalConfig: GlobalConfig;
  defaultSeriesId: string;
  activePageId: string | null;
  selectedItemId: string | null;
  projectName: string;
  isItemDragging: boolean;
  theme: 'blue' | 'black';
  showGrid: boolean;
  previewMode: boolean;
  toastMessage: string | null;
  toastType: 'success' | 'warning' | null;
  toastKey: number;
  alertMessage: string | null;
  confirmMessage: string | null;
  confirmOnConfirm: (() => void) | null;
  isExporting: boolean;

  // Actions
  showToast: (message: string, type?: 'success' | 'warning') => void;
  setToastMessage: (message: string | null) => void;
  showAlert: (message: string) => void;
  setAlertMessage: (message: string | null) => void;
  showConfirm: (message: string, onConfirm: () => void) => void;
  setConfirmMessage: (message: string | null) => void;
  setTheme: (theme: 'blue' | 'black') => void;
  setIsItemDragging: (val: boolean) => void;
  addPage: (layoutId?: string) => void;
  addCoverPage: (pageSize: PageSize) => void;
  updatePageHtml: (id: string, html: string) => void;
  setPageHtmlActiveSlot: (id: string, slotIndex: HtmlContentSlotIndex) => void;
  deletePage: (id: string) => void;
  movePage: (id: string, direction: 'up' | 'down') => void;
  reorderPages: (oldIndex: number, newIndex: number) => void;
  reorderItems: (pageId: string, oldIndex: number, newIndex: number) => void;
  clearPage: (id: string) => void;
  updatePageLayout: (id: string, layoutId: string) => void;
  updateAllPagesLayout: (layoutId: string) => void;
  updatePageImageFit: (id: string, imageFit: 'cover' | 'contain') => void;
  updatePageImagePadding: (id: string, imagePadding: boolean) => void;
  updatePagePageNumber: (id: string, pageNumber: string) => void;
  updatePageHeaderSubtitle: (id: string, subtitle: string) => void;
  addProducts: (images: string[], target: 'all' | 'current', autoNumber: boolean, defaultSeriesId?: string) => void;
  applyNumbering: (target: 'all' | 'current') => void;
  batchFill: (data: Partial<Item>, target: 'all' | 'current') => void;
  batchClear: (target: 'all' | 'current', mode: 'number' | 'text') => void;

  updateItem: (id: string, updates: Partial<Item>) => void;
  deleteItem: (id: string) => void;

  updateGlobalConfig: (updates: Partial<GlobalConfig>) => void;
  setProjectName: (name: string) => void;
  setDefaultSeriesId: (id: string) => void;
  setActivePage: (id: string) => void;
  setSelectedItem: (id: string | null) => void;
  setShowGrid: (v: boolean) => void;
  setPreviewMode: (v: boolean) => void;
  setIsExporting: (v: boolean) => void;
  clearAll: () => void;
}

const SETTINGS_DRAFT_KEY = 'catalogMaker:settings:v1';
const MAX_PAGES = 50;

interface SettingsDraft {
  schemaVersion: number;
  globalConfig: GlobalConfig;
  defaultSeriesId: string;
  theme: 'blue' | 'black';
  savedAt: string;
}

function loadSettingsDraft(): Partial<SettingsDraft> | null {
  if (typeof window === 'undefined' || typeof window.localStorage === 'undefined') {
    return null;
  }
  try {
    const raw = window.localStorage.getItem(SETTINGS_DRAFT_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw) as Partial<SettingsDraft>;
    if (!parsed || typeof parsed !== 'object') return null;
    if (typeof parsed.schemaVersion !== 'number' || parsed.schemaVersion !== SCHEMA_VERSION) {
      // schema 版本不匹配，忽略并清理
      window.localStorage.removeItem(SETTINGS_DRAFT_KEY);
      return null;
    }
    if (!parsed.globalConfig || typeof parsed.defaultSeriesId !== 'string' || (parsed.theme !== 'blue' && parsed.theme !== 'black')) {
      return null;
    }
    return parsed;
  } catch (err) {
    // 解析失败或访问失败，清理坏数据
    try {
      window.localStorage.removeItem(SETTINGS_DRAFT_KEY);
    } catch {
      // ignore
    }
    return null;
  }
}

const defaultGlobalConfig: GlobalConfig = {
  header: 'Product Catalog',
  footer: '© 2026 Company Name',
  website: 'www.example.com',
  email: '',
  whatsapp: '',
  startNumber: 1,
  prefix: 'MPN-',
  showEmptySlots: false,
  logo: '',
  imagePadding: true,
  autoNumbering: true,
  headerFooterStyle: 'standard',
  pdfCompressionEnabled: true,
  pdfJpegQuality: 0.97,
  pdfStreamCompression: 'FAST',
  pdfMetadataInjectionEnabled: false,
  pdfMetadataTitle: '',
  pdfMetadataSubject: '',
  pdfMetadataAuthor: '',
  pdfMetadataKeywords: '',
};

const START_NUMBER_MIN = 1;
const START_NUMBER_MAX = 199;

function clampStartNumber(n: number): number {
  return Math.max(START_NUMBER_MIN, Math.min(START_NUMBER_MAX, n));
}

const draft = loadSettingsDraft();

let lastSettingsSave = 0;
function saveSettingsDraft() {
  if (typeof window === 'undefined' || typeof window.localStorage === 'undefined') {
    return;
  }
  const now = Date.now();
  if (now - lastSettingsSave < 500) return;
  lastSettingsSave = now;
  const state = useStore.getState();
  try {
    const payload: SettingsDraft = {
      schemaVersion: SCHEMA_VERSION,
      globalConfig: state.globalConfig,
      defaultSeriesId: state.defaultSeriesId,
      theme: state.theme,
      savedAt: new Date().toISOString(),
    };
    window.localStorage.setItem(SETTINGS_DRAFT_KEY, JSON.stringify(payload));
  } catch {
    // ignore storage errors
  }
}

export const useStore = create<Store>((set, get) => ({
  pages: (() => {
    const seriesId = draft?.defaultSeriesId ?? 'a4-standard';
    const layout = getDefaultLayoutForSeries(seriesId);
    return [{ id: uuidv4(), layoutId: layout.id, pageSize: layout.pageSize, items: [], pageSubtitles: ['Subtitle 1', 'Subtitle 2'], type: 'standard' as const }];
  })(),
  globalConfig: (() => {
    const base = draft?.globalConfig ? { ...defaultGlobalConfig, ...draft.globalConfig } : defaultGlobalConfig;
    if (base.pdfStreamCompression == null) {
      base.pdfStreamCompression = 'FAST';
    }
    const raw = base as unknown as Record<string, unknown>;
    if (base.pdfJpegQuality == null && raw.pdfCompress != null) {
      base.pdfJpegQuality = raw.pdfCompress ? 0.88 : 0.97;
      delete raw.pdfCompress;
    }
    if (base.pdfCompressionEnabled == null && raw.pdfLossless != null) {
      base.pdfCompressionEnabled = !raw.pdfLossless;
      delete raw.pdfLossless;
    }
    const validStyles = ['standard', 'fashion', 'brand'];
    if (base.headerFooterStyle != null && !validStyles.includes(base.headerFooterStyle)) {
      base.headerFooterStyle = 'standard';
    }
    return { ...base, startNumber: clampStartNumber(base.startNumber ?? 1) };
  })(),
  defaultSeriesId: draft?.defaultSeriesId ?? 'a4-standard',
  activePageId: null,
  selectedItemId: null,
  projectName: 'Untitled Catalog',
  isItemDragging: false,
  theme: draft?.theme ?? 'blue',
  showGrid: false,
  previewMode: false,
  toastMessage: null,
  toastType: null,
  toastKey: 0,
  alertMessage: null,
  confirmMessage: null,
  confirmOnConfirm: null,
  isExporting: false,

  showToast: (message, type = 'success') => set((s) => ({ toastMessage: message, toastType: type, toastKey: (s.toastKey ?? 0) + 1 })),
  setToastMessage: (message) => set({ toastMessage: message, toastType: null }),
  showAlert: (message) => set({ alertMessage: message }),
  setAlertMessage: (message) => set({ alertMessage: message }),
  showConfirm: (message, onConfirm) => set({ confirmMessage: message, confirmOnConfirm: onConfirm }),
  setConfirmMessage: (message) => set({ confirmMessage: message, confirmOnConfirm: null }),
  setTheme: (theme) => {
    set({ theme });
    saveSettingsDraft();
  },
  setIsItemDragging: (val) => set({ isItemDragging: val }),

  addPage: (layoutId) => set((state) => {
    if (get().isExporting) return state;
    if (state.pages.length >= MAX_PAGES) {
      get().showToast(i18n.t('sidebar.toastMaxPages'), 'warning');
      return state;
    }
    const layout = layoutId
      ? getLayoutById(layoutId)
      : getDefaultLayoutForSeries(state.defaultSeriesId);
    if (!layout) return state;
    const newPage: Page = { id: uuidv4(), layoutId: layout.id, pageSize: layout.pageSize, items: [], pageSubtitles: ['Subtitle 1', 'Subtitle 2'], type: 'standard' };
    return { pages: [...state.pages, newPage], activePageId: newPage.id };
  }),

  addCoverPage: (pageSize) => set((state) => {
    if (get().isExporting) return state;
    if (state.pages.length >= MAX_PAGES) {
      get().showToast(i18n.t('sidebar.toastMaxPages'), 'warning');
      return state;
    }
    const defaultHtml = getDefaultCoverBlockHtml();
    const newPage: Page = {
      id: uuidv4(),
      layoutId: COVER_LAYOUT_ID,
      pageSize,
      items: [],
      pageSubtitles: [],
      type: 'cover-block',
      htmlContent: defaultHtml,
      htmlContentSlots: [defaultHtml, '', ''],
      htmlContentActiveSlot: 0,
    };
    return { pages: [newPage, ...state.pages], activePageId: newPage.id };
  }),

  updatePageHtml: (id, html) => set((state) => {
    if (get().isExporting) return state;
    if (html.length > HTML_CONTENT_MAX_LENGTH) {
      get().showToast(i18n.t('cellEditor.htmlContentTooLong'), 'warning');
      return state;
    }
    return {
      pages: state.pages.map(p => {
        if (p.id !== id) return p;
        const slots = getCoverHtmlSlots(p);
        const activeSlot = getCoverActiveSlot(p);
        const newSlots: [string, string, string] = [...slots];
        newSlots[activeSlot] = html;
        return {
          ...p,
          htmlContentSlots: newSlots,
          htmlContent: newSlots[0],
        };
      })
    };
  }),

  setPageHtmlActiveSlot: (id, slotIndex) => set((state) => ({
    pages: state.pages.map(p => p.id === id ? { ...p, htmlContentActiveSlot: slotIndex } : p)
  })),

  deletePage: (id) => set((state) => {
    if (get().isExporting) return state;
    const newPages = state.pages.filter(p => p.id !== id);
    const fallbackLayout = newPages.length > 0
      ? null
      : getDefaultLayoutForSeries(state.defaultSeriesId);
    const pages = newPages.length > 0
      ? newPages
      : [{ id: uuidv4(), layoutId: fallbackLayout.id, pageSize: fallbackLayout.pageSize, items: [], pageSubtitles: ['Subtitle 1', 'Subtitle 2'], type: 'standard' as const }];
    return {
      pages,
      activePageId: state.activePageId === id ? (newPages[0]?.id ?? pages[0]?.id ?? null) : state.activePageId
    };
  }),

  movePage: (id, direction) => set((state) => {
    if (get().isExporting) return state;
    const index = state.pages.findIndex(p => p.id === id);
    if (index < 0) return state;
    if (direction === 'up' && index === 0) return state;
    if (direction === 'down' && index === state.pages.length - 1) return state;

    const newPages = [...state.pages];
    const targetIndex = direction === 'up' ? index - 1 : index + 1;
    [newPages[index], newPages[targetIndex]] = [newPages[targetIndex], newPages[index]];
    return { pages: newPages };
  }),

  reorderPages: (oldIndex, newIndex) => set((state) => {
    if (get().isExporting) return state;
    const newPages = [...state.pages];
    const [moved] = newPages.splice(oldIndex, 1);
    newPages.splice(newIndex, 0, moved);
    return { pages: newPages };
  }),

  reorderItems: (pageId, oldIndex, newIndex) => set((state) => {
    if (get().isExporting) return state;
    const pages = state.pages.map(p => {
      if (p.id !== pageId) return p;
      const newItems = [...p.items];
      const [moved] = newItems.splice(oldIndex, 1);
      newItems.splice(newIndex, 0, moved);
      return { ...p, items: newItems };
    });
    return { pages };
  }),

  clearPage: (id) => set((state) => {
    if (get().isExporting) return state;
    return { pages: state.pages.map(p => p.id === id ? { ...p, items: [] } : p) };
  }),

  updatePageLayout: (id, layoutId) => set((state) => {
    if (get().isExporting) return state;
    const layout = getLayoutById(layoutId);
    if (!layout) return state;
    const targetSeries = allSeries.find(s => s.layouts.some(l => l.id === layoutId));
    const currentSeries = allSeries.find(s => s.id === state.defaultSeriesId);
    if (!targetSeries || !currentSeries || targetSeries.id !== currentSeries.id) return state;
    return {
      pages: state.pages.map(p => p.id === id ? { ...p, layoutId: layout.id, pageSize: layout.pageSize } : p)
    };
  }),

  updateAllPagesLayout: (layoutId) => set((state) => {
    if (get().isExporting) return state;
    const layout = getLayoutById(layoutId);
    if (!layout) return state;
    const targetSeries = allSeries.find(s => s.layouts.some(l => l.id === layoutId));
    if (!targetSeries) return state;

    const pages = state.pages.map(p => {
      if (isCoverBlockPage(p)) return p;
      const pageSeries = allSeries.find(s => s.layouts.some(l => l.id === p.layoutId));
      const hasItems = (p.items?.length ?? 0) > 0;
      if (hasItems && pageSeries?.id !== targetSeries.id) return p;
      return { ...p, layoutId: layout.id, pageSize: layout.pageSize };
    });
    return { pages };
  }),

  updatePageImageFit: (id, imageFit) => set((state) => {
    if (get().isExporting) return state;
    return { pages: state.pages.map(p => p.id === id ? { ...p, imageFit } : p) };
  }),

  updatePageImagePadding: (id, imagePadding) => set((state) => {
    if (get().isExporting) return state;
    return { pages: state.pages.map(p => p.id === id ? { ...p, imagePadding } : p) };
  }),

  updatePagePageNumber: (id, pageNumber) => set((state) => ({
    pages: state.pages.map(p => p.id === id ? { ...p, pageNumber } : p)
  })),

  updatePageHeaderSubtitle: (id, subtitle) => set((state) => ({
    pages: state.pages.map(p => p.id === id ? { ...p, headerSubtitle: subtitle } : p)
  })),

  addProducts: (images, target, autoNumber, defaultSeriesId) => set((state) => {
    if (get().isExporting) return state;
    let pages = [...state.pages];
    let currentPageIndex = target === 'current' && state.activePageId 
      ? pages.findIndex(p => p.id === state.activePageId)
      : 0;
    
    if (currentPageIndex === -1) currentPageIndex = 0;

    let currentNumber = state.globalConfig.startNumber;
    if (autoNumber) {
      pages.forEach(p => p.items.forEach(item => {
        if (item.type === 'product' && item.number) {
          const numPart = item.number.replace(state.globalConfig.prefix, '');
          const parsed = parseInt(numPart, 10);
          if (!isNaN(parsed) && parsed >= currentNumber) {
            currentNumber = parsed + 1;
          }
        }
      }));
    }

    let imgIndex = 0;
    while (imgIndex < images.length) {
      let page = pages[currentPageIndex];
      
      // Skip cover pages
      if (isCoverBlockPage(page)) {
        currentPageIndex++;
        if (currentPageIndex >= pages.length) {
          if (pages.length >= MAX_PAGES) {
            get().showToast(i18n.t('sidebar.toastMaxPages'), 'warning');
            break;
          }
          let newLayout = getDefaultLayout();
          if (defaultSeriesId) {
            const series = allSeries.find(s => s.id === defaultSeriesId);
            if (series && series.layouts.length > 0) {
              newLayout = series.layouts[0];
            }
          }
          const newPage: Page = { id: uuidv4(), layoutId: newLayout.id, pageSize: newLayout.pageSize, items: [], pageSubtitles: ['Subtitle 1', 'Subtitle 2'], type: 'standard' };
          pages.push(newPage);
        }
        continue;
      }

      // 空页统一使用当前预设布局，避免用户添加新页后未填充前出现 A3/A4 混用
      if (page.items.length === 0 && (!page.type || page.type === 'standard') && defaultSeriesId) {
        const series = allSeries.find(s => s.id === defaultSeriesId);
        if (series && series.layouts.length > 0) {
          page = { ...page, layoutId: series.layouts[0].id, pageSize: series.layouts[0].pageSize };
          pages[currentPageIndex] = page;
        }
      }

      let layout = getLayoutById(page.layoutId) || getDefaultLayout();
      let currentUnits = page.items.length;

      if (currentUnits >= layout.maxItems) {
        // Move to next page or create new page
        currentPageIndex++;
        if (currentPageIndex >= pages.length) {
          if (pages.length >= MAX_PAGES) {
            get().showToast(i18n.t('sidebar.toastMaxPages'), 'warning');
            break;
          }
          let newLayout = layout;
          if (defaultSeriesId) {
            const series = allSeries.find(s => s.id === defaultSeriesId);
            if (series && series.layouts.length > 0) {
              newLayout = series.layouts[0];
            }
          }
          const newPage: Page = { id: uuidv4(), layoutId: newLayout.id, pageSize: newLayout.pageSize, items: [], pageSubtitles: ['Subtitle 1', 'Subtitle 2'], type: 'standard' as const };
          pages.push(newPage);
        }
        page = pages[currentPageIndex];
        layout = getLayoutById(page.layoutId) || getDefaultLayout();
        currentUnits = page.items.length;
      }

      const availableUnits = layout.maxItems - currentUnits;
      const itemsToAdd = Math.min(availableUnits, images.length - imgIndex);

      const newItems: Item[] = [];
      for (let i = 0; i < itemsToAdd; i++) {
        const imgData = images[imgIndex];
        newItems.push({
          id: uuidv4(),
          type: 'product',
          image: imgData,
          imageOriginal: imgData,
          title: `Product`,
          number: autoNumber ? `${state.globalConfig.prefix}${currentNumber.toString().padStart(3, '0')}` : undefined,
          badgeColor: 'blue',
        });
        imgIndex++;
        if (autoNumber) currentNumber++;
      }

      pages[currentPageIndex] = {
        ...page,
        items: [...page.items, ...newItems]
      };
    }

    return { pages };
  }),

  applyNumbering: (target) => set((state) => {
    if (get().isExporting) return state;
    if (target === 'current' && !state.activePageId && state.pages.length > 0) {
      get().showToast(i18n.t('sidebar.toastSelectPageFirst'), 'warning');
      return state;
    }
    let currentNumber = state.globalConfig.startNumber;
    const pages = state.pages.map(p => {
      if (target === 'current' && p.id !== state.activePageId) return p;
      if (isCoverBlockPage(p)) return p;

      const items = p.items ?? [];
      return {
        ...p,
        items: items.map(item => {
          if (item.type === 'product') {
            const number = `${state.globalConfig.prefix}${currentNumber.toString().padStart(3, '0')}`;
            currentNumber++;
            return { ...item, number };
          }
          return item;
        })
      };
    });
    return { pages };
  }),

  batchFill: (data, target) => set((state) => {
    if (get().isExporting) return state;
    if (target === 'current' && !state.activePageId && state.pages.length > 0) {
      get().showToast(i18n.t('sidebar.toastSelectPageFirst'), 'warning');
      return state;
    }
    const BATCH_FILL_MAX_LENGTH = 15;
    const sanitized: Partial<Item> = { ...data };
    if (typeof sanitized.price === 'string' && sanitized.price.length > BATCH_FILL_MAX_LENGTH) {
      sanitized.price = sanitized.price.slice(0, BATCH_FILL_MAX_LENGTH);
    }
    if (typeof sanitized.badge === 'string' && sanitized.badge.length > BATCH_FILL_MAX_LENGTH) {
      sanitized.badge = sanitized.badge.slice(0, BATCH_FILL_MAX_LENGTH);
    }
    if (sanitized.badge === '') {
      sanitized.badgeColor = undefined;
    }
    const pages = state.pages.map(p => {
      if (target === 'current' && p.id !== state.activePageId) return p;
      if (isCoverBlockPage(p)) return p;

      const items = p.items ?? [];
      return {
        ...p,
        items: items.map(item => {
          if (item.type === 'product') {
            return { ...item, ...sanitized };
          }
          return item;
        })
      };
    });
    return { pages };
  }),

  batchClear: (target, mode) => set((state) => {
    if (get().isExporting) return state;
    if (target === 'current' && !state.activePageId && state.pages.length > 0) {
      get().showToast(i18n.t('sidebar.toastSelectPageFirst'), 'warning');
      return state;
    }
    const clearData: Partial<Item> =
      mode === 'number'
        ? { number: undefined }
        : { price: '', badge: '', badgeColor: undefined };
    const pages = state.pages.map(p => {
      if (target === 'current' && p.id !== state.activePageId) return p;
      if (isCoverBlockPage(p)) return p;

      const items = p.items ?? [];
      return {
        ...p,
        items: items.map(item => {
          if (item.type === 'product') {
            return { ...item, ...clearData };
          }
          return item;
        })
      };
    });
    return { pages };
  }),

  updateItem: (id, updates) => set((state) => {
    if (get().isExporting) return state;
    const pages = state.pages.map(p => ({
      ...p,
      items: p.items.map(item => item.id === id ? { ...item, ...updates } : item)
    }));
    return { pages };
  }),

  deleteItem: (id) => set((state) => {
    if (get().isExporting) return state;
    const pages = state.pages.map(p => ({
      ...p,
      items: p.items.filter(item => item.id !== id)
    }));
    return { pages, selectedItemId: state.selectedItemId === id ? null : state.selectedItemId };
  }),

  updateGlobalConfig: (updates) => {
    set((state) => {
      const merged = { ...state.globalConfig, ...updates };
      if (typeof merged.startNumber === 'number') {
        merged.startNumber = clampStartNumber(merged.startNumber);
      }
      return { globalConfig: merged };
    });
    saveSettingsDraft();
  },

  setProjectName: (name) => set({ projectName: name }),
  setDefaultSeriesId: (id) => {
    set((state) => {
      const hasAnyStandardItems = state.pages.some(
        (p) => (!p.type || p.type === 'standard') && p.items.length > 0
      );
      const next: Record<string, unknown> = { defaultSeriesId: id };
      if (!hasAnyStandardItems) {
        const series = allSeries.find((s) => s.id === id);
        const defaultLayout = series?.layouts[0];
        if (defaultLayout) {
          const newPageSize = defaultLayout.pageSize;
          next.pages = state.pages.map((p) => {
            const isStandard = !p.type || p.type === 'standard';
            if (isStandard && p.items.length === 0) {
              return { ...p, layoutId: defaultLayout.id, pageSize: newPageSize };
            }
            if (isCoverBlockPage(p)) {
              return { ...p, pageSize: newPageSize };
            }
            return p;
          });
        }
      }
      return next as Partial<typeof state>;
    });
    saveSettingsDraft();
  },
  setActivePage: (id) => set({ activePageId: id }),
  setSelectedItem: (id) => set({ selectedItemId: id }),
  setShowGrid: (v) => set({ showGrid: v }),
  setPreviewMode: (v) => set({ previewMode: v }),
  setIsExporting: (v) => set({ isExporting: v }),
  // reset all pages and settings to defaults
  clearAll: () => {
    set({
      pages: [{ id: uuidv4(), layoutId: getDefaultLayout().id, pageSize: getDefaultLayout().pageSize, items: [], pageSubtitles: ['Subtitle 1', 'Subtitle 2'], type: 'standard' as const }],
      globalConfig: defaultGlobalConfig,
      defaultSeriesId: 'a4-standard',
      activePageId: null,
      selectedItemId: null,
      projectName: 'Untitled Catalog',
      isItemDragging: false,
      theme: 'blue',
    });
    try {
      if (typeof window !== 'undefined' && typeof window.localStorage !== 'undefined') {
        window.localStorage.removeItem(SETTINGS_DRAFT_KEY);
      }
    } catch {
      // ignore
    }
  },
}));
