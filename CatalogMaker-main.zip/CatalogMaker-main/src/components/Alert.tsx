import React from 'react';
import { useTranslation } from 'react-i18next';
import { useStore } from '../store';
import clsx from 'clsx';
import { PrimaryButton } from './ui';

/**
 * Modal that mimics window.alert(): centered box, backdrop, message, and OK button.
 * Use store.showAlert('message') to show; clicking OK calls setAlertMessage(null).
 */
export const Alert: React.FC = () => {
  const { t } = useTranslation();
  const { alertMessage, setAlertMessage, theme } = useStore();

  if (alertMessage == null) {
    return null;
  }

  const isBlue = theme === 'blue';

  const handleOk = () => {
    setAlertMessage(null);
  };

  const handleBackdropClick = (e: React.MouseEvent) => {
    if (e.target === e.currentTarget) {
      handleOk();
    }
  };

  return (
    <div
      className="fixed inset-0 z-[100] flex items-center justify-center bg-black/30"
      onClick={handleBackdropClick}
      role="alertdialog"
      aria-modal="true"
      aria-labelledby="alert-message"
    >
      <div
        className={clsx(
          'min-w-[280px] max-w-[90vw] rounded-lg border bg-white p-5 shadow-xl',
          isBlue ? 'border-gray-200' : 'border-zinc-200'
        )}
        onClick={(e) => e.stopPropagation()}
      >
        <p id="alert-message" className="mb-5 text-sm text-gray-800 whitespace-pre-wrap text-center">
          {alertMessage}
        </p>
        <div className="flex justify-center">
          <PrimaryButton onClick={handleOk} fullWidth={false}>
            {t('common.confirm')}
          </PrimaryButton>
        </div>
      </div>
    </div>
  );
};
