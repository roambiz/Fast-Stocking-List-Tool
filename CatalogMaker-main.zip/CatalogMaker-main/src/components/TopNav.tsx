import React, { useState } from 'react';
import { useTranslation } from 'react-i18next';
import clsx from 'clsx';
import { Download, LayoutTemplate, Loader2, Compass, X } from 'lucide-react';
import { useStore } from '../store';
import { checkAndRecordExport } from '../utils/exportThrottle';
import { getFooterLinkAnnotations } from '../utils/pdfLinks';
import { getPixelRatio } from '../utils/exportImageConfig';
import { isCoverBlockPage } from '../utils/pageUtils';
import { applyPdfDocumentMetadata } from '../utils/pdfMetadata';
import { PrimaryButton, Modal, IconButton, TabBar } from './ui';

type GuideTab = 'workflow' | 'features' | 'shortcuts';

export const TopNav: React.FC = () => {
  const { t, i18n } = useTranslation();
  const { projectName, setProjectName, theme, setTheme, showToast, globalConfig, isExporting, setIsExporting } = useStore();
  const [exportError, setExportError] = useState<string | null>(null);
  const [projectNameFocused, setProjectNameFocused] = useState(false);
  const [guideOpen, setGuideOpen] = useState(false);
  const [guideTab, setGuideTab] = useState<GuideTab>('workflow');

  const toggleTheme = () => {
    if (isExporting) return;
    setTheme(theme === 'blue' ? 'black' : 'blue');
    showToast(t('sidebar.toastThemeSwitched'));
  };

  const handleExportPDF = async () => {
    if (isExporting) return;
    if (!checkAndRecordExport()) {
      showToast(t('common.exportThrottled'), 'warning');
      return;
    }
    setExportError(null);
    setIsExporting(true);

    try {
      const [htmlToImage, { jsPDF }] = await Promise.all([
        import('html-to-image'),
        import('jspdf'),
      ]);

      const pageElements = document.querySelectorAll('.pdf-page');
      const currentPages = useStore.getState().pages;
      const initialPageCount = currentPages.length;
      if (pageElements.length === 0 || pageElements.length !== initialPageCount) {
        const msg = pageElements.length === 0 ? t('topNav.noPagesToExport') : t('topNav.exportSyncError');
        setExportError(msg);
        showToast(msg, 'warning');
        return;
      }

      // Wait for layout to settle before capture to avoid text wrapping differences
      await new Promise((r) => requestAnimationFrame(() => requestAnimationFrame(r)));

      const firstIsA3 = currentPages[0]?.pageSize === 'A3';
      const compressionEnabled = globalConfig.pdfCompressionEnabled ?? true;
      const jpegQuality = compressionEnabled ? (globalConfig.pdfJpegQuality ?? 0.97) : 1;
      const streamCompression = compressionEnabled ? (globalConfig.pdfStreamCompression ?? 'FAST') : 'NONE';
      const pdf = new jsPDF({
        orientation: firstIsA3 ? 'l' : 'p',
        unit: 'mm',
        format: firstIsA3 ? 'a3' : 'a4',
        compress: streamCompression === 'SLOW',
      });

      for (let i = 0; i < pageElements.length; i++) {
        const freshPages = useStore.getState().pages;
        if (freshPages.length !== initialPageCount) {
          const msg = t('topNav.exportSyncError');
          setExportError(msg);
          showToast(msg, 'warning');
          return;
        }
        const currentPages = freshPages;
        const el = pageElements[i] as HTMLElement;
        const isA3 = currentPages[i]?.pageSize === 'A3';
        
        // Temporarily remove scale and shadows for accurate capture
        const originalTransform = el.style.transform;
        const originalBoxShadow = el.style.boxShadow;
        el.style.transform = 'none';
        el.style.boxShadow = 'none';
        
        const pixelRatio = getPixelRatio(compressionEnabled);
        const captureOptions = {
          pixelRatio,
          backgroundColor: '#ffffff',
          cacheBust: true,
          style: { transform: 'none', boxShadow: 'none' },
        };

        let imgData: string;
        let imgFormat: 'JPEG' | 'PNG';
        if (compressionEnabled) {
          imgData = await htmlToImage.toJpeg(el, {
            ...captureOptions,
            quality: jpegQuality,
          });
          imgFormat = 'JPEG';
        } else {
          imgData = await htmlToImage.toPng(el, captureOptions);
          imgFormat = 'PNG';
        }

        const width = isA3 ? 420 : 210;
        const height = isA3 ? 297 : 297;
        const page = currentPages[i];

        const linkAnnotations = (page && !isCoverBlockPage(page))
          ? getFooterLinkAnnotations(el, width, height)
          : [];

        el.style.transform = originalTransform;
        el.style.boxShadow = originalBoxShadow;

        if (i > 0) {
          pdf.addPage(isA3 ? 'a3' : 'a4', isA3 ? 'l' : 'p');
        }

        pdf.addImage(imgData, imgFormat, 0, 0, width, height, undefined, streamCompression);

        linkAnnotations.forEach((ann) => {
          pdf.link(ann.x, ann.y, ann.w, ann.h, {
            url: ann.url,
            newWindow: true,
          });
        });
      }

      const latestConfig = useStore.getState().globalConfig;
      applyPdfDocumentMetadata(pdf, latestConfig);

      // Generate Blob and trigger download manually to bypass potential iframe restrictions
      const pdfBlob = pdf.output('blob');
      const blobUrl = URL.createObjectURL(pdfBlob);
      
      const link = document.createElement('a');
      link.href = blobUrl;
      link.download = `${projectName || t('topNav.defaultProjectName')}.pdf`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      
      setTimeout(() => URL.revokeObjectURL(blobUrl), 100);

    } catch {
      setExportError(t('topNav.exportFailed'));
    } finally {
      setIsExporting(false);
    }
  };

  const isBlue = theme === 'blue';
  const currentLang = i18n.language === 'zh' ? 'zh' : 'en';

  const changeLang = (lang: 'en' | 'zh') => {
    if (lang === currentLang) return;
    i18n.changeLanguage(lang);
    try {
      window.localStorage.setItem('catalogMaker:lang', lang);
    } catch {
      // ignore
    }
  };

  return (
    <header className="h-16 bg-white border-b border-gray-200 flex items-center justify-between px-6 shrink-0 z-10">
      <div className="flex items-center gap-4">
        <div
          role="button"
          tabIndex={0}
          onClick={toggleTheme}
          onKeyDown={(e) => e.key === 'Enter' && toggleTheme()}
          className={clsx(
            'w-10 h-10 rounded-lg flex items-center justify-center text-white shadow-sm transition-colors',
            isBlue ? 'bg-blue-600 hover:bg-blue-700' : 'bg-zinc-900 hover:bg-zinc-800',
            isExporting ? 'cursor-not-allowed opacity-70' : 'cursor-pointer'
          )}
          title={t('topNav.toggleThemeTitle')}
          aria-disabled={isExporting}
        >
          <LayoutTemplate size={20} />
        </div>
        <div className="flex flex-col gap-0.5">
          <div className="flex items-center gap-2">
            <input
              type="text"
              value={projectName}
              onChange={(e) => setProjectName(e.target.value.slice(0, 25))}
              onFocus={() => setProjectNameFocused(true)}
              onBlur={() => setProjectNameFocused(false)}
              disabled={isExporting}
              readOnly={isExporting}
              className={clsx(
                'text-xl font-bold text-gray-900 bg-transparent border-b-2 border-transparent focus:ring-0 p-1 transition-colors outline-none',
                isBlue ? 'focus:border-blue-600' : 'focus:border-zinc-900',
                isExporting && 'cursor-not-allowed opacity-70'
              )}
              placeholder={t('topNav.placeholderProjectName')}
              maxLength={25}
            />
            {projectNameFocused && (
              <span className="text-xs font-mono text-gray-400 shrink-0">{projectName.length} / 25</span>
            )}
          </div>
        </div>
      </div>
      <div className="flex items-center gap-4">
        <button
          type="button"
          onClick={() => setGuideOpen(true)}
          className="flex items-center justify-center w-9 h-9 rounded-lg border border-gray-200 text-gray-600 hover:bg-gray-50 transition-colors"
          title={t('topNav.userGuideTitle')}
          aria-label={t('topNav.userGuideTitle')}
        >
          <Compass size={18} strokeWidth={2} />
        </button>
        <div className="flex items-center rounded-lg border border-gray-200 overflow-hidden">
          <button
            type="button"
            onClick={() => changeLang('en')}
            className={`px-3 py-2 text-xs font-medium rounded-l-lg transition-colors ${currentLang === 'en' ? (isBlue ? 'bg-blue-600 text-white' : 'bg-zinc-900 text-white') : 'bg-white text-gray-600 hover:bg-gray-50'}`}
          >
            {t('topNav.langEn')}
          </button>
          <button
            type="button"
            onClick={() => changeLang('zh')}
            className={`px-3 py-2 text-xs font-medium rounded-r-lg transition-colors ${currentLang === 'zh' ? (isBlue ? 'bg-blue-600 text-white' : 'bg-zinc-900 text-white') : 'bg-white text-gray-600 hover:bg-gray-50'}`}
          >
            {t('topNav.langZh')}
          </button>
        </div>
        {exportError && <span className="text-sm text-red-600 font-medium px-2 py-1 bg-red-50 rounded">{exportError}</span>}
        <PrimaryButton
          fullWidth={false}
          compact
          onClick={handleExportPDF}
          disabled={isExporting}
          icon={isExporting ? undefined : Download}
          className="transition-transform duration-200 hover:scale-[1.02] active:scale-[0.98] disabled:hover:scale-100 disabled:active:scale-100"
        >
          {isExporting ? (
            <>
              <Loader2 size={18} className="animate-spin" />
              {t('topNav.exporting')}
            </>
          ) : (
            t('topNav.exportPdf')
          )}
        </PrimaryButton>
      </div>
      {guideOpen && (
        <Modal
          isOpen={true}
          onClose={() => setGuideOpen(false)}
          maxWidth="2xl"
          maxHeight="85vh"
          closeOnOverlayClick={true}
        >
          <div className="flex items-center justify-between px-6 py-4 border-b border-gray-200 shrink-0">
            <h2 className="text-lg font-bold text-gray-900">
              {t('topNav.userGuideHeading')}
            </h2>
            <IconButton
              icon={X}
              onClick={() => setGuideOpen(false)}
              title={t('topNav.closeGuide')}
              ariaLabel={t('topNav.closeGuide')}
              theme={theme}
              className="rounded-lg text-gray-500"
            />
          </div>
          <TabBar
            tabs={[
              { id: 'workflow', label: t('topNav.guideTabWorkflow') },
              { id: 'features', label: t('topNav.guideTabFeatures') },
              { id: 'shortcuts', label: t('topNav.guideTabShortcuts') },
            ]}
            value={guideTab}
            onChange={(id) => setGuideTab(id as GuideTab)}
          />
          <div className="flex-1 overflow-y-auto px-6 py-5 text-sm text-gray-700 leading-relaxed">
            {guideTab === 'workflow' && (
              <div className="space-y-4">
                <p className="font-medium text-gray-900">{t('topNav.guideWorkflowIntro')}</p>
                <p className="whitespace-pre-line text-gray-600">{t('topNav.guideWorkflowSteps')}</p>
                <div>
                  <p className="font-medium text-gray-900 mb-1.5">{t('topNav.guideWorkflowExportTitle')}</p>
                  <ul className="list-disc list-inside space-y-1 text-gray-600">
                    <li>{t('topNav.guideWorkflowExportPdf')}</li>
                    <li>{t('topNav.guideWorkflowExportJpg')}</li>
                    <li>{t('topNav.guideWorkflowExportZip')}</li>
                  </ul>
                </div>
                <p>{t('topNav.guideWorkflowSuggest')}</p>
                <p><strong>{t('topNav.guideWorkflowExportTypes')}</strong></p>
                <div className="pt-2 space-y-1 text-gray-500 text-xs border-t border-gray-100">
                  <p>{t('topNav.guideWorkflowNote1')}</p>
                  <p>{t('topNav.guideWorkflowNote2')}</p>
                </div>
              </div>
            )}
            {guideTab === 'features' && (
              <div className="space-y-4">
                <div>
                  <p className="font-medium text-gray-900 mb-1">{t('topNav.guideFeaturesSectionTopBar')}</p>
                  <p className="text-gray-600">{t('topNav.guideFeaturesTopBar')}</p>
                </div>
                <div>
                  <p className="font-medium text-gray-900 mb-1">{t('topNav.guideFeaturesSectionCanvas')}</p>
                  <p className="whitespace-pre-line text-gray-600">{t('topNav.guideFeaturesCanvas')}</p>
                </div>
                <div>
                  <p className="font-medium text-gray-900 mb-1">{t('topNav.guideFeaturesSectionSidebar')}</p>
                  <p className="whitespace-pre-line text-gray-600">{t('topNav.guideFeaturesSidebar')}</p>
                </div>
                <div>
                  <p className="font-medium text-gray-900 mb-1">{t('topNav.guideFeaturesSectionFilmstrip')}</p>
                  <p className="text-gray-600">{t('topNav.guideFeaturesFilmstrip')}</p>
                </div>
                <div>
                  <p className="font-medium text-gray-900 mb-1">{t('topNav.guideFeaturesSectionPageToolbar')}</p>
                  <p className="text-gray-600">{t('topNav.guideFeaturesPageToolbar')}</p>
                </div>
                <div>
                  <p className="font-medium text-gray-900 mb-1">{t('topNav.guideFeaturesSectionEditor')}</p>
                  <div className="space-y-1.5 text-gray-600">
                    <p><span className="text-gray-500">{t('topNav.guideFeaturesEditorCardLabel')}</span>{t('topNav.guideFeaturesEditorCard')}</p>
                    <p><span className="text-gray-500">{t('topNav.guideFeaturesEditorPageLabel')}</span>{t('topNav.guideFeaturesEditorPage')}</p>
                    <p><span className="text-gray-500">{t('topNav.guideFeaturesEditorCoverLabel')}</span>{t('topNav.guideFeaturesEditorCover')}</p>
                  </div>
                </div>
              </div>
            )}
            {guideTab === 'shortcuts' && (
              <ul className="list-disc list-inside space-y-2">
                <li>{t('topNav.guideShortcutsAltWheel')}</li>
                <li>{t('topNav.guideShortcutsFit')}</li>
                <li>{t('topNav.guideShortcutsEscape')}</li>
              </ul>
            )}
          </div>
          <div className="px-6 py-3 border-t border-gray-100 bg-gray-50 text-xs text-gray-500">
            <div>{t('topNav.guideToolAuthor')}</div>
            <div>{t('topNav.guideDocAuthor')}</div>
          </div>
        </Modal>
      )}
    </header>
  );
};
