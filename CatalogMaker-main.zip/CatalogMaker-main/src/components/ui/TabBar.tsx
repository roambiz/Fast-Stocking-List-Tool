import React from 'react';
import { useStore } from '../../store';
import clsx from 'clsx';

export interface TabItem {
  id: string;
  label: string;
}

interface TabBarProps {
  tabs: TabItem[];
  value: string;
  onChange: (id: string) => void;
  className?: string;
}

export const TabBar: React.FC<TabBarProps> = ({ tabs, value, onChange, className }) => {
  const { theme } = useStore();
  const isBlue = theme === 'blue';

  return (
    <div className={clsx('flex border-b border-gray-200 bg-gray-50', className)}>
      {tabs.map((tab, index) => {
        const isActive = value === tab.id;
        const isLast = index === tabs.length - 1;
        return (
          <button
            key={tab.id}
            type="button"
            onClick={() => onChange(tab.id)}
            className={clsx(
              'flex-1 py-4 text-sm font-medium transition-colors',
              !isLast && 'border-r border-gray-200',
              isActive
                ? `bg-white ${isBlue ? 'text-blue-600 border-b-2 border-b-blue-600' : 'text-zinc-900 border-b-2 border-b-zinc-900'}`
                : 'text-gray-600 hover:bg-gray-100'
            )}
          >
            {tab.label}
          </button>
        );
      })}
    </div>
  );
};
