import React from 'react';
import { useStore } from '../../store';
import clsx from 'clsx';
import type { LucideIcon } from 'lucide-react';

interface OptionCardProps {
  icon: LucideIcon;
  title: string;
  description?: string;
  selected: boolean;
  onClick: () => void;
  disabled?: boolean;
  className?: string;
}

export const OptionCard: React.FC<OptionCardProps> = ({
  icon: Icon,
  title,
  description,
  selected,
  onClick,
  disabled = false,
  className,
}) => {
  const { theme } = useStore();
  const isBlue = theme === 'blue';

  const selectedClass = selected
    ? isBlue
      ? 'border-blue-500 bg-blue-50 ring-1 ring-blue-500'
      : 'border-zinc-800 bg-zinc-100 ring-1 ring-zinc-800'
    : 'border-gray-200 bg-white hover:border-gray-300 hover:shadow-sm';

  const iconClass = selected
    ? isBlue
      ? 'text-blue-600'
      : 'text-zinc-900'
    : 'text-gray-500';

  return (
    <button
      type="button"
      onClick={onClick}
      disabled={disabled}
      className={clsx(
        'flex items-center gap-3 p-3 rounded-lg border transition-all text-left w-full',
        selectedClass,
        disabled && 'cursor-not-allowed opacity-60',
        className
      )}
    >
      <Icon size={20} className={iconClass} />
      <div className="flex flex-col items-start">
        <span className="text-sm font-bold text-gray-900">{title}</span>
        {description != null && (
          <span className="text-xs text-gray-500">{description}</span>
        )}
      </div>
    </button>
  );
};
