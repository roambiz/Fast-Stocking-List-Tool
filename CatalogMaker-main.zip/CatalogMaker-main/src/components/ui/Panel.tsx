import React from 'react';
import { useStore } from '../../store';
import clsx from 'clsx';
import type { LucideIcon } from 'lucide-react';

interface PanelProps {
  title?: React.ReactNode;
  icon?: LucideIcon;
  action?: React.ReactNode;
  children: React.ReactNode;
  className?: string;
}

export const Panel: React.FC<PanelProps> = ({ title, icon: Icon, action, children, className }) => {
  const { theme } = useStore();
  const isBlue = theme === 'blue';

  const hasHeader = title != null || Icon != null || action != null;

  return (
    <div className={clsx('bg-white rounded-xl border border-gray-200 p-5 shadow-sm', className)}>
      {hasHeader && (
        <div className="flex justify-between items-center mb-5 border-b border-gray-100 pb-3">
          <div className="flex items-center gap-2">
            {Icon != null && <Icon size={18} className={isBlue ? 'text-blue-500' : 'text-zinc-800'} />}
            {title != null && (
              <h2 className="text-sm font-bold text-gray-900">
                {title}
              </h2>
            )}
          </div>
          {action != null && <div>{action}</div>}
        </div>
      )}
      {children}
    </div>
  );
};
