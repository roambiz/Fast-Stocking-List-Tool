import React from 'react';
import clsx from 'clsx';
import { DashedBox } from './DashedBox';

export interface HintCardProps {
  icon: React.ReactNode;
  text: string;
  className?: string;
}

/**
 * 空状态提示卡片，样式与「选择一个卡片进行编辑」一致。
 * 用于 CellEditor 未选卡片、Sidebar 封面模式等场景。
 */
export const HintCard: React.FC<HintCardProps> = ({ icon, text, className }) => {
  return (
    <DashedBox
      className={clsx(
        'h-full flex flex-col items-center justify-center text-gray-500 rounded-xl p-8',
        className
      )}
    >
      <div className="mb-4 text-gray-400">
        {icon}
      </div>
      <p className="text-sm font-medium text-center">{text}</p>
    </DashedBox>
  );
};
