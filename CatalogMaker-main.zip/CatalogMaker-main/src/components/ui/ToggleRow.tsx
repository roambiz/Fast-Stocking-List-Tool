import React from 'react';
import { useStore } from '../../store';
import clsx from 'clsx';
import { Check } from 'lucide-react';

interface ToggleRowProps {
  label: React.ReactNode;
  checked: boolean;
  onChange: () => void;
  rightNode?: React.ReactNode;
  className?: string;
}

export const ToggleRow: React.FC<ToggleRowProps> = ({
  label,
  checked,
  onChange,
  rightNode,
  className,
}) => {
  const { theme } = useStore();
  const isBlue = theme === 'blue';

  const checkboxClass = clsx(
    'w-5 h-5 rounded border flex items-center justify-center transition-colors',
    checked
      ? isBlue
        ? 'bg-blue-500 border-blue-500 text-white'
        : 'bg-zinc-800 border-zinc-800 text-white'
      : 'border-gray-300 bg-white'
  );

  return (
    <button
      type="button"
      onClick={onChange}
      className={clsx(
        'w-full flex items-center justify-between p-3 border border-gray-200 rounded-lg bg-white hover:bg-gray-50 transition-colors shadow-sm',
        className
      )}
    >
      <span className="text-sm font-medium text-gray-700">{label}</span>
      {rightNode != null ? (
        rightNode
      ) : (
        <div className={checkboxClass}>
          {checked && <Check size={14} strokeWidth={3} />}
        </div>
      )}
    </button>
  );
};
