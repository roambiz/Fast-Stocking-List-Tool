import React from 'react';
import clsx from 'clsx';
import type { LucideIcon } from 'lucide-react';

export interface IconButtonProps {
  icon: LucideIcon;
  onClick: React.MouseEventHandler<HTMLButtonElement>;
  title: string;
  ariaLabel: string;
  variant?: 'default' | 'danger';
  theme?: 'blue' | 'black';
  className?: string;
}

export const IconButton: React.FC<IconButtonProps> = ({
  icon: Icon,
  onClick,
  title,
  ariaLabel,
  variant = 'default',
  theme = 'blue',
  className,
}) => {
  const baseClass = 'p-2 rounded transition-colors focus:outline-none focus-visible:ring-2 focus-visible:ring-offset-2';
  const variantClass =
    variant === 'danger'
      ? 'hover:bg-red-50 text-red-600'
      : 'hover:bg-gray-100 text-gray-700';
  const focusRingColor =
    variant === 'danger'
      ? 'focus-visible:ring-red-500'
      : theme === 'black'
        ? 'focus-visible:ring-zinc-800'
        : 'focus-visible:ring-blue-500';

  return (
    <button
      type="button"
      onClick={onClick}
      title={title}
      aria-label={ariaLabel}
      className={clsx(baseClass, variantClass, focusRingColor, className)}
    >
      <Icon size={18} strokeWidth={2.5} />
    </button>
  );
};
