import React from 'react';
import { useStore } from '../../store';
import clsx from 'clsx';

export interface SegmentedOption {
  value: string;
  label: string;
}

interface SegmentedControlProps {
  label?: string;
  options: SegmentedOption[];
  value: string;
  onChange: (value: string) => void;
  columns?: 1 | 2;
  className?: string;
}

export const SegmentedControl: React.FC<SegmentedControlProps> = ({
  label,
  options,
  value,
  onChange,
  columns = 1,
  className,
}) => {
  const { theme } = useStore();
  const isBlue = theme === 'blue';

  const containerClass =
    columns === 2
      ? 'rounded-lg border border-gray-200 bg-gray-50 p-1 grid grid-cols-2 gap-1'
      : 'flex rounded-lg border border-gray-200 bg-gray-50 p-1';

  return (
    <div className={clsx('flex flex-col gap-2', className)}>
      {label != null && (
        <span className="text-xs font-medium text-gray-500 uppercase tracking-wider">
          {label}
        </span>
      )}
      <div className={containerClass}>
        {options.map((opt) => {
          const isActive = value === opt.value;
          return (
            <button
              key={opt.value}
              type="button"
              onClick={() => onChange(opt.value)}
              className={clsx(
                'flex-1 py-1.5 text-xs font-medium rounded-lg transition-colors',
                columns === 2 && 'flex flex-col items-center justify-center h-14',
                isActive
                  ? `bg-white shadow-sm ${isBlue ? 'text-blue-600' : 'text-zinc-900'}`
                  : 'text-gray-600 hover:text-gray-900'
              )}
            >
              {opt.label}
            </button>
          );
        })}
      </div>
    </div>
  );
};
