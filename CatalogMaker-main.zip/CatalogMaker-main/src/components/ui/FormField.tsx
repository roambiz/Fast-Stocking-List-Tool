import React, { useState } from 'react';
import { useStore } from '../../store';
import clsx from 'clsx';
import type { LucideIcon } from 'lucide-react';

interface FormFieldProps {
  label?: string;
  icon?: LucideIcon;
  type?: 'text' | 'number';
  value: string | number;
  onChange: (value: string | number) => void;
  onBlur?: () => void;
  placeholder?: string;
  maxLength?: number;
  min?: number;
  max?: number;
  error?: string;
  className?: string;
  inputClassName?: string;
}

export const FormField: React.FC<FormFieldProps> = ({
  label,
  icon: Icon,
  type = 'text',
  value,
  onChange,
  onBlur,
  placeholder,
  maxLength,
  min,
  max,
  error,
  className,
  inputClassName,
}) => {
  const { theme } = useStore();
  const isBlue = theme === 'blue';
  const [isFocused, setIsFocused] = useState(false);

  const focusRing = isBlue
    ? 'focus:ring-2 focus:ring-blue-500 focus:border-transparent'
    : 'focus:ring-2 focus:ring-zinc-800 focus:border-transparent';

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (type === 'number') {
      const num = parseInt(e.target.value, 10);
      if (Number.isNaN(num)) {
        onChange(0);
      } else {
        const clamped = min != null && num < min ? min : max != null && num > max ? max : num;
        onChange(clamped);
      }
    } else {
      onChange(e.target.value);
    }
  };

  const inputValue = type === 'number' && typeof value === 'number' ? String(value) : value;

  const showCharCount = type === 'text' && maxLength != null && isFocused;
  const charCount = typeof inputValue === 'string' ? inputValue.length : 0;

  return (
    <div className={clsx('flex flex-col gap-1', className)}>
      {label != null && (
        <label className="text-xs font-medium text-gray-500 flex items-center justify-between gap-1">
          <span className="flex items-center gap-1">
            {Icon != null && <Icon size={14} />}
            {label}
          </span>
          {showCharCount && (
            <span className="font-mono text-gray-400 shrink-0">{charCount} / {maxLength}</span>
          )}
        </label>
      )}
      <input
        type={type}
        value={inputValue}
        onChange={handleChange}
        onFocus={() => setIsFocused(true)}
        onBlur={() => {
          setIsFocused(false);
          onBlur?.();
        }}
        placeholder={placeholder}
        maxLength={maxLength}
        min={min}
        max={max}
        className={clsx(
          'w-full border rounded-lg px-3 py-2 text-sm outline-none transition-all',
          error ? 'border-red-400 focus:ring-2 focus:ring-red-400 focus:border-transparent' : 'border-gray-200',
          !error && focusRing,
          inputClassName
        )}
      />
      {error && <span className="text-xs text-red-500">{error}</span>}
    </div>
  );
};
