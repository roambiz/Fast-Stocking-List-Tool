import React from 'react';
import { useStore } from '../../store';
import clsx from 'clsx';
import type { LucideIcon } from 'lucide-react';

interface PrimaryButtonProps {
  children: React.ReactNode;
  onClick: () => void;
  icon?: LucideIcon;
  className?: string;
  fullWidth?: boolean;
  disabled?: boolean;
  compact?: boolean;
  variant?: 'default' | 'danger';
}

export const PrimaryButton: React.FC<PrimaryButtonProps> = ({
  children,
  onClick,
  icon: Icon,
  className,
  fullWidth = true,
  disabled = false,
  compact = false,
  variant = 'default',
}) => {
  const { theme } = useStore();
  const isBlue = theme === 'blue';

  const defaultBaseClass = isBlue
    ? 'bg-blue-600 text-white border-blue-600 hover:bg-blue-700'
    : 'bg-zinc-900 text-white border-zinc-900 hover:bg-zinc-800';
  const dangerBaseClass = 'bg-red-500 text-white border-red-500 hover:bg-red-600';
  const baseClass = variant === 'danger' ? dangerBaseClass : defaultBaseClass;

  const paddingClass = compact ? 'px-4 py-2' : 'px-5 py-2.5';

  return (
    <button
      type="button"
      onClick={onClick}
      disabled={disabled}
      className={clsx(
        'border rounded-lg text-sm font-medium transition-colors flex items-center justify-center gap-2 shadow-sm',
        paddingClass,
        baseClass,
        fullWidth && 'w-full',
        disabled && 'opacity-50 cursor-not-allowed',
        className
      )}
    >
      {Icon != null && <Icon size={18} />}
      {children}
    </button>
  );
};
