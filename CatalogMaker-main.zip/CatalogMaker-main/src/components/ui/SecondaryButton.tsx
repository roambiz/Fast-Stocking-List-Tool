import React from 'react';
import { useStore } from '../../store';
import clsx from 'clsx';
import type { LucideIcon } from 'lucide-react';

interface SecondaryButtonProps {
  children: React.ReactNode;
  onClick: () => void;
  icon?: LucideIcon;
  className?: string;
  fullWidth?: boolean;
  variant?: 'default' | 'warning';
}

export const SecondaryButton: React.FC<SecondaryButtonProps> = ({
  children,
  onClick,
  icon: Icon,
  className,
  fullWidth = true,
  variant = 'default',
}) => {
  const { theme } = useStore();
  const isBlue = theme === 'blue';

  const focusRing = isBlue
    ? 'focus:ring-2 focus:ring-blue-500 focus:border-transparent'
    : 'focus:ring-2 focus:ring-zinc-800 focus:border-transparent';

  const defaultHoverClass = isBlue
    ? 'hover:bg-blue-50 hover:border-blue-300 hover:text-blue-600'
    : 'hover:bg-zinc-100 hover:border-zinc-400 hover:text-zinc-900';
  const warningClass = 'border-amber-200 text-amber-700 hover:bg-amber-50';
  const hoverClass = variant === 'warning' ? warningClass : defaultHoverClass;

  return (
    <button
      type="button"
      onClick={onClick}
      className={clsx(
        'bg-white border rounded-lg px-5 py-2.5 text-sm font-medium transition-colors shadow-sm flex items-center justify-center gap-2',
        variant === 'default' && 'border-gray-200 text-gray-700',
        variant === 'warning' && 'border-amber-200 text-amber-700',
        hoverClass,
        focusRing,
        fullWidth && 'w-full',
        className
      )}
    >
      {Icon != null && <Icon size={18} />}
      {children}
    </button>
  );
};
