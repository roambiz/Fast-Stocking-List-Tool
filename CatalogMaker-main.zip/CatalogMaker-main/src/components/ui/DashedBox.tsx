import React from 'react';
import clsx from 'clsx';

export interface DashedBoxProps {
  children: React.ReactNode;
  className?: string;
}

export const DashedBox: React.FC<DashedBoxProps> = ({ children, className }) => {
  return (
    <div
      className={clsx(
        'border-2 border-dashed border-gray-300 bg-gray-50 rounded-lg flex items-center justify-center',
        className
      )}
    >
      {children}
    </div>
  );
};
