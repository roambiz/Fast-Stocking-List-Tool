import React, { useEffect } from 'react';
import { createPortal } from 'react-dom';
import clsx from 'clsx';

export interface ModalProps {
  isOpen: boolean;
  onClose: () => void;
  children: React.ReactNode;
  maxWidth?: '2xl' | '4xl';
  /** 最大高度，超出可滚动 */
  maxHeight?: string;
  /** 固定高度，与 maxHeight 二选一；用于需要固定尺寸的弹窗（如封面 HTML 全屏编辑） */
  height?: string;
  closeOnOverlayClick?: boolean;
}

const MAX_WIDTH_MAP = {
  '2xl': 'max-w-2xl',
  '4xl': 'max-w-4xl',
};

export const Modal: React.FC<ModalProps> = ({
  isOpen,
  onClose,
  children,
  maxWidth = '2xl',
  maxHeight = '85vh',
  height,
  closeOnOverlayClick = true,
}) => {
  useEffect(() => {
    if (!isOpen) return;
    const handleEscape = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    document.addEventListener('keydown', handleEscape);
    return () => document.removeEventListener('keydown', handleEscape);
  }, [isOpen, onClose]);

  if (!isOpen || typeof document === 'undefined') return null;

  const overlayClass = 'fixed inset-0 z-[9999] flex items-center justify-center bg-black/50 p-4';
  const contentClass = clsx(
    'relative w-full flex flex-col bg-white rounded-xl shadow-2xl border border-gray-200 overflow-hidden',
    MAX_WIDTH_MAP[maxWidth]
  );

  const overlay = (
    <div
      className={overlayClass}
      onClick={closeOnOverlayClick ? onClose : undefined}
      role="dialog"
      aria-modal="true"
    >
      <div
        className={contentClass}
        style={height != null ? { height, maxHeight: height } : { maxHeight }}
        onClick={closeOnOverlayClick ? (e) => e.stopPropagation() : undefined}
      >
        {children}
      </div>
    </div>
  );

  return createPortal(overlay, document.body);
};
