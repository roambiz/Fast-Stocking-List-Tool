import React, { useEffect, useRef } from "react";
import { useTranslation } from "react-i18next";
import { useStore } from "../store";
import { Plus, FileText, Trash2, Blocks } from "lucide-react";
import clsx from "clsx";
import {
  DndContext,
  closestCenter,
  KeyboardSensor,
  PointerSensor,
  useSensor,
  useSensors,
  DragEndEvent,
} from "@dnd-kit/core";
import {
  SortableContext,
  sortableKeyboardCoordinates,
  horizontalListSortingStrategy,
  useSortable,
} from "@dnd-kit/sortable";
import { CSS } from "@dnd-kit/utilities";

interface SortableItemProps {
  id: string;
  index: number;
  isActive: boolean;
  onClick: () => void;
  onDelete: (e: React.MouseEvent) => void;
  theme: 'blue' | 'black';
  deleteTitle?: string;
}

const SortableItem: React.FC<SortableItemProps> = ({
  id,
  index,
  isActive,
  onClick,
  onDelete,
  theme,
  deleteTitle,
}) => {
  const { attributes, listeners, setNodeRef, transform, transition } =
    useSortable({ id });

  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
  };

  const isBlue = theme === 'blue';

  return (
    <div
      ref={setNodeRef}
      data-page-id={id}
      style={style}
      className={clsx(
        "h-24 w-16 bg-white rounded-lg border-2 flex flex-col items-center justify-center transition-all shrink-0 group relative cursor-grab active:cursor-grabbing",
        isActive
          ? (isBlue ? "border-blue-600 shadow-md ring-2 ring-blue-600 ring-offset-2" : "border-zinc-900 shadow-md ring-2 ring-zinc-900 ring-offset-2")
          : "border-gray-200 hover:border-gray-300 hover:shadow-sm",
      )}
    >
      <div
        {...attributes}
        {...listeners}
        onClick={onClick}
        className="absolute inset-0 flex flex-col items-center justify-center z-10"
      >
        <FileText
          size={20}
          strokeWidth={2.5}
          className={isActive ? (isBlue ? "text-blue-600" : "text-zinc-900") : "text-gray-400"}
        />
        <span className="text-xs font-medium mt-2 text-gray-500">
          {index + 1}
        </span>
      </div>

      <div className="absolute inset-0 bg-black/5 opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none rounded-lg" />

      <button
        onClick={onDelete}
        className="absolute -top-2 -right-2 bg-red-500 text-white rounded-full p-1 opacity-0 group-hover:opacity-100 transition-opacity hover:bg-red-600 shadow-sm z-20"
        title={deleteTitle}
      >
        <Trash2 size={14} strokeWidth={2.5} />
      </button>
    </div>
  );
};

export const Filmstrip: React.FC = () => {
  const { t } = useTranslation();
  const { pages, activePageId, setActivePage, addPage, addCoverPage, defaultSeriesId, reorderPages, deletePage, theme } =
    useStore();

  const isBlue = theme === 'blue';
  const canAddCover = defaultSeriesId === 'a4-standard' || defaultSeriesId === 'a3-standard';

  const addButtonFocusClass = isBlue ? "focus:outline-none focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:ring-blue-500" : "focus:outline-none focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:ring-zinc-800";
  const addButtonBaseClass = "h-24 w-16 bg-white rounded-lg border-2 flex flex-col items-center justify-center shrink-0 transition-all group";

  const sensors = useSensors(
    useSensor(PointerSensor, {
      activationConstraint: {
        distance: 5,
      },
    }),
    useSensor(KeyboardSensor, {
      coordinateGetter: sortableKeyboardCoordinates,
    }),
  );

  const handleDragEnd = (event: DragEndEvent) => {
    const { active, over } = event;

    if (over && active.id !== over.id) {
      const oldIndex = pages.findIndex((p) => p.id === active.id);
      const newIndex = pages.findIndex((p) => p.id === over.id);
      reorderPages(oldIndex, newIndex);
    }
  };

  const scrollContainerRef = useRef<HTMLDivElement>(null);
  useEffect(() => {
    if (!activePageId || !scrollContainerRef.current) return;
    const el = scrollContainerRef.current.querySelector(`[data-page-id="${activePageId}"]`);
    if (el instanceof HTMLElement) {
      el.scrollIntoView({ behavior: 'smooth', block: 'nearest', inline: 'center' });
    }
  }, [activePageId]);

  return (
    <div className="h-32 bg-white border-t border-gray-200 flex items-center relative shrink-0 z-10 w-full overflow-hidden">
      <div ref={scrollContainerRef} className="flex-1 overflow-x-auto overflow-y-hidden min-w-0 h-full flex items-center px-6 gap-6 pr-[220px]">
        <DndContext
          sensors={sensors}
          collisionDetection={closestCenter}
          onDragEnd={handleDragEnd}
        >
          <SortableContext
            items={pages.map((p) => p.id)}
            strategy={horizontalListSortingStrategy}
          >
            {pages.map((page, index) => (
              <SortableItem
                key={page.id}
                id={page.id}
                index={index}
                isActive={activePageId === page.id}
                onClick={() => setActivePage(page.id)}
                onDelete={(e) => {
                  e.stopPropagation();
                  deletePage(page.id);
                }}
                theme={theme}
                deleteTitle={t('filmstrip.deletePage')}
              />
            ))}
          </SortableContext>
        </DndContext>
      </div>

      <div className="absolute right-0 top-0 bottom-0 bg-white border-l border-gray-200 px-6 flex items-center gap-4 shrink-0 shadow-[-10px_0_15px_-5px_rgba(0,0,0,0.05)] z-20">
        <button
          onClick={() => addPage()}
          className={clsx(
            addButtonBaseClass,
            addButtonFocusClass,
            "border-gray-200 hover:border-gray-300 hover:shadow-sm cursor-pointer"
          )}
          title={t('filmstrip.addStandardPage')}
        >
          <Plus size={20} className="text-gray-400 group-hover:text-gray-600 transition-colors" />
          <span className="text-xs font-medium mt-2 text-gray-500 group-hover:text-gray-700 transition-colors">
            {t('filmstrip.newPage')}
          </span>
        </button>

        <button
          onClick={() => {
            if (canAddCover) {
              const pageSize = defaultSeriesId === 'a3-standard' ? 'A3' : 'A4';
              addCoverPage(pageSize);
            }
          }}
          disabled={!canAddCover}
          className={clsx(
            addButtonBaseClass,
            addButtonFocusClass,
            canAddCover
              ? "border-gray-200 hover:border-gray-300 hover:shadow-sm cursor-pointer"
              : "opacity-50 cursor-not-allowed border-gray-200",
          )}
          title={canAddCover ? t('filmstrip.addCover') : t('filmstrip.addCoverLocked')}
        >
          <Blocks size={20} className={clsx("transition-colors", canAddCover ? "text-gray-400 group-hover:text-gray-600" : "text-gray-300")} />
          <span className={clsx("text-xs font-medium mt-2 transition-colors", canAddCover ? "text-gray-500 group-hover:text-gray-700" : "text-gray-400")}>
            {t('filmstrip.addCover')}
          </span>
        </button>
      </div>
    </div>
  );
};
