import React from 'react';
import { useStore } from '../store';
import clsx from 'clsx';
import type { LucideIcon } from 'lucide-react';

interface SidebarButtonProps {
  onClick: () => void;
  children: React.ReactNode;
  icon?: LucideIcon;
  className?: string;
}

/**
 * 侧边栏统一次要按钮样式：白底、边框、灰字，与主题一致的 hover/focus。
 */
export const SidebarButton: React.FC<SidebarButtonProps> = ({ onClick, children, icon: Icon, className }) => {
  const { theme } = useStore();
  const isBlue = theme === 'blue';

  return (
    <button
      type="button"
      onClick={onClick}
      className={clsx(
        'w-full bg-white border border-gray-200 text-gray-700 rounded-lg px-5 py-2.5 text-sm font-medium hover:bg-gray-50 hover:border-gray-300 transition-colors shadow-sm flex items-center justify-center gap-2',
        isBlue ? 'focus:ring-2 focus:ring-blue-500 focus:border-transparent' : 'focus:ring-2 focus:ring-zinc-800 focus:border-transparent',
        className
      )}
    >
      {Icon != null && <Icon size={18} />}
      {children}
    </button>
  );
};
