import React from 'react';
import { useTranslation } from 'react-i18next';
import { useStore } from '../store';
import clsx from 'clsx';
import { PrimaryButton, SecondaryButton } from './ui';

export const ConfirmDialog: React.FC = () => {
  const { t } = useTranslation();
  const { confirmMessage, confirmOnConfirm, theme, setConfirmMessage } = useStore();

  if (confirmMessage == null) {
    return null;
  }

  const isBlue = theme === 'blue';

  const handleClose = () => {
    setConfirmMessage(null);
  };

  const handleConfirm = () => {
    if (confirmOnConfirm) {
      confirmOnConfirm();
    }
    handleClose();
  };

  const handleBackdropClick = (e: React.MouseEvent) => {
    if (e.target === e.currentTarget) {
      handleClose();
    }
  };

  return (
    <div
      className="fixed inset-0 z-[110] flex items-center justify-center bg-black/30"
      onClick={handleBackdropClick}
      role="alertdialog"
      aria-modal="true"
      aria-labelledby="confirm-message"
    >
      <div
        className={clsx(
          'min-w-[280px] max-w-[90vw] rounded-lg border bg-white p-5 shadow-xl',
          isBlue ? 'border-gray-200' : 'border-zinc-200'
        )}
        onClick={(e) => e.stopPropagation()}
      >
        <p id="confirm-message" className="mb-5 text-sm text-gray-800 whitespace-pre-wrap text-center">
          {confirmMessage}
        </p>
        <div className="flex justify-center gap-3">
          <SecondaryButton onClick={handleClose} fullWidth={false}>
            {t('common.cancel') ?? 'Cancel'}
          </SecondaryButton>
          <PrimaryButton onClick={handleConfirm} fullWidth={false}>
            {t('common.confirm')}
          </PrimaryButton>
        </div>
      </div>
    </div>
  );
};

