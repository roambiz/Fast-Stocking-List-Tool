import React from 'react';
import { useTranslation } from 'react-i18next';
import { Braces, Copy, Undo2, Eraser } from 'lucide-react';
import clsx from 'clsx';

export interface CoverHtmlToolbarProps {
  canUndo: boolean;
  onFormat: () => void;
  onCopy: () => void;
  onUndo: () => void;
  onClear: () => void;
  className?: string;
}

export const CoverHtmlToolbar: React.FC<CoverHtmlToolbarProps> = ({
  canUndo,
  onFormat,
  onCopy,
  onUndo,
  onClear,
  className,
}) => {
  const { t } = useTranslation();

  return (
    <div className={clsx('flex gap-1.5', className)}>
      <button
        type="button"
        onClick={onFormat}
        className="p-2 rounded border border-zinc-300 text-zinc-600 hover:bg-zinc-100 transition-colors"
        title={t('cellEditor.formatHtml')}
        aria-label={t('cellEditor.formatHtml')}
      >
        <Braces size={18} strokeWidth={2.5} />
      </button>
      <button
        type="button"
        onClick={onCopy}
        className="p-2 rounded border border-zinc-300 text-zinc-600 hover:bg-zinc-100 transition-colors"
        title={t('cellEditor.copyHtml')}
        aria-label={t('cellEditor.copyHtml')}
      >
        <Copy size={18} strokeWidth={2.5} />
      </button>
      <button
        type="button"
        onClick={onUndo}
        disabled={!canUndo}
        className={clsx(
          'p-2 rounded border transition-colors',
          canUndo
            ? 'border-zinc-300 text-zinc-600 hover:bg-zinc-100'
            : 'border-zinc-200 text-zinc-400 cursor-not-allowed'
        )}
        title={t('cellEditor.undo')}
        aria-label={t('cellEditor.undo')}
      >
        <Undo2 size={18} strokeWidth={2.5} />
      </button>
      <button
        type="button"
        onClick={onClear}
        className="p-2 rounded border border-amber-200 text-amber-700 hover:bg-amber-50 transition-colors"
        title={t('cellEditor.clearContent')}
        aria-label={t('cellEditor.clearContent')}
      >
        <Eraser size={18} strokeWidth={2.5} />
      </button>
    </div>
  );
};
