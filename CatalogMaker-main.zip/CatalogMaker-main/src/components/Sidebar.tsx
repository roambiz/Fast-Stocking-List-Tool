import React, { useRef, useState, useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import { useStore } from '../store';
import { readFileAsDataURL, compressAndCropLogoToBase64 } from '../utils/imageProcess';
import { Settings, Image as ImageIcon, LayoutGrid, Type, Hash, ChevronDown, ChevronRight, Eye, EyeOff, DollarSign, Tag, X, Smartphone, Globe, Mail, Check, Download, AlertCircle, Eraser, RotateCcw, PanelLeft, Search } from 'lucide-react';
import clsx from 'clsx';
import { allSeries } from '../presets';
import { BadgeColor, BADGE_COLOR_CLASSES, Item } from '../types';
import {
  Panel,
  TabBar,
  SegmentedControl,
  FormField,
  ToggleRow,
  PrimaryButton,
  SecondaryButton,
  HintCard,
} from './ui';
import { isCoverBlockPage } from '../utils/pageUtils';
import { isValidEmailFormat } from '../utils/emailFormat';
import { PDF_METADATA_LIMITS } from '../utils/pdfMetadata';

type Tab = 'batch' | 'presets' | 'global';

export const Sidebar: React.FC = () => {
  const { t } = useTranslation();
  const { globalConfig, defaultSeriesId, setDefaultSeriesId, updateGlobalConfig, addProducts, applyNumbering, batchFill, batchClear, activePageId, updatePageLayout, updateAllPagesLayout, pages, theme, showToast, showAlert, clearAll, showConfirm } = useStore();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [activeTab, setActiveTab] = useState<Tab>('batch');
  const [expandedSeries, setExpandedSeries] = useState<string[]>(['a4-standard']);

  const [uploadTarget, setUploadTarget] = useState<'all' | 'current'>('all');
  const [numberingTarget, setNumberingTarget] = useState<'all' | 'current'>('all');

  const [fillTarget, setFillTarget] = useState<'all' | 'current'>('all');
  const [fillData, setFillData] = useState<{ price: string; badge: string; badgeColor?: BadgeColor }>({ price: '', badge: '' });
  const [fieldErrors, setFieldErrors] = useState<{ email?: string; whatsapp?: string }>({});

  const validateEmail = (val: string) => {
    if (!val.trim()) { setFieldErrors(prev => ({ ...prev, email: undefined })); return; }
    if (!isValidEmailFormat(val)) setFieldErrors(prev => ({ ...prev, email: t('sidebar.validationEmailInvalid') }));
    else setFieldErrors(prev => ({ ...prev, email: undefined }));
  };
  const validateWhatsapp = (val: string) => {
    if (!val.trim()) { setFieldErrors(prev => ({ ...prev, whatsapp: undefined })); return; }
    const valid = /^[\d\s+()-]+$/.test(val) && val.replace(/\D/g, '').length >= 8;
    if (!valid) setFieldErrors(prev => ({ ...prev, whatsapp: t('sidebar.validationWhatsappInvalid') }));
    else setFieldErrors(prev => ({ ...prev, whatsapp: undefined }));
  };

  const FOOTER_CONTACT_LENGTH_THRESHOLD = 95;
  const footerSpaceWarnedRef = useRef(false);
  const numberPriceWarnedRef = useRef(false);
  const NUMBER_PRICE_LENGTH_THRESHOLD = 15;
  const PREFIX_NUMBER_MAX_LENGTH = 12;
  const NUMBER_DIGITS = 3;
  const checkPrefixNumberSpace = (prefixOverride?: string) => {
    const p = prefixOverride ?? globalConfig.prefix ?? '';
    if (p.length + NUMBER_DIGITS > PREFIX_NUMBER_MAX_LENGTH) {
      showToast(t('sidebar.toastPrefixNumberTooLong'), 'warning');
      return false;
    }
    return true;
  };
  const checkNumberPriceSpace = (prefixOverride?: string, priceOverride?: string) => {
    const p = prefixOverride ?? globalConfig.prefix ?? '';
    const price = priceOverride ?? fillData.price ?? '';
    const numberPartLen = p.length + NUMBER_DIGITS;
    const total = numberPartLen + price.length;
    if (total > NUMBER_PRICE_LENGTH_THRESHOLD) {
      if (!numberPriceWarnedRef.current) {
        numberPriceWarnedRef.current = true;
        showToast(t('sidebar.toastNumberPriceTooLong'), 'warning');
      }
    } else {
      numberPriceWarnedRef.current = false;
    }
  };
  const checkFooterSpace = (overrides?: { website?: string; email?: string; whatsapp?: string }) => {
    const w = overrides?.website ?? globalConfig.website ?? '';
    const e = overrides?.email ?? globalConfig.email ?? '';
    const wa = overrides?.whatsapp ?? globalConfig.whatsapp ?? '';
    const total = w.length + e.length + wa.length;
    if (total > FOOTER_CONTACT_LENGTH_THRESHOLD) {
      if (!footerSpaceWarnedRef.current) {
        footerSpaceWarnedRef.current = true;
        showToast(t('sidebar.toastFooterInsufficientSpace'), 'warning');
      }
    } else {
      footerSpaceWarnedRef.current = false;
    }
  };

  const activePage = pages.find(p => p.id === activePageId);
  const hasAnyStandardItems = pages.some(p => (!p.type || p.type === 'standard') && p.items.length > 0);
  const isBlue = theme === 'blue';

  useEffect(() => {
    numberPriceWarnedRef.current = false;
    footerSpaceWarnedRef.current = false;
  }, [defaultSeriesId, activePage?.layoutId]);

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files) return;

    try {
      const images = await Promise.all(Array.from(files).map(readFileAsDataURL));
      addProducts(images, uploadTarget, globalConfig.autoNumbering, defaultSeriesId);
    } catch {
      showToast(t('sidebar.toastImageUploadFailed'), 'warning');
    }
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const toggleSeries = (id: string) => {
    setExpandedSeries(prev =>
      prev.includes(id) ? prev.filter(s => s !== id) : [...prev, id]
    );
  };

  const tabs = [
    { id: 'batch', label: t('sidebar.tabBatch') },
    { id: 'presets', label: t('sidebar.tabPresets') },
    { id: 'global', label: t('sidebar.tabGlobal') },
  ];

  const isCoverActive = activePage != null && isCoverBlockPage(activePage);

  return (
    <aside className="w-80 bg-white border-r border-gray-200 h-full flex flex-col shrink-0 z-10">
      {isCoverActive ? (
        <div className="flex-1 overflow-y-auto p-6 bg-gray-50 flex">
          <HintCard
            icon={<PanelLeft size={48} strokeWidth={1.5} />}
            text={t('sidebar.coverModeHint')}
            className="w-full"
          />
        </div>
      ) : (
        <>
          <TabBar tabs={tabs} value={activeTab} onChange={(id) => setActiveTab(id as Tab)} />

          <div className="flex-1 overflow-y-auto p-6 bg-gray-50">
        {activeTab === 'batch' && (
          <div className="space-y-6">
            <Panel title={t('sidebar.batchUploadTitle')} icon={ImageIcon}>
              <div className="space-y-4 mb-5">
                <SegmentedControl
                  label={t('sidebar.fillTarget')}
                  options={[
                    { value: 'all', label: t('sidebar.allPages') },
                    { value: 'current', label: t('sidebar.currentPage') },
                  ]}
                  value={uploadTarget}
                  onChange={(v) => {
                    setUploadTarget(v as 'all' | 'current');
                    showToast(t('sidebar.toastSwitched'));
                  }}
                />

                <div className="flex flex-col gap-2">
                  <span className="text-xs font-medium text-gray-500 uppercase tracking-wider">{t('sidebar.defaultPreset')}</span>
                  <div className="rounded-lg border border-gray-200 bg-gray-50 p-1 grid grid-cols-2 gap-1">
                    <button
                      onClick={() => {
                        if (hasAnyStandardItems && defaultSeriesId !== 'a4-standard') {
                          showAlert(t('sidebar.alertCannotSwitchSeries'));
                          return;
                        }
                        if (defaultSeriesId !== 'a4-standard') {
                          setDefaultSeriesId('a4-standard');
                          showToast(t('sidebar.toastSwitched'));
                        }
                      }}
                      className={clsx(
                        'h-14 rounded-lg text-xs font-medium flex flex-col items-center justify-center transition-colors',
                        defaultSeriesId === 'a4-standard'
                          ? `bg-white shadow-sm ${isBlue ? 'text-blue-600' : 'text-zinc-900'}`
                          : 'text-gray-600 hover:text-gray-900'
                      )}
                    >
                      <span>{t('sidebar.presetA4Standard')}</span>
                    </button>
                    <button
                      onClick={() => {
                        if (hasAnyStandardItems && defaultSeriesId !== 'a3-standard') {
                          showAlert(t('sidebar.alertCannotSwitchSeries'));
                          return;
                        }
                        if (defaultSeriesId !== 'a3-standard') {
                          setDefaultSeriesId('a3-standard');
                          showToast(t('sidebar.toastSwitched'));
                        }
                      }}
                      className={clsx(
                        'h-14 rounded-lg text-xs font-medium flex flex-col items-center justify-center transition-colors',
                        defaultSeriesId === 'a3-standard'
                          ? `bg-white shadow-sm ${isBlue ? 'text-blue-600' : 'text-zinc-900'}`
                          : 'text-gray-600 hover:text-gray-900'
                      )}
                    >
                      <span>{t('sidebar.presetA3Horizontal')}</span>
                    </button>
                    <button
                      onClick={() => showAlert(t('sidebar.comingSoon') + ', ' + t('sidebar.comingSoonHint'))}
                      className="h-14 rounded-lg text-xs font-medium flex flex-col items-center justify-center text-gray-400 cursor-not-allowed"
                    >
                      <span>{"A4 - " + t('sidebar.comingSoon')}</span>
                      <span className="mt-0.5 text-[10px] text-gray-400">{t('sidebar.comingSoonHint')}</span>
                    </button>
                    <button
                      onClick={() => showAlert(t('sidebar.comingSoon') + ', ' + t('sidebar.comingSoonHint'))}
                      className="h-14 rounded-lg text-xs font-medium flex flex-col items-center justify-center text-gray-400 cursor-not-allowed"
                    >
                      <span>{"A3 - " + t('sidebar.comingSoon')}</span>
                      <span className="mt-0.5 text-[10px] text-gray-400">{t('sidebar.comingSoonHint')}</span>
                    </button>
                  </div>
                </div>
              </div>

              <input
                type="file"
                multiple
                accept="image/*"
                className="hidden"
                ref={fileInputRef}
                onChange={handleFileUpload}
              />
              <PrimaryButton onClick={() => fileInputRef.current?.click()} icon={ImageIcon}>
                {t('sidebar.uploadImages')}
              </PrimaryButton>
            </Panel>

            <Panel title={t('sidebar.numberingTitle')} icon={Hash}>
              <div className="space-y-4">
                <SegmentedControl
                  label={t('sidebar.fillTarget')}
                  options={[
                    { value: 'all', label: t('sidebar.allPages') },
                    { value: 'current', label: t('sidebar.currentPage') },
                  ]}
                  value={numberingTarget}
                  onChange={(v) => {
                    setNumberingTarget(v as 'all' | 'current');
                    showToast(t('sidebar.toastSwitched'));
                  }}
                />
                <FormField
                  label={t('sidebar.startNumber')}
                  type="number"
                  value={globalConfig.startNumber}
                  onChange={(val) => {
                    const num = typeof val === 'number' ? val : parseInt(String(val), 10) || 1;
                    const clamped = Math.max(1, Math.min(199, num));
                    updateGlobalConfig({ startNumber: clamped });
                  }}
                  min={1}
                  max={199}
                />
                <FormField
                  label={t('sidebar.prefix')}
                  type="text"
                  value={globalConfig.prefix}
                  onChange={(val) => {
                    const s = String(val);
                    if (s.length <= PREFIX_NUMBER_MAX_LENGTH - NUMBER_DIGITS) {
                      updateGlobalConfig({ prefix: s });
                    }
                    checkNumberPriceSpace(s);
                    checkPrefixNumberSpace(s);
                  }}
                  onBlur={() => {
                    checkNumberPriceSpace();
                    checkPrefixNumberSpace();
                  }}
                  maxLength={PREFIX_NUMBER_MAX_LENGTH - NUMBER_DIGITS}
                />
                <SecondaryButton onClick={() => applyNumbering(numberingTarget)} icon={Hash} className="mt-4">
                  {t('sidebar.applyNumbering')}
                </SecondaryButton>
                <SecondaryButton
                  onClick={() => {
                    batchClear(numberingTarget, 'number');
                    showToast(t('sidebar.toastNumberCleared'));
                  }}
                  icon={Eraser}
                  variant="warning"
                  className="mt-2"
                >
                  {t('sidebar.batchClearNumber')}
                </SecondaryButton>
              </div>
            </Panel>

            <Panel title={t('sidebar.multiFillTitle')} icon={Type}>
              <div className="space-y-4">
                <SegmentedControl
                  label={t('sidebar.fillTarget')}
                  options={[
                    { value: 'all', label: t('sidebar.allPages') },
                    { value: 'current', label: t('sidebar.currentPage') },
                  ]}
                  value={fillTarget}
                  onChange={(v) => {
                    setFillTarget(v as 'all' | 'current');
                    showToast(t('sidebar.toastSwitched'));
                  }}
                />
                <FormField
                  label={t('sidebar.price')}
                  icon={DollarSign}
                  type="text"
                  value={fillData.price}
                  onChange={(val) => {
                    const s = String(val);
                    setFillData({ ...fillData, price: s });
                    checkNumberPriceSpace(undefined, s);
                  }}
                  onBlur={() => checkNumberPriceSpace()}
                  placeholder={t('sidebar.placeholderPrice')}
                  maxLength={15}
                />
                <FormField
                  label={t('sidebar.badge')}
                  icon={Tag}
                  type="text"
                  value={fillData.badge}
                  onChange={(val) => setFillData({ ...fillData, badge: String(val) })}
                  placeholder={t('sidebar.placeholderBadge')}
                  maxLength={15}
                />
                <div className="flex flex-col gap-2">
                  <label className="text-xs font-medium text-gray-500 flex items-center gap-1">
                    <Tag size={14} /> {t('cellEditor.badgeColor')}
                  </label>
                  <div className="flex gap-2">
                    {(['blue', 'red', 'green', 'black'] as BadgeColor[]).map((c) => (
                      <button
                        key={c}
                        onClick={() => {
                          if ((fillData.badgeColor || 'blue') !== c) {
                            setFillData({ ...fillData, badgeColor: c });
                            showToast(t('sidebar.toastSwitched'));
                          }
                        }}
                        className={clsx(
                          'flex-1 h-8 rounded-lg font-medium text-white text-xs transition-all',
                          BADGE_COLOR_CLASSES[c],
                          (fillData.badgeColor || 'blue') === c
                            ? (isBlue ? 'ring-2 ring-offset-2 ring-blue-500 shadow-md' : 'ring-2 ring-offset-2 ring-zinc-800 shadow-md')
                            : 'opacity-80 hover:opacity-100'
                        )}
                        title={t(`cellEditor.badgeColor${c.charAt(0).toUpperCase() + c.slice(1)}`)}
                      >
                        {t(`cellEditor.badgeColor${c.charAt(0).toUpperCase() + c.slice(1)}`)}
                      </button>
                    ))}
                  </div>
                </div>
                <SecondaryButton
                  icon={Check}
                  onClick={() => {
                    if (fillData.price) checkNumberPriceSpace(undefined, fillData.price);
                    const dataToFill: Partial<Item> = {};
                    if (fillData.price) dataToFill.price = fillData.price;
                    if (fillData.badge) dataToFill.badge = fillData.badge;
                    if (fillData.badgeColor) dataToFill.badgeColor = fillData.badgeColor;
                    batchFill(dataToFill, fillTarget);
                  }}
                  className="mt-4"
                >
                  {t('sidebar.executeFill')}
                </SecondaryButton>
                <SecondaryButton
                  icon={Eraser}
                  onClick={() => {
                    batchClear(fillTarget, 'text');
                    showToast(t('sidebar.toastTextCleared'));
                  }}
                  variant="warning"
                  className="mt-2"
                >
                  {t('sidebar.batchClearText')}
                </SecondaryButton>
              </div>
            </Panel>

            <Panel title={t('sidebar.resetSectionTitle')} icon={RotateCcw}>
              <div className="space-y-3">
                <PrimaryButton
                  icon={RotateCcw}
                  variant="danger"
                  onClick={() => {
                    showConfirm(t('sidebar.resetAllConfirm'), () => {
                      clearAll();
                      showToast(t('sidebar.toastResetAll'));
                    });
                  }}
                >
                  {t('sidebar.resetAllButton')}
                </PrimaryButton>
              </div>
            </Panel>
          </div>
        )}

        {activeTab === 'presets' && (
          <div className="space-y-4">
            {allSeries.filter(series => series.id === defaultSeriesId).map(series => {
              const isExpanded = expandedSeries.includes(series.id);
              const activeLayout = allSeries.flatMap(s => s.layouts).find(l => l.id === activePage?.layoutId);
              const activeSeriesId = allSeries.find(s => s.layouts.some(l => l.id === activePage?.layoutId))?.id;
              const hasItems = (activePage?.items?.length || 0) > 0;
              const isLocked = hasItems;

              return (
                <div key={series.id} className={clsx("bg-white rounded-xl border overflow-hidden shadow-sm transition-opacity", isLocked && activeSeriesId !== series.id ? "opacity-50 border-gray-200" : "border-gray-200")}>
                  <button
                    onClick={() => toggleSeries(series.id)}
                    className="w-full flex items-center justify-between p-4 hover:bg-gray-50 transition-colors"
                  >
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-gray-900">{series.nameKey ? t(series.nameKey) : series.name}</span>
                      {isLocked && activeSeriesId !== series.id && <span className="text-xs bg-gray-100 text-gray-500 px-2 py-0.5 rounded">{t('sidebar.locked')}</span>}
                    </div>
                    {isExpanded ? <ChevronDown size={20} className="text-gray-500" /> : <ChevronRight size={20} className="text-gray-500" />}
                  </button>
                  {isExpanded && (
                    <div className="p-4 space-y-3 bg-gray-50 border-t border-gray-100">
                      {isLocked && activeSeriesId !== series.id && (
                        <div className="flex items-start gap-2 text-xs text-amber-600 bg-amber-50 p-2 rounded border border-amber-100 mb-3">
                          <AlertCircle size={16} className="shrink-0 mt-0.5" />
                          <span>{t('sidebar.alertLockedClearFirst')}</span>
                        </div>
                      )}
                      {series.layouts.map(layout => {
                        const isThisLayoutLocked = hasItems && activeSeriesId !== series.id;
                        return (
                          <button
                            key={layout.id}
                            onClick={() => {
                              if (isThisLayoutLocked) {
                                showAlert(t('sidebar.alertCannotSwitchOtherSeries'));
                                return;
                              }
                              if (activePageId) updatePageLayout(activePageId, layout.id);
                            }}
                            disabled={isThisLayoutLocked}
                            className={clsx(
                              "w-full text-left p-4 rounded-lg border transition-all",
                              activePage?.layoutId === layout.id
                                ? `${isBlue ? 'border-blue-500 bg-blue-50 ring-1 ring-blue-500' : 'border-zinc-800 bg-zinc-100 ring-1 ring-zinc-800'}`
                                : `border-gray-200 bg-white ${!isThisLayoutLocked ? (isBlue ? 'hover:border-blue-300 hover:shadow-sm' : 'hover:border-zinc-400 hover:shadow-sm') : 'cursor-not-allowed opacity-60'}`
                            )}
                          >
                            <div className="font-bold text-gray-900 text-sm">{layout.nameKey ? t(layout.nameKey) : layout.name}</div>
                            <div className="text-xs text-gray-500 mt-1">{layout.descriptionKey ? t(layout.descriptionKey) : layout.description}</div>
                          </button>
                        );
                      })}
                      {activeSeriesId === series.id && activeLayout && (
                        <SecondaryButton
                          icon={LayoutGrid}
                          onClick={() => {
                            showConfirm(t('sidebar.applyLayoutToAllConfirm'), () => {
                              updateAllPagesLayout(activeLayout.id);
                              showToast(t('sidebar.toastLayoutAppliedToAll'));
                            });
                          }}
                          className="mt-3 w-full"
                        >
                          {t('sidebar.applyLayoutToAll')}
                        </SecondaryButton>
                      )}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}

        {activeTab === 'global' && (
          <div className="space-y-6">
            <Panel title={t('sidebar.globalText')} icon={Settings}>
              <div className="space-y-4">
                <SegmentedControl
                  label={t('sidebar.layoutStyle')}
                  options={[
                    { value: 'standard', label: t('sidebar.layoutStyleStandard') },
                    { value: 'fashion', label: t('sidebar.layoutStyleFashion') },
                    { value: 'brand', label: t('sidebar.layoutStyleBrand') },
                  ]}
                  value={globalConfig.headerFooterStyle ?? 'standard'}
                  onChange={(v) => {
                    updateGlobalConfig({ headerFooterStyle: v as 'standard' | 'fashion' | 'brand' });
                    showToast(t('sidebar.toastSwitched'));
                  }}
                />
                <FormField
                  label={t('sidebar.headerLabel')}
                  type="text"
                  value={globalConfig.header}
                  onChange={(val) => updateGlobalConfig({ header: String(val) })}
                  maxLength={27}
                />
                <FormField
                  label={t('sidebar.footerLabel')}
                  type="text"
                  value={globalConfig.footer}
                  onChange={(val) => updateGlobalConfig({ footer: String(val) })}
                  maxLength={15}
                />
              </div>
            </Panel>

            <Panel title={t('sidebar.contact')} icon={Globe}>
              <div className="space-y-4">
                <FormField
                  label={t('sidebar.website')}
                  icon={Globe}
                  type="text"
                  value={globalConfig.website}
                  onChange={(val) => {
                    const s = String(val);
                    updateGlobalConfig({ website: s });
                    checkFooterSpace({ website: s });
                  }}
                  onBlur={() => checkFooterSpace()}
                  maxLength={50}
                />
                <FormField
                  label={t('sidebar.email')}
                  icon={Mail}
                  type="text"
                  value={globalConfig.email || ''}
                  onChange={(val) => {
                    const s = String(val);
                    updateGlobalConfig({ email: s });
                    if (fieldErrors.email) validateEmail(s);
                    checkFooterSpace({ email: s });
                  }}
                  onBlur={() => { validateEmail(globalConfig.email || ''); checkFooterSpace(); }}
                  placeholder={t('sidebar.placeholderEmail')}
                  maxLength={50}
                  error={fieldErrors.email}
                />
                <FormField
                  label={t('sidebar.whatsapp')}
                  icon={Smartphone}
                  type="text"
                  value={globalConfig.whatsapp || ''}
                  onChange={(val) => {
                    const s = String(val);
                    updateGlobalConfig({ whatsapp: s });
                    if (fieldErrors.whatsapp) validateWhatsapp(s);
                    checkFooterSpace({ whatsapp: s });
                  }}
                  onBlur={() => { validateWhatsapp(globalConfig.whatsapp || ''); checkFooterSpace(); }}
                  placeholder="+1 234 567 8900"
                  maxLength={18}
                  error={fieldErrors.whatsapp}
                />
              </div>
            </Panel>

            <Panel title={t('sidebar.brandLogo')} icon={ImageIcon}>
              <div className="space-y-4">
                {globalConfig.logo && (
                  <div className="relative w-full h-24 bg-gray-50 rounded-lg border border-gray-200 flex items-center justify-center p-2">
                    <img src={globalConfig.logo} alt="Logo" className="max-h-full max-w-full object-contain" />
                    <button
                      onClick={() => updateGlobalConfig({ logo: undefined })}
                      className="absolute -top-2 -right-2 bg-red-500 text-white rounded-full p-1 hover:bg-red-600 shadow-sm transition-colors"
                    >
                      <X size={14} />
                    </button>
                  </div>
                )}
                <input
                  type="file"
                  accept="image/*"
                  className="hidden"
                  id="logo-upload"
                  onChange={async (e) => {
                    const file = e.target.files?.[0];
                    if (!file) return;
                    try {
                      const base64 = await compressAndCropLogoToBase64(file);
                      updateGlobalConfig({ logo: base64 });
                    } catch {
                      showToast(t('sidebar.toastLogoUploadFailed'), 'warning');
                    }
                    e.target.value = '';
                  }}
                />
                <SecondaryButton
                  onClick={() => document.getElementById('logo-upload')?.click()}
                  icon={ImageIcon}
                >
                  {globalConfig.logo ? t('sidebar.replaceLogo') : t('sidebar.uploadLogo')}
                </SecondaryButton>
              </div>
            </Panel>

            <Panel title={t('sidebar.autoNumbering')} icon={Hash}>
              <div className="space-y-3">
                <ToggleRow
                  label={t('sidebar.autoNumberOnUpload')}
                  checked={globalConfig.autoNumbering}
                  onChange={() => {
                    updateGlobalConfig({ autoNumbering: !globalConfig.autoNumbering });
                    showToast(t('sidebar.toastSettingsSaved'));
                  }}
                />
              </div>
            </Panel>

            <Panel title={t('sidebar.searchOptimization')} icon={Search}>
              <div className="space-y-4">
                <ToggleRow
                  label={t('sidebar.pdfMetadataInjection')}
                  checked={globalConfig.pdfMetadataInjectionEnabled === true}
                  onChange={() => {
                    updateGlobalConfig({ pdfMetadataInjectionEnabled: !(globalConfig.pdfMetadataInjectionEnabled === true) });
                    showToast(t('sidebar.toastSettingsSaved'));
                  }}
                />
                {globalConfig.pdfMetadataInjectionEnabled === true && (
                  <div className="space-y-3">
                    <FormField
                      label={t('sidebar.pdfMetadataTitle')}
                      icon={Type}
                      value={globalConfig.pdfMetadataTitle ?? ''}
                      onChange={(val) => updateGlobalConfig({ pdfMetadataTitle: String(val) })}
                      onBlur={() => {
                        const raw = globalConfig.pdfMetadataTitle ?? '';
                        if (raw.length > 0 && raw.trim().length === 0) {
                          showToast(t('sidebar.pdfMetadataWhitespaceWarning'), 'warning');
                        }
                      }}
                      placeholder={t('sidebar.pdfMetadataTitlePlaceholder')}
                      maxLength={PDF_METADATA_LIMITS.title}
                    />
                    <FormField
                      label={t('sidebar.pdfMetadataSubject')}
                      icon={Type}
                      value={globalConfig.pdfMetadataSubject ?? ''}
                      onChange={(val) => updateGlobalConfig({ pdfMetadataSubject: String(val) })}
                      onBlur={() => {
                        const raw = globalConfig.pdfMetadataSubject ?? '';
                        if (raw.length > 0 && raw.trim().length === 0) {
                          showToast(t('sidebar.pdfMetadataWhitespaceWarning'), 'warning');
                        }
                      }}
                      placeholder={t('sidebar.pdfMetadataSubjectPlaceholder')}
                      maxLength={PDF_METADATA_LIMITS.subject}
                    />
                    <FormField
                      label={t('sidebar.pdfMetadataAuthor')}
                      icon={Type}
                      value={globalConfig.pdfMetadataAuthor ?? ''}
                      onChange={(val) => updateGlobalConfig({ pdfMetadataAuthor: String(val) })}
                      onBlur={() => {
                        const raw = globalConfig.pdfMetadataAuthor ?? '';
                        if (raw.length > 0 && raw.trim().length === 0) {
                          showToast(t('sidebar.pdfMetadataWhitespaceWarning'), 'warning');
                        }
                      }}
                      placeholder={t('sidebar.pdfMetadataAuthorPlaceholder')}
                      maxLength={PDF_METADATA_LIMITS.author}
                    />
                    <FormField
                      label={t('sidebar.pdfMetadataKeywords')}
                      icon={Type}
                      value={globalConfig.pdfMetadataKeywords ?? ''}
                      onChange={(val) => updateGlobalConfig({ pdfMetadataKeywords: String(val) })}
                      onBlur={() => {
                        const raw = globalConfig.pdfMetadataKeywords ?? '';
                        if (raw.length > 0 && raw.trim().length === 0) {
                          showToast(t('sidebar.pdfMetadataWhitespaceWarning'), 'warning');
                        }
                      }}
                      placeholder={t('sidebar.pdfMetadataKeywordsPlaceholder')}
                      maxLength={PDF_METADATA_LIMITS.keywords}
                    />
                  </div>
                )}
              </div>
            </Panel>

            <Panel title={t('sidebar.exportOptimization')} icon={Download}>
              <div className="space-y-4">
                <ToggleRow
                  label={t('sidebar.pdfCompressionEnabled')}
                  checked={globalConfig.pdfCompressionEnabled ?? true}
                  onChange={() => {
                    updateGlobalConfig({ pdfCompressionEnabled: !(globalConfig.pdfCompressionEnabled ?? true) });
                    showToast(t('sidebar.toastSettingsSaved'));
                  }}
                />
                {(globalConfig.pdfCompressionEnabled ?? true) && (
                  <>
                    <SegmentedControl
                      label={t('sidebar.pdfJpegQuality')}
                      options={[
                        { value: '0.97', label: t('sidebar.pdfJpegQualityStandard') },
                        { value: '0.88', label: t('sidebar.pdfJpegQualityUltimate') },
                      ]}
                      value={String(globalConfig.pdfJpegQuality ?? 0.97)}
                      onChange={(v) => {
                        updateGlobalConfig({ pdfJpegQuality: parseFloat(v) });
                        showToast(t('sidebar.toastSettingsSaved'));
                      }}
                    />
                    <SegmentedControl
                      label={t('sidebar.pdfStreamCompression')}
                      options={[
                        { value: 'FAST', label: t('sidebar.pdfStreamCompressionStandard') },
                        { value: 'SLOW', label: t('sidebar.pdfStreamCompressionUltimate') },
                      ]}
                      value={globalConfig.pdfStreamCompression ?? 'FAST'}
                      onChange={(v) => {
                        updateGlobalConfig({ pdfStreamCompression: v as 'FAST' | 'SLOW' });
                        showToast(t('sidebar.toastSettingsSaved'));
                      }}
                    />
                  </>
                )}
              </div>
            </Panel>

            <Panel title={t('sidebar.slotDisplay')} icon={LayoutGrid}>
              <div className="space-y-3">
                <ToggleRow
                  label={t('sidebar.showEmptySlots')}
                  checked={globalConfig.showEmptySlots}
                  onChange={() => {
                    updateGlobalConfig({ showEmptySlots: !globalConfig.showEmptySlots });
                    showToast(t('sidebar.toastSettingsSaved'));
                  }}
                  rightNode={globalConfig.showEmptySlots ? <Eye size={20} className={isBlue ? 'text-blue-500' : 'text-zinc-800'} /> : <EyeOff size={20} className="text-gray-400" />}
                />
              </div>
            </Panel>
          </div>
        )}
          </div>
        </>
      )}
    </aside>
  );
};
