import React, { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { useStore } from '../store';
import { Page, Item } from '../types';
import { ArrowUp, ArrowDown, Trash2, Eraser, Move, Globe, Mail } from 'lucide-react';
import clsx from 'clsx';
import { getLayoutById, getDefaultLayout } from '../presets';
import { IconButton, DashedBox } from './ui';
import { isCoverBlockPage, sanitizeCoverHtml, getCoverCurrentHtml } from '../utils/pageUtils';
import {
  DndContext,
  closestCenter,
  KeyboardSensor,
  PointerSensor,
  useSensor,
  useSensors,
  DragEndEvent,
} from "@dnd-kit/core";
import {
  SortableContext,
  sortableKeyboardCoordinates,
  rectSortingStrategy,
  useSortable,
} from "@dnd-kit/sortable";
import { CSS } from "@dnd-kit/utilities";

interface SortableItemWrapperProps {
  id: string;
  children: React.ReactNode;
  dragMode: boolean;
  theme: 'blue' | 'black';
}

const SortableItemWrapper: React.FC<SortableItemWrapperProps> = ({ id, children, dragMode, theme }) => {
  const { attributes, listeners, setNodeRef, transform, transition } = useSortable({ id, disabled: !dragMode });

  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
  };

  const ringClass = theme === 'black' ? 'ring-2 ring-zinc-800 ring-inset' : 'ring-2 ring-blue-500 ring-inset';

  return (
    <div ref={setNodeRef} style={style} {...(dragMode ? attributes : {})} {...(dragMode ? listeners : {})} className={clsx("h-full w-full", dragMode && `cursor-grab active:cursor-grabbing ${ringClass} z-50 shadow-lg rounded-lg`)}>
      {children}
    </div>
  );
};

interface PageRendererProps {
  page: Page;
  index: number;
  isActive: boolean;
}

export const PageRenderer: React.FC<PageRendererProps> = ({ page, index, isActive }) => {
  const { t } = useTranslation();
  const { globalConfig, theme, pages, movePage, deletePage, clearPage, setActivePage, setSelectedItem, reorderItems, isItemDragging, setIsItemDragging, previewMode } = useStore();
  const dragMode = isItemDragging && isActive;
  const setDragMode = setIsItemDragging;

  const layout = getLayoutById(page.layoutId) || getDefaultLayout();

  const sensors = useSensors(
    useSensor(PointerSensor, {
      activationConstraint: {
        distance: 5,
      },
    }),
    useSensor(KeyboardSensor, {
      coordinateGetter: sortableKeyboardCoordinates,
    }),
  );

  const handleDragEnd = (event: DragEndEvent) => {
    const { active, over } = event;

    if (over && active.id !== over.id) {
      const oldIndex = page.items.findIndex((item) => item.id === active.id);
      const newIndex = page.items.findIndex((item) => item.id === over.id);
      reorderItems(page.id, oldIndex, newIndex);
    }
  };

  const handleCellClick = (e: React.MouseEvent, item: Item) => {
    if (dragMode) return;
    e.stopPropagation();
    setActivePage(page.id);
    setSelectedItem(item.id);
  };

  const renderEmptySlots = () => {
    if (!globalConfig.showEmptySlots) return null;
    
    const currentUnits = page.items.length;
    const emptySlots = Math.max(0, layout.maxItems - currentUnits);
    
    return Array.from({ length: emptySlots }).map((_, i) => (
      <DashedBox key={`empty-${i}`} className="h-full w-full">
        <span className="text-gray-400 text-sm font-medium">{i + 1}</span>
      </DashedBox>
    ));
  };

  const isA4 = page.pageSize === 'A4';
  const pageDimensions = isA4 ? "w-[794px] h-[1123px]" : "w-[1587px] h-[1123px]";

  return (
    <div className="relative flex flex-col items-center">
      {/* Hover Toolbar */}
      {isActive && !previewMode && (
        <div className="absolute -top-14 left-1/2 -translate-x-1/2 bg-white rounded-lg shadow-lg border border-gray-200 px-2 py-1.5 flex items-center gap-1 z-30">
          <IconButton icon={ArrowUp} onClick={() => movePage(page.id, 'up')} title={t('canvas.moveUp')} ariaLabel={t('canvas.moveUp')} theme={theme} />
          <IconButton icon={ArrowDown} onClick={() => movePage(page.id, 'down')} title={t('canvas.moveDown')} ariaLabel={t('canvas.moveDown')} theme={theme} />
          {(page.type === 'standard' || !page.type) && (
            <>
              <div className="w-px h-6 bg-gray-200 mx-1" />
              <button
                onClick={() => setDragMode(!dragMode)}
                className={clsx("p-2 rounded transition-colors", dragMode ? "bg-blue-50 text-blue-600" : "hover:bg-gray-100 text-gray-700")}
                title={t('canvas.dragSort')}
                aria-label={t('canvas.dragSort')}
              >
                <Move size={18} strokeWidth={2.5} />
              </button>
              <div className="w-px h-6 bg-gray-200 mx-1" />
              <IconButton icon={Eraser} onClick={() => clearPage(page.id)} title={t('canvas.clearContent')} ariaLabel={t('canvas.clearContent')} theme={theme} />
            </>
          )}
          <div className="w-px h-6 bg-gray-200 mx-1" />
          <IconButton icon={Trash2} onClick={() => deletePage(page.id)} title={t('canvas.deletePage')} ariaLabel={t('canvas.deletePage')} variant="danger" theme={theme} />
        </div>
      )}

      {/* Page Container */}
      <div 
        onClick={() => { setActivePage(page.id); setSelectedItem(null); }}
        className={clsx(
          "pdf-page bg-white shadow-2xl flex flex-col transition-all cursor-default relative overflow-hidden",
          pageDimensions,
          isActive ? (theme === 'black' ? "ring-4 ring-zinc-800 ring-offset-4" : "ring-4 ring-blue-500 ring-offset-4") : ""
        )}
        style={{ padding: isA4 ? '40px' : '60px' }}
      >
        {/* Header */}
        {!isCoverBlockPage(page) && (
          globalConfig.headerFooterStyle === 'fashion' ? (
            <div className={clsx("flex flex-col items-center justify-center border-b-2 border-gray-900 pb-4 mb-6 shrink-0 z-10 relative bg-white gap-1", isA4 ? "min-h-[4rem]" : "min-h-[5rem]")}>
              <div className="flex flex-nowrap items-center gap-4 justify-center min-w-0 w-full">
                {globalConfig.logo && (
                  <img src={globalConfig.logo} alt="Logo" className={clsx("shrink-0 object-cover", isA4 ? "w-8 h-8" : "w-12 h-12")} />
                )}
                <div className={clsx("font-bold text-gray-900 text-center min-w-0 truncate", isA4 ? "text-2xl" : "text-4xl")}>{globalConfig.header}</div>
              </div>
              {page.headerSubtitle && (
                <div className={clsx("text-gray-500 font-medium", isA4 ? "text-sm" : "text-lg")}>{page.headerSubtitle}</div>
              )}
              <div className={clsx("font-bold text-gray-900", isA4 ? "text-sm" : "text-lg")}>{page.pageNumber != null && page.pageNumber !== '' ? page.pageNumber : `- ${index + 1}/${pages.length} -`}</div>
            </div>
          ) : globalConfig.headerFooterStyle === 'brand' ? (
            <div className={clsx("flex justify-between items-center border-b-2 border-gray-900 pb-4 mb-6 shrink-0 z-10 relative bg-white", isA4 ? "min-h-[4rem]" : "min-h-[5rem]")}>
              <div className="flex flex-col justify-center shrink-0 w-24">
                {globalConfig.logo && (
                  <img src={globalConfig.logo} alt="Logo" className={clsx("shrink-0 object-cover", isA4 ? "w-10 h-10" : "w-14 h-14")} />
                )}
              </div>
              <div className="flex-1 flex flex-col justify-center items-center min-w-0 px-2">
                <div className={clsx("font-bold text-gray-900 text-center min-w-0 truncate w-full", isA4 ? "text-2xl" : "text-4xl")}>{globalConfig.header}</div>
                {page.headerSubtitle && (
                  <div className={clsx("text-gray-500 font-medium", isA4 ? "text-sm" : "text-lg")}>{page.headerSubtitle}</div>
                )}
              </div>
              <div className={clsx("font-bold text-gray-900 shrink-0 w-24 flex justify-end", isA4 ? "text-sm" : "text-lg")}>{page.pageNumber != null && page.pageNumber !== '' ? page.pageNumber : `- ${index + 1}/${pages.length} -`}</div>
            </div>
          ) : (
            <div className={clsx("flex justify-between border-b-2 border-gray-900 pb-4 mb-6 shrink-0 z-10 relative bg-white", isA4 ? "min-h-[4rem]" : "min-h-[5rem]")}>
              <div className="flex flex-col justify-center w-1/3 min-w-0">
                <div className="flex flex-nowrap items-center gap-4 min-w-0">
                  {globalConfig.logo && (
                    <img src={globalConfig.logo} alt="Logo" className={clsx("shrink-0 object-cover", isA4 ? "w-8 h-8" : "w-12 h-12")} />
                  )}
                  <div className={clsx("font-bold text-gray-900 min-w-0 truncate", isA4 ? "text-2xl" : "text-4xl")}>{globalConfig.header}</div>
                </div>
              </div>
              <div className="w-1/3 flex flex-col justify-end items-center">
                {page.headerSubtitle && (
                  <div className={clsx("text-gray-500 font-medium", isA4 ? "text-sm" : "text-lg")}>{page.headerSubtitle}</div>
                )}
              </div>
              <div className={clsx("font-bold text-gray-900 w-1/3 flex flex-col justify-center items-end", isA4 ? "text-sm" : "text-lg")}>{page.pageNumber != null && page.pageNumber !== '' ? page.pageNumber : `- ${index + 1}/${pages.length} -`}</div>
            </div>
          )
        )}

        {/* Grid Content */}
        {isCoverBlockPage(page) ? (
          <div className="flex-1 w-full h-full relative z-10 overflow-hidden [&_img]:max-w-full [&_img]:max-h-full [&_img]:object-contain" dangerouslySetInnerHTML={{ __html: sanitizeCoverHtml(getCoverCurrentHtml(page)) }} />
        ) : (
          <DndContext
            sensors={sensors}
            collisionDetection={closestCenter}
            onDragEnd={handleDragEnd}
          >
            <SortableContext
              items={page.items.map(i => i.id)}
              strategy={rectSortingStrategy}
            >
              <div className={clsx("flex-1 grid z-10 relative min-h-0", layout.gridClassName)}>
                {page.items.map((item) => (
                  <SortableItemWrapper key={item.id} id={item.id} dragMode={dragMode} theme={theme}>
                    {layout.renderItem(item, false, handleCellClick, { ...globalConfig, imageFit: page.imageFit || 'cover', imagePadding: page.imagePadding ?? globalConfig.imagePadding, theme })}
                  </SortableItemWrapper>
                ))}
                {renderEmptySlots()}
              </div>
            </SortableContext>
          </DndContext>
        )}

        {/* Extra Page Content (like absolute subtitles) */}
        {!isCoverBlockPage(page) && layout.renderPageExtra && layout.renderPageExtra(page)}

        {/* Footer */}
        {!isCoverBlockPage(page) && (
          globalConfig.headerFooterStyle === 'fashion' ? (
            <div className="flex flex-col items-center justify-center border-t border-gray-200 pt-4 mt-6 shrink-0 text-gray-500 z-10 relative bg-white gap-2">
              <div className={clsx("flex items-center gap-4", isA4 ? "text-xs" : "text-sm")}>
                {globalConfig.website && (
                  <a href={globalConfig.website.startsWith('http') ? globalConfig.website : `https://${globalConfig.website}`} target="_blank" rel="noopener noreferrer" className="flex items-center gap-1.5 hover:text-gray-900 transition-colors lowercase">
                    <Globe size={16} strokeWidth={2.5} />
                    {globalConfig.website}
                  </a>
                )}
                {globalConfig.email && (
                  <a href={`mailto:${globalConfig.email}`} className="flex items-center gap-1.5 hover:text-gray-900 transition-colors lowercase">
                    <Mail size={16} strokeWidth={2.5} />
                    {globalConfig.email}
                  </a>
                )}
                {globalConfig.whatsapp && (
                  <a href={`https://wa.me/${globalConfig.whatsapp.replace(/[^\d+]/g, '')}`} target="_blank" rel="noopener noreferrer" className="flex items-center gap-1.5 hover:text-gray-900 transition-colors lowercase">
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><path d="M3 21l1.65-3.8a9 9 0 1 1 3.4 2.9L3 21"/><path d="M9 10a.5.5 0 0 0 1 0V9a.5.5 0 0 0-1 0v1a5 5 0 0 0 5 5h1a.5.5 0 0 0 0-1h-1a.5.5 0 0 0 0 1"/></svg>
                    {globalConfig.whatsapp}
                  </a>
                )}
              </div>
              <div className={clsx(isA4 ? "text-xs" : "text-sm")}>{globalConfig.footer}</div>
            </div>
          ) : globalConfig.headerFooterStyle === 'brand' ? (
            <div className="flex justify-between items-center border-t border-gray-200 pt-4 mt-6 shrink-0 text-gray-500 z-10 relative bg-white">
              <div className="flex items-center shrink-0">
                {globalConfig.logo ? (
                  <img src={globalConfig.logo} alt="Logo" className={clsx("object-cover", isA4 ? "w-6 h-6" : "w-8 h-8")} />
                ) : (
                  <span className={clsx(isA4 ? "text-xs" : "text-sm")}>{globalConfig.footer}</span>
                )}
              </div>
              <div className={clsx("flex items-center gap-4", isA4 ? "text-xs" : "text-sm")}>
                {globalConfig.website && (
                  <a href={globalConfig.website.startsWith('http') ? globalConfig.website : `https://${globalConfig.website}`} target="_blank" rel="noopener noreferrer" className="flex items-center gap-1.5 hover:text-gray-900 transition-colors lowercase">
                    <Globe size={16} strokeWidth={2.5} />
                    {globalConfig.website}
                  </a>
                )}
                {globalConfig.email && (
                  <a href={`mailto:${globalConfig.email}`} className="flex items-center gap-1.5 hover:text-gray-900 transition-colors lowercase">
                    <Mail size={16} strokeWidth={2.5} />
                    {globalConfig.email}
                  </a>
                )}
                {globalConfig.whatsapp && (
                  <a href={`https://wa.me/${globalConfig.whatsapp.replace(/[^\d+]/g, '')}`} target="_blank" rel="noopener noreferrer" className="flex items-center gap-1.5 hover:text-gray-900 transition-colors lowercase">
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><path d="M3 21l1.65-3.8a9 9 0 1 1 3.4 2.9L3 21"/><path d="M9 10a.5.5 0 0 0 1 0V9a.5.5 0 0 0-1 0v1a5 5 0 0 0 5 5h1a.5.5 0 0 0 0-1h-1a.5.5 0 0 0 0 1"/></svg>
                    {globalConfig.whatsapp}
                  </a>
                )}
              </div>
            </div>
          ) : (
            <div className="flex justify-between items-start border-t border-gray-200 pt-4 mt-6 shrink-0 text-gray-500 z-10 relative bg-white">
              <div className={clsx(isA4 ? "text-xs" : "text-sm")}>{globalConfig.footer}</div>
              <div className={clsx("flex items-center gap-4", isA4 ? "text-xs" : "text-sm")}>
                {globalConfig.website && (
                  <a href={globalConfig.website.startsWith('http') ? globalConfig.website : `https://${globalConfig.website}`} target="_blank" rel="noopener noreferrer" className="flex items-center gap-1.5 hover:text-gray-900 transition-colors lowercase">
                    <Globe size={16} strokeWidth={2.5} />
                    {globalConfig.website}
                  </a>
                )}
                {globalConfig.email && (
                  <a href={`mailto:${globalConfig.email}`} className="flex items-center gap-1.5 hover:text-gray-900 transition-colors lowercase">
                    <Mail size={16} strokeWidth={2.5} />
                    {globalConfig.email}
                  </a>
                )}
                {globalConfig.whatsapp && (
                  <a href={`https://wa.me/${globalConfig.whatsapp.replace(/[^\d+]/g, '')}`} target="_blank" rel="noopener noreferrer" className="flex items-center gap-1.5 hover:text-gray-900 transition-colors lowercase">
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><path d="M3 21l1.65-3.8a9 9 0 1 1 3.4 2.9L3 21"/><path d="M9 10a.5.5 0 0 0 1 0V9a.5.5 0 0 0-1 0v1a5 5 0 0 0 5 5h1a.5.5 0 0 0 0-1h-1a.5.5 0 0 0 0 1"/></svg>
                    {globalConfig.whatsapp}
                  </a>
                )}
              </div>
            </div>
          )
        )}
      </div>
    </div>
  );
};
