import React, { useState, useRef, useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import {
  Grid3X3,
  Eye,
  Edit3,
  Maximize2,
  FileJson,
  FolderOpen,
  Image,
  Archive,
  Loader2,
} from 'lucide-react';
import clsx from 'clsx';
import { useStore } from '../store';
import {
  buildSettingsExport,
  buildProjectExport,
  downloadJson,
} from '../utils/exportProject';
import { importSettings, importProject } from '../utils/importProject';
import { checkAndRecordExport } from '../utils/exportThrottle';
import { getPixelRatio } from '../utils/exportImageConfig';

const CORNER_GAP = 14;
const SCROLLBAR_OFFSET = 20;

export const CanvasControls: React.FC<{
  isFit: boolean;
  onToggleFit: () => void;
}> = ({ isFit, onToggleFit }) => {
  const { t } = useTranslation();
  const {
    pages,
    activePageId,
    projectName,
    globalConfig,
    defaultSeriesId,
    theme,
    showToast,
    showGrid,
    previewMode,
    setShowGrid,
    setPreviewMode,
    isExporting,
    setIsExporting,
  } = useStore();

  const [exportOpen, setExportOpen] = useState(false);
  const [busy, setBusy] = useState<'zip' | 'pdf' | null>(null);
  const [zipProgress, setZipProgress] = useState('');
  const exportRef = useRef<HTMLDivElement>(null);
  const settingsInputRef = useRef<HTMLInputElement>(null);
  const projectInputRef = useRef<HTMLInputElement>(null);
  const isBlue = theme === 'blue';

  useEffect(() => {
    if (!exportOpen) return;
    const onOutside = (e: MouseEvent) => {
      if (exportRef.current && !exportRef.current.contains(e.target as Node)) {
        setExportOpen(false);
      }
    };
    document.addEventListener('mousedown', onOutside);
    return () => document.removeEventListener('mousedown', onOutside);
  }, [exportOpen]);

  const baseBtn =
    'w-9 h-9 flex items-center justify-center rounded-lg border border-gray-200 bg-white text-gray-700 shadow-sm hover:bg-gray-50 transition-colors';

  const activeBtn = isBlue
    ? 'border-blue-500 bg-blue-50 text-blue-600'
    : 'border-zinc-800 bg-zinc-100 text-zinc-900';

  const disabledBtn = 'opacity-50 cursor-not-allowed';

  const handleExportSettings = () => {
    const data = buildSettingsExport(globalConfig, defaultSeriesId, theme);
    downloadJson(data, 'settings.json');
    showToast(t('importExport.toastSettingsExported'));
    setExportOpen(false);
  };

  const handleExportProject = () => {
    const data = buildProjectExport(projectName, pages, globalConfig, defaultSeriesId, theme);
    downloadJson(data, `${projectName || 'project'}.json`);
    showToast(t('importExport.toastProjectExported'));
    setExportOpen(false);
  };

  const handleExportPageJpg = async () => {
    if (!activePageId) {
      showToast(t('importExport.noPageSelected'), 'warning');
      setExportOpen(false);
      return;
    }
    const idx = pages.findIndex((p) => p.id === activePageId);
    const pageElements = document.querySelectorAll('.pdf-page');
    const el = pageElements[idx] as HTMLElement | undefined;
    if (!el) {
      showToast(t('importExport.exportFailed'), 'warning');
      setExportOpen(false);
      return;
    }
    setIsExporting(true);
    try {
      const htmlToImage = await import('html-to-image');
      await new Promise((r) => requestAnimationFrame(() => requestAnimationFrame(r)));
      const ot = el.style.transform;
      const ob = el.style.boxShadow;
      el.style.transform = 'none';
      el.style.boxShadow = 'none';
      const compressionEnabled = globalConfig.pdfCompressionEnabled ?? true;
      const pixelRatio = getPixelRatio(compressionEnabled);
      const baseOptions = {
        pixelRatio,
        backgroundColor: '#ffffff',
        cacheBust: true,
        style: { transform: 'none', boxShadow: 'none' },
      };
      let dataUrl: string;
      let ext: string;
      if (compressionEnabled) {
        const jpegQuality = globalConfig.pdfJpegQuality ?? 0.97;
        dataUrl = await htmlToImage.toJpeg(el, { ...baseOptions, quality: jpegQuality });
        ext = 'jpg';
      } else {
        dataUrl = await htmlToImage.toPng(el, baseOptions);
        ext = 'png';
      }
      el.style.transform = ot;
      el.style.boxShadow = ob;
      const link = document.createElement('a');
      link.href = dataUrl;
      link.download = `${projectName || 'page'}_page_${idx + 1}.${ext}`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      showToast(t('importExport.toastPageExported', { format: ext.toUpperCase() }));
    } catch {
      showToast(t('importExport.exportFailed'), 'warning');
    } finally {
      setIsExporting(false);
    }
    setExportOpen(false);
  };

  const handleExportZip = async () => {
    if (busy) return;
    if (!checkAndRecordExport()) {
      showToast(t('common.exportThrottled'), 'warning');
      setExportOpen(false);
      return;
    }
    setBusy('zip');
    setZipProgress('');
    setExportOpen(false);
    setIsExporting(true);
    try {
      const { exportAsZip } = await import('../utils/exportZip');
      await exportAsZip(projectName || 'catalog', setZipProgress, (msg) => showToast(msg, 'warning'));
      showToast(t('importExport.toastZipExported'));
    } catch {
      showToast(t('importExport.exportFailed'), 'warning');
    } finally {
      setBusy(null);
      setZipProgress('');
      setIsExporting(false);
    }
  };

  const validateJsonFile = (file: File): string | null => {
    const name = file.name.toLowerCase();
    if (name.endsWith('.zip')) return 'importExport.importZipHint';
    if (name.endsWith('.jpg') || name.endsWith('.jpeg') || name.endsWith('.png')) return 'importExport.importImageHint';
    if (!name.endsWith('.json')) return 'importExport.importJsonOnly';
    return null;
  };

  const onSettingsFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const extErr = validateJsonFile(file);
    if (extErr) {
      showToast(t(extErr), 'warning');
      e.target.value = '';
      setExportOpen(false);
      return;
    }
    const reader = new FileReader();
    reader.onload = () => {
      try {
        const data = JSON.parse(reader.result as string);
        const err = importSettings(data);
        if (err) showToast(t(err), 'warning');
        else showToast(t('importExport.toastSettingsImported'));
      } catch {
        showToast(t('importExport.importInvalid'), 'warning');
      }
      e.target.value = '';
    };
    reader.readAsText(file);
    setExportOpen(false);
  };

  const onProjectFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const extErr = validateJsonFile(file);
    if (extErr) {
      showToast(t(extErr), 'warning');
      e.target.value = '';
      setExportOpen(false);
      return;
    }
    const reader = new FileReader();
    reader.onload = () => {
      try {
        const data = JSON.parse(reader.result as string);
        const err = importProject(data);
        if (err) showToast(t(err), 'warning');
        else showToast(t('importExport.toastProjectImported'));
      } catch {
        showToast(t('importExport.importInvalid'), 'warning');
      }
      e.target.value = '';
    };
    reader.readAsText(file);
    setExportOpen(false);
  };

  const menuItemClass =
    'flex items-center gap-2 w-full px-3 py-2 text-left text-sm font-medium text-gray-700 rounded-lg transition-colors';

  return (
    <>
      {/* Top-left: Mode toggle */}
      <div
        className="absolute z-50 flex items-center gap-1"
        style={{ top: CORNER_GAP, left: CORNER_GAP }}
      >
        <button
          onClick={() => setPreviewMode(!previewMode)}
          className={clsx(
            baseBtn,
            previewMode && activeBtn
          )}
          title={previewMode ? t('canvas.previewOn') : t('canvas.previewOff')}
        >
          {previewMode ? <Eye size={14} /> : <Edit3 size={14} />}
        </button>
      </div>

      {/* Top-right: Export / Backup */}
      <div
        className="absolute z-50 flex items-center gap-1"
        style={{ top: CORNER_GAP, right: CORNER_GAP + SCROLLBAR_OFFSET }}
      >
        <div ref={exportRef} className="relative">
          <button
            onClick={() => setExportOpen(!exportOpen)}
            className={clsx(
              baseBtn,
              (exportOpen || busy || isExporting) && activeBtn,
              (busy || isExporting) && disabledBtn
            )}
            title={zipProgress || t('importExport.menuTitle')}
            disabled={!!busy || isExporting}
          >
            {busy === 'zip' ? (
              <Loader2 size={14} className="animate-spin" />
            ) : (
              <Archive size={14} />
            )}
          </button>
          {exportOpen && (
            <div
              className={clsx(
                'absolute top-full right-0 mt-1 w-64 py-2 z-[100]',
                'bg-white border border-gray-200 rounded-lg shadow-lg'
              )}
            >
              <div className="px-3 py-1.5">
                <div className="text-xs font-medium text-gray-500 uppercase tracking-wider mb-1">
                  {t('importExport.backupSectionTitle')}
                </div>
                <button
                  onClick={handleExportSettings}
                  className={clsx(
                    menuItemClass,
                    isBlue
                      ? 'hover:bg-blue-50 hover:text-blue-700'
                      : 'hover:bg-zinc-100 hover:text-zinc-900'
                  )}
                >
                  <FileJson size={14} />
                  {t('importExport.exportSettings')}
                </button>
                <button
                  onClick={handleExportProject}
                  className={clsx(
                    menuItemClass,
                    isBlue
                      ? 'hover:bg-blue-50 hover:text-blue-700'
                      : 'hover:bg-zinc-100 hover:text-zinc-900'
                  )}
                >
                  <FolderOpen size={14} />
                  {t('importExport.exportProject')}
                </button>
              </div>
              <div className="border-t border-slate-200 my-1" />
              <div className="px-3 py-1.5">
                <div className="text-xs font-medium text-gray-500 uppercase tracking-wider mb-1">
                  {t('importExport.importSectionTitle')}
                </div>
                <button
                  onClick={() => settingsInputRef.current?.click()}
                  className={clsx(
                    menuItemClass,
                    isBlue
                      ? 'hover:bg-blue-50 hover:text-blue-700'
                      : 'hover:bg-zinc-100 hover:text-zinc-900'
                  )}
                  title={t('importExport.importSettingsHint')}
                >
                  <FileJson size={14} />
                  {t('importExport.importSettings')}
                </button>
                <button
                  onClick={() => projectInputRef.current?.click()}
                  className={clsx(
                    menuItemClass,
                    isBlue
                      ? 'hover:bg-blue-50 hover:text-blue-700'
                      : 'hover:bg-zinc-100 hover:text-zinc-900'
                  )}
                  title={t('importExport.importProjectHint')}
                >
                  <FolderOpen size={14} />
                  {t('importExport.importProject')}
                </button>
              </div>
              <div className="border-t border-slate-200 my-1" />
              <div className="px-3 py-1.5">
                <div className="text-xs font-medium text-gray-500 uppercase tracking-wider mb-1">
                  {t('importExport.quickSectionTitle')}
                </div>
                <button
                  onClick={handleExportPageJpg}
                  title={t('importExport.exportPageJpgHint')}
                  className={clsx(
                    menuItemClass,
                    isBlue
                      ? 'hover:bg-blue-50 hover:text-blue-700'
                      : 'hover:bg-zinc-100 hover:text-zinc-900'
                  )}
                >
                  <Image size={14} />
                  {t('importExport.exportPageJpg')}
                </button>
                <button
                  onClick={handleExportZip}
                  disabled={!!busy}
                  title={t('importExport.exportZipHint')}
                  className={clsx(
                    menuItemClass,
                    busy && 'opacity-50',
                    isBlue
                      ? 'hover:bg-blue-50 hover:text-blue-700'
                      : 'hover:bg-zinc-100 hover:text-zinc-900'
                  )}
                >
                  <Archive size={14} />
                  {t('importExport.exportZip')}
                </button>
              </div>
            </div>
          )}
        </div>
      </div>

      <input
        ref={settingsInputRef}
        type="file"
        accept=".json"
        className="hidden"
        onChange={onSettingsFileChange}
      />
      <input
        ref={projectInputRef}
        type="file"
        accept=".json"
        className="hidden"
        onChange={onProjectFileChange}
      />

      {/* Bottom-left: Grid */}
      <div
        className="absolute z-50 flex items-center gap-1"
        style={{ bottom: CORNER_GAP, left: CORNER_GAP }}
      >
        <button
          onClick={() => setShowGrid(!showGrid)}
          className={clsx(baseBtn, showGrid && activeBtn)}
          title={t('canvas.grid')}
        >
          <Grid3X3 size={14} />
        </button>
      </div>

      {/* Bottom-right: Zoom / Fit toggle */}
      <div
        className="absolute z-50 flex items-center gap-1"
        style={{ bottom: CORNER_GAP, right: CORNER_GAP + SCROLLBAR_OFFSET }}
      >
        <button
          onClick={onToggleFit}
          className={clsx(baseBtn, isFit && activeBtn)}
          title={isFit ? t('canvas.fitOff') : t('canvas.fit')}
        >
          <Maximize2 size={14} />
        </button>
      </div>
    </>
  );
};
