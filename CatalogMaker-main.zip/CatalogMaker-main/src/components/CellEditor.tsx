import React, { useRef, useState, useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import { useStore } from '../store';
import { X, Image as ImageIcon, Type, Hash, Tag, AlignLeft, Edit3, Trash2, DollarSign, LayoutTemplate, Palette, Maximize, Minimize, Code, Copy, RotateCcw, RotateCw, Maximize2, Minimize2, PanelRight, Undo2, Download } from 'lucide-react';
import clsx from 'clsx';
import { getLayoutById, getDefaultLayout, getSeriesByLayoutId } from '../presets';
import { BadgeColor, BADGE_COLOR_CLASSES } from '../types';
import { Panel, TabBar, FormField, OptionCard, PrimaryButton, SecondaryButton, ToggleRow, SegmentedControl, Modal, HintCard, IconButton } from './ui';
import { CoverHtmlToolbar } from './CoverHtmlToolbar';
import { isCoverBlockPage, getDefaultCoverBlockHtml, HTML_CONTENT_MAX_LENGTH, getCoverCurrentHtml, getCoverActiveSlot, findItemInPages } from '../utils/pageUtils';
import { readFileAsDataURL } from '../utils/imageProcess';
import { rotateImage } from '../utils/imageRotate';
import { formatHtmlSimple } from '../utils/htmlFormat';

type Tab = 'card' | 'page';

const NUMBER_PRICE_LENGTH_THRESHOLD = 15;

export const CellEditor: React.FC = () => {
  const { t } = useTranslation();
  const { selectedItemId, activePageId, pages, updateItem, setSelectedItem, deleteItem, updatePageHeaderSubtitle, updatePageImageFit, updatePageImagePadding, updatePagePageNumber, updatePageHtml, setPageHtmlActiveSlot, theme, globalConfig, showAlert, showToast, showConfirm } = useStore();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const numberPriceWarnedRef = useRef(false);
  const [activeTab, setActiveTab] = useState<Tab>('card');
  const [descriptionFocused, setDescriptionFocused] = useState(false);
  const [coverHtmlCanUndo, setCoverHtmlCanUndo] = useState(false);
  const [coverHtmlExpanded, setCoverHtmlExpanded] = useState(false);
  const [rotateBusy, setRotateBusy] = useState(false);
  const coverHtmlUndoRef = useRef<string | null>(null);

  const activePage = pages.find(p => p.id === activePageId);

  useEffect(() => {
    numberPriceWarnedRef.current = false;
  }, [activePage?.layoutId, selectedItemId]);

  useEffect(() => {
    setCoverHtmlCanUndo(false);
    coverHtmlUndoRef.current = null;
  }, [activePageId, activePage?.htmlContentActiveSlot]);

  const checkNumberPriceSpace = (numberOverride?: string, priceOverride?: string) => {
    if (!selectedItem) return;
    const num = numberOverride ?? selectedItem.number ?? '';
    const price = priceOverride ?? selectedItem.price ?? '';
    const total = num.length + price.length;
    if (total > NUMBER_PRICE_LENGTH_THRESHOLD) {
      if (!numberPriceWarnedRef.current) {
        numberPriceWarnedRef.current = true;
        showToast(t('sidebar.toastNumberPriceTooLong'), 'warning');
      }
    } else {
      numberPriceWarnedRef.current = false;
    }
  };

  const layout = activePage ? (getLayoutById(activePage.layoutId) || getDefaultLayout()) : null;
  const isBlue = theme === 'blue';

  const selectedItem = findItemInPages(pages, selectedItemId);

  const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !selectedItemId) return;
    try {
      const dataUrl = await readFileAsDataURL(file);
      updateItem(selectedItemId, { image: dataUrl, imageOriginal: dataUrl });
    } catch {
      // 读取失败时静默忽略
    }
  };

  const handleRotate = async (direction: 'left' | 'right') => {
    if (!selectedItem?.image || !selectedItemId || rotateBusy) return;
    setRotateBusy(true);
    try {
      const result = await rotateImage(selectedItem.image, direction);
      updateItem(selectedItemId, { image: result });
      showToast(t('cellEditor.rotateImageToast'));
    } catch {
      showToast(t('cellEditor.rotateImageFailed'), 'warning');
    } finally {
      setRotateBusy(false);
    }
  };

  const handleRestoreOriginal = () => {
    if (!selectedItem || !selectedItemId) return;
    const original = selectedItem.imageOriginal;
    if (original == null || original === selectedItem.image) return;
    updateItem(selectedItemId, { image: original });
    showToast(t('cellEditor.restoreImageToast'));
  };

  const getImageFileExtension = (dataUrl: string): string => {
    const match = dataUrl.match(/^data:(image\/[a-zA-Z0-9.+-]+);/);
    const mime = match?.[1];
    if (mime === 'image/jpeg') return 'jpg';
    if (mime === 'image/png') return 'png';
    if (mime === 'image/webp') return 'webp';
    return 'png';
  };

  const downloadDataUrl = async (dataUrl: string, fileName: string) => {
    const resp = await fetch(dataUrl);
    const blob = await resp.blob();
    const url = URL.createObjectURL(blob);
    try {
      const a = document.createElement('a');
      a.href = url;
      a.download = fileName;
      document.body.appendChild(a);
      a.click();
      a.remove();
    } finally {
      URL.revokeObjectURL(url);
    }
  };

  const handleDownloadImage: React.MouseEventHandler<HTMLButtonElement> = async (e) => {
    if (!selectedItem || !selectedItemId) return;
    if (!selectedItem.image) return;
    if (rotateBusy) return;

    const dataUrl = selectedItem.image;

    const ext = getImageFileExtension(dataUrl);
    const fileName = `catalogmaker-${selectedItemId}.` + ext;

    try {
      await downloadDataUrl(dataUrl, fileName);
      showToast(t('cellEditor.downloadImageToast'));
    } catch {
      showToast(t('cellEditor.downloadImageFailed'), 'warning');
    }
  };

  if (!activePage) return null;

  const tabs = [
    { id: 'card', label: t('cellEditor.tabCard') },
    { id: 'page', label: t('cellEditor.tabPage') },
  ];

  const focusRing = isBlue ? 'focus:ring-2 focus:ring-blue-500 focus:border-transparent' : 'focus:ring-2 focus:ring-zinc-900 focus:border-transparent';

  return (
    <aside className="w-80 bg-white border-l border-gray-200 h-full flex flex-col shrink-0 z-20">
      <TabBar tabs={tabs} value={activeTab} onChange={(id) => setActiveTab(id as Tab)} />

      <div className="flex-1 overflow-y-auto p-6 bg-gray-50">
        {activeTab === 'card' && (
          selectedItem ? (
            <div className="space-y-6">
              <Panel
                title={t('cellEditor.editProduct')}
                icon={Edit3}
                action={
                  <button onClick={() => setSelectedItem(null)} className="p-1 text-gray-400 hover:text-gray-600 hover:bg-gray-100 rounded-full transition-colors">
                    <X size={18} />
                  </button>
                }
              >
                <div>
                  <label className="text-xs font-medium text-gray-500 mb-2 flex items-center gap-1">
                    <ImageIcon size={14} /> {t('cellEditor.image')}
                  </label>
                  <div className="flex flex-col gap-3">
                    {selectedItem.image ? (
                      <>
                        <div className="relative aspect-square w-full rounded-lg border border-gray-200 bg-gray-50 overflow-hidden group">
                          <img src={selectedItem.image} alt="Preview" className="w-full h-full object-cover" />
                          <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex flex-col items-center justify-center gap-2">
                            <SecondaryButton fullWidth={false} onClick={() => fileInputRef.current?.click()}>
                              {t('cellEditor.replace')}
                            </SecondaryButton>
                            <button onClick={() => updateItem(selectedItemId, { image: undefined, imageOriginal: undefined })} className="bg-red-500 text-white text-sm font-medium px-5 py-2.5 rounded-lg hover:bg-red-600 transition-colors shadow-sm flex items-center justify-center">
                              {t('cellEditor.remove')}
                            </button>
                          </div>
                        </div>
                        <div className="flex justify-center gap-1">
                          <IconButton
                            icon={RotateCcw}
                            onClick={rotateBusy ? () => {} : () => handleRotate('left')}
                            title={t('cellEditor.rotateLeft')}
                            ariaLabel={t('cellEditor.rotateLeft')}
                            theme={theme}
                            className={clsx(rotateBusy && 'opacity-50 cursor-not-allowed')}
                          />
                          <IconButton
                            icon={RotateCw}
                            onClick={rotateBusy ? () => {} : () => handleRotate('right')}
                            title={t('cellEditor.rotateRight')}
                            ariaLabel={t('cellEditor.rotateRight')}
                            theme={theme}
                            className={clsx(rotateBusy && 'opacity-50 cursor-not-allowed')}
                          />
                          <IconButton
                            icon={Undo2}
                            onClick={
                              rotateBusy || !selectedItem.imageOriginal || selectedItem.image === selectedItem.imageOriginal
                                ? () => {}
                                : handleRestoreOriginal
                            }
                            title={t('cellEditor.restoreImage')}
                            ariaLabel={t('cellEditor.restoreImage')}
                            theme={theme}
                            className={clsx(
                              (rotateBusy || !selectedItem.imageOriginal || selectedItem.image === selectedItem.imageOriginal) && 'opacity-50 cursor-not-allowed'
                            )}
                          />
                          <IconButton
                            icon={Download}
                            onClick={handleDownloadImage}
                            title={t('cellEditor.downloadImage')}
                            ariaLabel={t('cellEditor.downloadImage')}
                            theme={theme}
                            className={clsx(rotateBusy && 'opacity-50 cursor-not-allowed')}
                          />
                        </div>
                      </>
                    ) : (
                      <PrimaryButton fullWidth={true} onClick={() => fileInputRef.current?.click()} icon={ImageIcon}>
                        {t('cellEditor.uploadImage')}
                      </PrimaryButton>
                    )}
                    <input type="file" accept="image/*" className="hidden" ref={fileInputRef} onChange={handleImageUpload} />
                  </div>
                </div>
              </Panel>

              <Panel title={undefined}>
                <div className="space-y-4">
                  <FormField
                    label={t('cellEditor.number')}
                    icon={Hash}
                    type="text"
                    value={selectedItem.number || ''}
                    onChange={(val) => {
                      const s = String(val);
                      updateItem(selectedItemId, { number: s });
                      checkNumberPriceSpace(s, selectedItem.price);
                    }}
                    onBlur={() => checkNumberPriceSpace()}
                    placeholder={t('cellEditor.placeholderNumber')}
                    maxLength={15}
                  />
                  <FormField
                    label={t('cellEditor.price')}
                    icon={DollarSign}
                    type="text"
                    value={selectedItem.price || ''}
                    onChange={(val) => {
                      const s = String(val);
                      updateItem(selectedItemId, { price: s });
                      checkNumberPriceSpace(selectedItem.number, s);
                    }}
                    onBlur={() => checkNumberPriceSpace()}
                    placeholder={t('cellEditor.placeholderPrice')}
                    maxLength={15}
                  />
                  <FormField
                    label={t('cellEditor.badge')}
                    icon={Tag}
                    type="text"
                    value={selectedItem.badge || ''}
                    onChange={(val) => updateItem(selectedItemId, { badge: String(val).slice(0, 12) })}
                    placeholder={t('cellEditor.placeholderBadge')}
                    maxLength={12}
                  />
                  <div className="flex flex-col gap-2">
                    <label className="text-xs font-medium text-gray-500 flex items-center gap-1">
                      <Palette size={14} /> {t('cellEditor.badgeColor')}
                    </label>
                    <div className="flex gap-2">
                      {(['blue', 'red', 'green', 'black'] as BadgeColor[]).map((c) => (
                        <button
                          key={c}
                          onClick={() => {
                            if ((selectedItem.badgeColor || 'blue') !== c) {
                              updateItem(selectedItemId, { badgeColor: c });
                              showToast(t('sidebar.toastSwitched'));
                            }
                          }}
                          className={clsx(
                            'flex-1 h-9 rounded-lg font-medium text-white text-xs transition-all',
                            BADGE_COLOR_CLASSES[c],
                            (selectedItem.badgeColor || 'blue') === c
                              ? (isBlue ? 'ring-2 ring-offset-2 ring-blue-500 shadow-md scale-105' : 'ring-2 ring-offset-2 ring-zinc-800 shadow-md scale-105')
                              : 'opacity-80 hover:opacity-100'
                          )}
                          title={t(`cellEditor.badgeColor${c.charAt(0).toUpperCase() + c.slice(1)}`)}
                        >
                          {t(`cellEditor.badgeColor${c.charAt(0).toUpperCase() + c.slice(1)}`)}
                        </button>
                      ))}
                    </div>
                  </div>
                  {activePage.pageSize === 'A3' && (
                    <div className="flex flex-col gap-1">
                      <label className="text-xs font-medium text-gray-500 flex items-center justify-between gap-1">
                        <span className="flex items-center gap-1">
                          <AlignLeft size={14} /> {t('cellEditor.description')}
                        </span>
                        {descriptionFocused && (
                          <span className="font-mono text-gray-400 shrink-0">{(selectedItem.description || '').length} / 200</span>
                        )}
                      </label>
                      <textarea
                        value={selectedItem.description || ''}
                        onChange={(e) => {
                          let val = e.target.value;
                          const lines = val.split('\n').slice(0, 6);
                          val = lines.join('\n').slice(0, 200);
                          updateItem(selectedItemId, { description: val });
                        }}
                        onFocus={() => setDescriptionFocused(true)}
                        onBlur={() => setDescriptionFocused(false)}
                        rows={6}
                        className={clsx('w-full border border-gray-200 rounded-lg px-3 py-2 text-sm outline-none transition-all resize-none', focusRing)}
                        placeholder={
                          activePage?.layoutId === 'a3-v2'
                            ? t('cellEditor.placeholderDescriptionParams')
                            : activePage?.layoutId === 'a3-v3'
                            ? t('cellEditor.placeholderDescriptionHighlight')
                            : t('cellEditor.placeholderDescription')
                        }
                        maxLength={200}
                      />
                    </div>
                  )}
                </div>
              </Panel>

              <Panel title={undefined}>
                <button
                  onClick={() => deleteItem(selectedItemId)}
                  className="w-full bg-red-50 text-red-600 border border-red-200 rounded-lg px-5 py-2.5 text-sm font-medium hover:bg-red-600 hover:text-white hover:border-red-600 transition-colors flex items-center justify-center gap-2"
                >
                  <Trash2 size={16} /> {t('cellEditor.deleteItem')}
                </button>
              </Panel>
            </div>
          ) : (
            <HintCard
              icon={<PanelRight size={48} strokeWidth={1.5} />}
              text={t('cellEditor.selectCardHint')}
            />
          )
        )}

        {activeTab === 'page' && (
          <div className="space-y-6">
            {isCoverBlockPage(activePage) ? (
              <>
                {coverHtmlExpanded && (
                  <Modal
                    isOpen={true}
                    onClose={() => setCoverHtmlExpanded(false)}
                    maxWidth="4xl"
                    height="85vh"
                    closeOnOverlayClick={false}
                  >
                    <div className="flex items-center justify-between px-4 py-3 border-b border-gray-200">
                      <span className="text-sm font-medium text-gray-700">
                        {t('cellEditor.htmlCodeContainer')}
                      </span>
                      <span
                        className={clsx(
                          'text-xs font-mono tabular-nums',
                          getCoverCurrentHtml(activePage).length > HTML_CONTENT_MAX_LENGTH
                            ? 'text-amber-600'
                            : 'text-gray-500'
                        )}
                      >
                        {getCoverCurrentHtml(activePage).length} / {HTML_CONTENT_MAX_LENGTH}
                      </span>
                    </div>
                    <div className="flex-1 min-h-0 p-4">
                      <textarea
                        value={getCoverCurrentHtml(activePage)}
                        onChange={(e) => updatePageHtml(activePage.id, e.target.value)}
                        className={clsx(
                          'w-full h-full rounded-lg px-4 py-3 text-sm font-mono leading-relaxed resize-none bg-[#1e1e1e] text-[#d4d4d4] placeholder:text-zinc-500 border-2 border-blue-400/80 outline-none transition-all shadow-[0_0_0_3px_rgba(96,165,250,0.2)]',
                          focusRing
                        )}
                        placeholder={t('cellEditor.placeholderHtml')}
                        spellCheck={false}
                        autoFocus
                      />
                    </div>
                    <div className="flex items-center justify-between gap-4 px-4 py-3 border-t border-gray-200 bg-gray-50">
                      <CoverHtmlToolbar
                        canUndo={coverHtmlCanUndo}
                        onFormat={() => {
                          coverHtmlUndoRef.current = getCoverCurrentHtml(activePage);
                          setCoverHtmlCanUndo(true);
                          const formatted = formatHtmlSimple(getCoverCurrentHtml(activePage));
                          updatePageHtml(activePage.id, formatted);
                          showToast(t('cellEditor.formatComplete'));
                        }}
                        onCopy={() => {
                          const raw = getCoverCurrentHtml(activePage);
                          if (!raw) return;
                          navigator.clipboard.writeText(raw);
                          showToast(t('cellEditor.copyHtmlToast'));
                        }}
                        onUndo={() => {
                          if (coverHtmlUndoRef.current == null) return;
                          updatePageHtml(activePage.id, coverHtmlUndoRef.current);
                          coverHtmlUndoRef.current = null;
                          setCoverHtmlCanUndo(false);
                          showToast(t('cellEditor.undoComplete'));
                        }}
                        onClear={() => {
                          coverHtmlUndoRef.current = getCoverCurrentHtml(activePage);
                          setCoverHtmlCanUndo(true);
                          updatePageHtml(activePage.id, '');
                          showToast(t('cellEditor.clearContent'));
                        }}
                      />
                      <div className="flex-shrink-0 w-12 h-12 flex items-center justify-center bg-white rounded-lg border border-gray-200 shadow">
                        <button
                          type="button"
                          onClick={() => setCoverHtmlExpanded(false)}
                          className="w-full h-full flex items-center justify-center rounded-lg text-zinc-600 hover:bg-zinc-100 transition-colors"
                          title={t('cellEditor.collapseEditor')}
                          aria-label={t('cellEditor.collapseEditor')}
                        >
                          <Minimize2 size={22} strokeWidth={2.5} />
                        </button>
                      </div>
                    </div>
                  </Modal>
                )}
                <Panel title={t('cellEditor.coverHtmlTitle')} icon={Code}>
                  <SegmentedControl
                    options={[
                      { value: '0', label: t('cellEditor.coverSlot1') },
                      { value: '1', label: t('cellEditor.coverSlot2') },
                      { value: '2', label: t('cellEditor.coverSlot3') },
                    ]}
                    value={String(getCoverActiveSlot(activePage))}
                    onChange={(v) => setPageHtmlActiveSlot(activePage.id, Number(v) as 0 | 1 | 2)}
                  />
                  <div className="mt-3 flex items-center justify-between mb-1">
                    <span className="text-xs font-medium text-zinc-500">
                      {t('cellEditor.htmlCodeContainer')}
                    </span>
                    <span
                      className={clsx(
                        'text-[11px] font-mono tabular-nums',
                        getCoverCurrentHtml(activePage).length > HTML_CONTENT_MAX_LENGTH
                          ? 'text-amber-400'
                          : 'text-zinc-500'
                      )}
                    >
                      {getCoverCurrentHtml(activePage).length} / {HTML_CONTENT_MAX_LENGTH}
                    </span>
                  </div>
                  <div className="relative">
                    <textarea
                      value={getCoverCurrentHtml(activePage)}
                      onChange={(e) => updatePageHtml(activePage.id, e.target.value)}
                      className={clsx(
                        'w-full rounded-lg px-4 py-3 text-sm font-mono leading-relaxed outline-none transition-all min-h-[260px] resize-y bg-[#1e1e1e] text-[#d4d4d4] placeholder:text-zinc-500 border border-zinc-700 focus:border-zinc-500',
                        focusRing
                      )}
                      placeholder={t('cellEditor.placeholderHtml')}
                      spellCheck={false}
                    />
                  </div>
                  <div className="mt-2 flex justify-center gap-1.5 items-center">
                    <button
                      type="button"
                      onClick={() => setCoverHtmlExpanded(!coverHtmlExpanded)}
                      className="p-2 rounded border border-zinc-300 text-zinc-600 hover:bg-zinc-100 transition-colors"
                      title={coverHtmlExpanded ? t('cellEditor.collapseEditor') : t('cellEditor.expandEditor')}
                      aria-label={coverHtmlExpanded ? t('cellEditor.collapseEditor') : t('cellEditor.expandEditor')}
                    >
                      {coverHtmlExpanded ? (
                        <Minimize2 size={18} strokeWidth={2.5} />
                      ) : (
                        <Maximize2 size={18} strokeWidth={2.5} />
                      )}
                    </button>
                    <CoverHtmlToolbar
                      canUndo={coverHtmlCanUndo}
                      onFormat={() => {
                        coverHtmlUndoRef.current = getCoverCurrentHtml(activePage);
                        setCoverHtmlCanUndo(true);
                        const formatted = formatHtmlSimple(getCoverCurrentHtml(activePage));
                        updatePageHtml(activePage.id, formatted);
                        showToast(t('cellEditor.formatComplete'));
                      }}
                      onCopy={() => {
                        const raw = getCoverCurrentHtml(activePage);
                        if (!raw) return;
                        navigator.clipboard.writeText(raw);
                        showToast(t('cellEditor.copyHtmlToast'));
                      }}
                      onUndo={() => {
                        if (coverHtmlUndoRef.current == null) return;
                        updatePageHtml(activePage.id, coverHtmlUndoRef.current);
                        coverHtmlUndoRef.current = null;
                        setCoverHtmlCanUndo(false);
                        showToast(t('cellEditor.undoComplete'));
                      }}
                      onClear={() => {
                        coverHtmlUndoRef.current = getCoverCurrentHtml(activePage);
                        setCoverHtmlCanUndo(true);
                        updatePageHtml(activePage.id, '');
                        showToast(t('cellEditor.clearContent'));
                      }}
                    />
                  </div>
                </Panel>

                <Panel title={t('cellEditor.copyAiPromptTitle')} icon={Copy}>
                  <SecondaryButton
                    icon={Copy}
                    onClick={() => {
                      const prompt = t('cellEditor.aiPromptTemplate', { pageSize: activePage.pageSize });
                      navigator.clipboard.writeText(prompt);
                      showAlert(t('cellEditor.aiPromptCopied'));
                    }}
                    fullWidth
                  >
                    {t('cellEditor.copyAiPrompt')}
                  </SecondaryButton>
                </Panel>

                <Panel title={t('cellEditor.resetTitle')} icon={RotateCcw}>
                  <PrimaryButton
                    icon={RotateCcw}
                    variant="danger"
                    onClick={() => {
                      showConfirm(t('cellEditor.resetCoverConfirm'), () => {
                        updatePageHtml(activePage.id, getDefaultCoverBlockHtml());
                        showToast(t('cellEditor.resetToDefault'));
                      });
                    }}
                  >
                    {t('cellEditor.resetToDefault')}
                  </PrimaryButton>
                </Panel>
              </>
            ) : (
              <div className="space-y-6">
                <Panel title={t('cellEditor.currentLayout')} icon={LayoutTemplate}>
                  <div className="text-sm text-gray-700 p-3 bg-gray-50 rounded-lg border border-gray-200">
                    {(() => {
                      const series = getSeriesByLayoutId(activePage.layoutId);
                      const seriesName = series ? (series.nameKey ? t(series.nameKey) : series.name) : '';
                      const layoutName = layout ? (layout.nameKey ? t(layout.nameKey) : layout.name) : '';
                      return `${seriesName} - ${layoutName}`;
                    })()}
                  </div>
                </Panel>

                <Panel title={t('cellEditor.contentInput')} icon={Type}>
                  <div className="space-y-4">
                    <FormField
                      label={t('cellEditor.headerSubtitle')}
                      icon={Type}
                      type="text"
                      value={activePage.headerSubtitle || ''}
                      onChange={(val) => updatePageHeaderSubtitle(activePage.id, String(val))}
                      placeholder={t('cellEditor.placeholderHeaderSubtitle')}
                      maxLength={30}
                    />
                    <FormField
                      label={t('cellEditor.pageNumber')}
                      icon={Hash}
                      type="text"
                      value={activePage.pageNumber != null ? activePage.pageNumber : ''}
                      onChange={(val) => updatePagePageNumber(activePage.id, String(val))}
                      placeholder={t('cellEditor.placeholderPageNumber')}
                      maxLength={12}
                    />
                  </div>
                </Panel>

                <Panel title={t('cellEditor.imageDisplay')} icon={Palette}>
                  <div className="space-y-4">
                    <h3 className="text-xs font-bold text-gray-900 flex items-center gap-2">
                      {t('cellEditor.imageDisplayMode')}
                    </h3>
                    <div className="flex flex-col gap-2">
                      <OptionCard
                        icon={Maximize}
                        title={t('cellEditor.imageFitCover')}
                        description={t('cellEditor.imageFitCoverDesc')}
                        selected={!activePage.imageFit || activePage.imageFit === 'cover'}
                        onClick={() => updatePageImageFit(activePage.id, 'cover')}
                      />
                      <OptionCard
                        icon={Minimize}
                        title={t('cellEditor.imageFitContain')}
                        description={t('cellEditor.imageFitContainDesc')}
                        selected={activePage.imageFit === 'contain'}
                        onClick={() => updatePageImageFit(activePage.id, 'contain')}
                      />
                    </div>
                    <ToggleRow
                      label={t('sidebar.imagePadding')}
                      checked={activePage.imagePadding ?? globalConfig.imagePadding}
                      onChange={() => {
                        const next = !(activePage.imagePadding ?? globalConfig.imagePadding);
                        updatePageImagePadding(activePage.id, next);
                        showToast(t('sidebar.toastSettingsSaved'));
                      }}
                    />
                  </div>
                </Panel>
              </div>
            )}
          </div>
        )}
      </div>
    </aside>
  );
};
