import React, { useState, useRef, useCallback, useEffect } from "react";
import clsx from "clsx";
import { Lightbulb } from "lucide-react";
import { useTranslation } from "react-i18next";
import { useStore } from "../store";
import { PageRenderer } from "./PageRenderer";
import { CanvasControls } from "./CanvasControls";

export const MainCanvas: React.FC = () => {
  const { t } = useTranslation();
  const { pages, activePageId, showGrid } = useStore();
  const isEmptyProject =
    pages.length === 1 &&
    pages[0].items.length === 0 &&
    (!pages[0].type || pages[0].type === "standard");
  const [zoom, setZoom] = useState(1);
  const [isFit, setIsFit] = useState(false);
  const [prevZoom, setPrevZoom] = useState(1);
  const containerRef = useRef<HTMLDivElement>(null);
  const lastWheelZoomRef = useRef(0);

  const zoomIn = useCallback(() => setZoom((z) => Math.min(2, z + 0.25)), []);
  const zoomOut = useCallback(() => setZoom((z) => Math.max(0.25, z - 0.25)), []);

  const toggleFit = useCallback(() => {
    const el = containerRef.current;
    if (!el || pages.length === 0) return;
    if (!isFit) {
      // 记录当前缩放并适配屏幕
      setPrevZoom(zoom);
      const vw = el.clientWidth;
      const vh = el.clientHeight;
      const pad = 32;
      const pageEl = el.querySelector(".pdf-page") as HTMLElement | null;
      if (!pageEl) return;
      const pw = pageEl.offsetWidth;
      const ph = pageEl.offsetHeight;
      const gap = 48;
      const scaleW = (vw - pad * 2) / pw;
      const scaleH = (vh - pad * 2) / (pages.length * ph + (pages.length - 1) * gap);
      const s = Math.min(scaleW, scaleH, 2);
      setZoom(Math.max(0.25, s));
      setIsFit(true);
    } else {
      // 恢复到进入适配前的缩放
      setZoom(prevZoom || 1);
      setIsFit(false);
    }
  }, [isFit, pages.length, prevZoom, zoom]);

  const handleWheel = useCallback(
    (e: React.WheelEvent) => {
      if (!e.altKey) return;
      e.preventDefault();
      const now = Date.now();
      if (now - lastWheelZoomRef.current < 80) return;
      lastWheelZoomRef.current = now;
      if (e.deltaY < 0) zoomIn();
      else zoomOut();
    },
    [zoomIn, zoomOut]
  );

  const pagesOrderKey = pages.map((p) => p.id).join(',');

  useEffect(() => {
    if (!activePageId || !containerRef.current) return;
    const el = containerRef.current.querySelector(`[data-page-id="${activePageId}"]`);
    if (el instanceof HTMLElement) {
      el.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }
  }, [activePageId, pagesOrderKey]);

  return (
    <div className="flex-1 relative overflow-hidden flex flex-col bg-slate-200">
      <CanvasControls
        isFit={isFit}
        onToggleFit={toggleFit}
      />

      {/* Canvas Area - Alt+scroll to zoom */}
      <main
        ref={containerRef}
        onWheel={handleWheel}
        className={clsx(
          "flex-1 overflow-auto p-8 flex flex-col items-center gap-12 relative transition-all cursor-default select-none",
          showGrid && "bg-[linear-gradient(to_right,#94a3b8_1px,transparent_1px),linear-gradient(to_bottom,#94a3b8_1px,transparent_1px)] bg-[size:20px_20px]"
        )}
      >
        <div 
          className="flex flex-col items-center gap-12 origin-top transition-transform duration-200"
          style={{ transform: `scale(${zoom})` }}
        >
          {isEmptyProject && (
            <div className="flex items-center gap-3 text-center text-blue-700 text-sm font-medium bg-blue-50 rounded-lg border border-blue-200 px-6 py-4 shadow-sm">
              <Lightbulb size={20} className="shrink-0 text-blue-600" />
              <span>{t("canvas.emptyStateHint")}</span>
            </div>
          )}
          {pages.map((page, index) => (
            <div key={page.id} className="relative group pt-14" data-page-id={page.id} data-page-index={index}>
              <PageRenderer
                page={page}
                index={index}
                isActive={page.id === activePageId}
              />
            </div>
          ))}
        </div>
      </main>
    </div>
  );
};
