import React, { useEffect, useState, useRef } from 'react';
import { useStore } from '../store';
import clsx from 'clsx';

const SUCCESS_VISIBLE_MS = 1500;
const WARNING_VISIBLE_MS = 3000;
const FADE_MS = 300;

export const Toast: React.FC = () => {
  const { toastMessage, toastType, toastKey, setToastMessage } = useStore();
  const [visibleMessage, setVisibleMessage] = useState<string | null>(null);
  const [visibleType, setVisibleType] = useState<'success' | 'warning' | null>(null);
  const [isHiding, setIsHiding] = useState(false);
  const [hasSlidIn, setHasSlidIn] = useState(false);
  const [shouldShake, setShouldShake] = useState(false);
  const visibleTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const fadeTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => {
    if (toastMessage == null) {
      return;
    }
    if (visibleTimerRef.current) {
      clearTimeout(visibleTimerRef.current);
      visibleTimerRef.current = null;
    }
    if (fadeTimerRef.current) {
      clearTimeout(fadeTimerRef.current);
      fadeTimerRef.current = null;
    }
    const isWarning = (toastType ?? 'success') === 'warning';
    setVisibleMessage(toastMessage);
    setVisibleType(toastType ?? 'success');
    setIsHiding(false);
    setHasSlidIn(false);
    setShouldShake(isWarning);
    const slideInId = requestAnimationFrame(() => {
      requestAnimationFrame(() => setHasSlidIn(true));
    });
    const visibleMs = isWarning ? WARNING_VISIBLE_MS : SUCCESS_VISIBLE_MS;
    visibleTimerRef.current = setTimeout(() => {
      visibleTimerRef.current = null;
      setShouldShake(false);
      setIsHiding(true);
      fadeTimerRef.current = setTimeout(() => {
        fadeTimerRef.current = null;
        setToastMessage(null);
        setVisibleMessage(null);
        setVisibleType(null);
      }, FADE_MS);
    }, visibleMs);
    return () => {
      cancelAnimationFrame(slideInId);
      if (visibleTimerRef.current) clearTimeout(visibleTimerRef.current);
      if (fadeTimerRef.current) clearTimeout(fadeTimerRef.current);
    };
  }, [toastMessage, toastType, toastKey, setToastMessage]);

  if (visibleMessage == null) {
    return null;
  }

  return (
    <div
      className="fixed top-0 left-0 right-0 h-16 flex items-center justify-center pointer-events-none z-50"
      aria-live="polite"
    >
      <div
        className={clsx(
          'px-4 py-2.5 rounded-lg border shadow-md text-sm font-medium transition-all duration-300 ease-out',
          visibleType === 'warning'
            ? 'border-amber-200 bg-amber-50 text-amber-800'
            : 'border-green-200 bg-green-50 text-green-800',
          hasSlidIn ? 'translate-y-0 opacity-100' : '-translate-y-8 opacity-0',
          isHiding && 'opacity-0',
          shouldShake && 'animate-toast-shake'
        )}
      >
        {visibleMessage}
      </div>
    </div>
  );
};
