# Create GitHub Release v1.2.0 and upload dist + dev zips.
# Prerequisite: $env:GITHUB_TOKEN = "<your-token>"
# Run from repo root: .\scripts\create-release-v1.2.0.ps1

$ErrorActionPreference = "Stop"
$repo = "roambiz/CatalogMaker"
$tag = "v1.2.0"
$distZip = "catalogmaker-v1.2.0-dist.zip"
$devZip = "catalogmaker-v1.2.0-dev.zip"

if (-not $env:GITHUB_TOKEN) {
  Write-Error "Set GITHUB_TOKEN first: `$env:GITHUB_TOKEN = '<your-token>'"
}

$headers = @{
  Authorization = "token $env:GITHUB_TOKEN"
  "Content-Type" = "application/json"
}

# Create release
$body = @{
  tag_name = $tag
  name = "CatalogMaker v1.2.0 稳定版"
  body = "## 稳定版发布`n`nv1.2.0 更新: PDF 检索优化（PDF 元数据注入）、全局设置检索优化区块`n`n- 部署包 (catalogmaker-v1.2.0-dist.zip): 仅包含 dist，用于生产部署`n- 开发包 (catalogmaker-v1.2.0-dev.zip): 源码包，已排除 docs、.cursor、node_modules、dist 及所有 .md 文件"
} | ConvertTo-Json

$release = Invoke-RestMethod -Uri "https://api.github.com/repos/$repo/releases" -Method Post -Headers $headers -Body $body
$releaseId = $release.id
Write-Host "Release created: $releaseId"

# Upload assets
$uploadHeaders = @{
  Authorization = "token $env:GITHUB_TOKEN"
  "Content-Type" = "application/zip"
}

foreach ($zip in $distZip, $devZip) {
  if (-not (Test-Path $zip)) {
    Write-Warning "Skip $zip (not found). Run build and create zips first."
    continue
  }
  $bytes = [System.IO.File]::ReadAllBytes((Resolve-Path $zip))
  $uri = "https://uploads.github.com/repos/$repo/releases/$releaseId/assets?name=$zip"
  Invoke-RestMethod -Uri $uri -Method Post -Headers $uploadHeaders -Body $bytes
  Write-Host "Uploaded: $zip"
}
Write-Host "Done. See https://github.com/$repo/releases/tag/$tag"
