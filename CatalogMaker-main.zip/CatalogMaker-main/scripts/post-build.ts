/**
 * 打包后生成 config.json、ai.txt、.htaccess、robots.txt、sitemap.xml
 * 并注入 index.html 的 canonical、og、twitter meta
 * 在 Vite closeBundle 时调用
 */
import { readFileSync, writeFileSync, existsSync } from 'fs';
import { join } from 'path';
import { fileURLToPath } from 'url';

const __dirname = fileURLToPath(new URL('.', import.meta.url));
const root = join(__dirname, '..');
const distDir = join(root, 'dist');

// 从 package.json 读取版本
function getVersion(): string {
  const pkgPath = join(root, 'package.json');
  const pkg = JSON.parse(readFileSync(pkgPath, 'utf-8'));
  return pkg.version ?? '0.0.0';
}

function generateConfig(siteUrl: string): void {
  const version = getVersion();
  const buildTime = new Date().toISOString();

  const config = {
    name: {
      en: 'CatalogMaker',
      zh: '目录生成器',
    },
    version,
    buildTime,
    product: 'CatalogMaker',
    siteUrl,
  };

  const outputPath = join(distDir, 'config.json');
  writeFileSync(outputPath, JSON.stringify(config, null, 2), 'utf-8');
}

function generateAiTxt(): void {
  const buildDate = new Date().toISOString().slice(0, 10);

  const content = `---
updated: ${buildDate}
scope: /
---

# CatalogMaker | 目录生成器

在线产品目录设计工具。支持 A4/A3 多款预设布局，批量上传图片、自动编号、封面设计，一键导出 PDF，轻松制作专业产品目录。

## 功能

- 多款预设布局（A4/A3）
- 批量上传与自动编号
- 封面设计与 PDF 导出

## 使用对象

面向需要制作产品目录的企业、设计师、销售人员。

## 请勿滥用

请勿自动化批量调用 PDF 导出或 ZIP 导出功能。导出为本地计算，过度自动化会增加带宽与资源消耗。尊重合理使用，避免爬虫或自动化工具频繁触发导出。
`;

  const path = join(distDir, 'ai.txt');
  writeFileSync(path, content, 'utf-8');
}

function generateHtaccess(): void {
  const content = `# CatalogMaker - 目录生成器
# Apache 服务器配置，上传到网站根目录

<IfModule mod_rewrite.c>
  RewriteEngine On
  RewriteBase /
  RewriteRule ^index\\.html$ - [L]
  RewriteCond %{REQUEST_FILENAME} !-f
  RewriteCond %{REQUEST_FILENAME} !-d
  RewriteRule . /index.html [L]
</IfModule>

# 静态资源长期缓存（带 hash 的 JS/CSS）
<IfModule mod_headers.c>
  <FilesMatch "\\.(js|css)$">
    Header set Cache-Control "public, max-age=31536000, immutable"
  </FilesMatch>
</IfModule>

# 安全响应头
<IfModule mod_headers.c>
  Header set X-Frame-Options "SAMEORIGIN"
  Header set X-Content-Type-Options "nosniff"
  Header set Referrer-Policy "strict-origin-when-cross-origin"
</IfModule>
`;

  const outputPath = join(distDir, '.htaccess');
  writeFileSync(outputPath, content, 'utf-8');
}

function generateRobotsTxt(siteUrl: string): void {
  const content = `User-agent: *
Allow: /

Sitemap: ${siteUrl}/sitemap.xml
`;

  const outputPath = join(distDir, 'robots.txt');
  writeFileSync(outputPath, content, 'utf-8');
}

function generateSitemap(siteUrl: string): void {
  const buildDate = new Date().toISOString().slice(0, 10);

  const content = `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
  <url>
    <loc>${siteUrl}/</loc>
    <lastmod>${buildDate}</lastmod>
    <changefreq>monthly</changefreq>
    <priority>1.0</priority>
  </url>
</urlset>
`;

  const outputPath = join(distDir, 'sitemap.xml');
  writeFileSync(outputPath, content, 'utf-8');
}

const OG_TITLE = 'CatalogMaker - 目录生成器 | 在线产品目录设计工具';
const OG_DESCRIPTION =
  'CatalogMaker（目录生成器）—— 在线产品目录设计工具，支持 A4/A3 布局、批量上传、自动编号、封面设计，一键导出 PDF，轻松制作专业产品目录。';

function injectIndexMeta(siteUrl: string): void {
  const indexPath = join(distDir, 'index.html');
  if (!existsSync(indexPath)) {
    return;
  }

  let html = readFileSync(indexPath, 'utf-8');

  const metaBlock = `    <link rel="canonical" href="${siteUrl}/" />
    <meta property="og:title" content="${OG_TITLE}" />
    <meta property="og:description" content="${OG_DESCRIPTION}" />
    <meta property="og:url" content="${siteUrl}/" />
    <meta property="og:type" content="website" />
    <meta name="twitter:card" content="summary" />
    <meta name="twitter:title" content="${OG_TITLE}" />
`;

  const insertBefore = '</head>';
  if (html.includes(insertBefore) && !html.includes('rel="canonical"')) {
    html = html.replace(insertBefore, `${metaBlock}  ${insertBefore}`);
  }

  writeFileSync(indexPath, html, 'utf-8');
}

export interface PostBuildOptions {
  siteUrl?: string;
}

export function runPostBuild(options?: PostBuildOptions): void {
  if (!existsSync(distDir)) {
    return;
  }

  const siteUrl = options?.siteUrl ?? process.env.SITE_URL ?? 'https://catalog-maker.roambiz.com';

  generateConfig(siteUrl);
  generateAiTxt();
  generateHtaccess();
  generateRobotsTxt(siteUrl);
  generateSitemap(siteUrl);
  injectIndexMeta(siteUrl);
}
