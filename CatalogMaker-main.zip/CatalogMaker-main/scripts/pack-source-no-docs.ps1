# 普通打包：排除文档（docs/、*.md、.cursor/rules），归档来自 Git 已提交内容
# 在项目根执行: .\scripts\pack-source-no-docs.ps1
$ErrorActionPreference = "Stop"
$root = Split-Path $PSScriptRoot -Parent
Set-Location $root
$out = Join-Path $root "catalogmaker-source-no-docs.zip"
git archive -o $out HEAD ":(exclude)docs" ":(exclude)*.md" ":(exclude).cursor/rules"
Write-Host "Created: $out"
