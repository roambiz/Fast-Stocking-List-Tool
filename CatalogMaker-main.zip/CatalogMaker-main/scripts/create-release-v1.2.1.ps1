# Create GitHub Release v1.2.1 and upload dist + dev zips.
# Prerequisite: $env:GITHUB_TOKEN = "<your-token>"
# Run from repo root: .\scripts\create-release-v1.2.1.ps1

$ErrorActionPreference = "Stop"
$repo = "roambiz/CatalogMaker"
$tag = "v1.2.1"
$distZip = "catalogmaker-v1.2.1-dist.zip"
$devZip = "catalogmaker-v1.2.1-dev.zip"

if (-not $env:GITHUB_TOKEN) {
  Write-Error "Set GITHUB_TOKEN first: `$env:GITHUB_TOKEN = '<your-token>'"
}

$headers = @{
  Authorization = "token $env:GITHUB_TOKEN"
  "Content-Type" = "application/json"
}

# Create release
$body = @{
  tag_name = $tag
  name = "CatalogMaker v1.2.1"
  body = "## 发布`n`nv1.2.1：检索优化区文案精简、PDF 元数据字段长度收紧（标题/作者 32、主题 128、关键词 512）、使用指南 v1.2.1`n`n- 部署包 (catalogmaker-v1.2.1-dist.zip): 仅包含 dist，用于生产部署`n- 开发包 (catalogmaker-v1.2.1-dev.zip): 源码包，已排除 docs、.cursor、node_modules、dist 及所有 .md 文件"
} | ConvertTo-Json

$release = Invoke-RestMethod -Uri "https://api.github.com/repos/$repo/releases" -Method Post -Headers $headers -Body $body
$releaseId = $release.id
Write-Host "Release created: $releaseId"

# Upload assets
$uploadHeaders = @{
  Authorization = "token $env:GITHUB_TOKEN"
  "Content-Type" = "application/zip"
}

foreach ($zip in $distZip, $devZip) {
  if (-not (Test-Path $zip)) {
    Write-Warning "Skip $zip (not found). Run build and create zips first."
    continue
  }
  $bytes = [System.IO.File]::ReadAllBytes((Resolve-Path $zip))
  $uri = "https://uploads.github.com/repos/$repo/releases/$releaseId/assets?name=$zip"
  Invoke-RestMethod -Uri $uri -Method Post -Headers $uploadHeaders -Body $bytes
  Write-Host "Uploaded: $zip"
}
Write-Host "Done. See https://github.com/$repo/releases/tag/$tag"
