# CatalogMaker | 目录生成器

在线产品目录设计工具。支持 A4/A3 多款预设布局，批量上传图片、自动编号、封面设计，一键导出 PDF，轻松制作专业产品目录。

## 功能

- 多款预设布局（A4/A3 卡片、便签、相片风格）
- 批量上传与自动编号
- 封面、尾页、海报设计
- 导出 PDF / 导出项目 ZIP
- 中英双语

## 本地运行

**环境要求**：Node.js 18+

```bash
npm install
npm run dev
```

浏览器访问 http://localhost:3000

## 构建与部署

```bash
npm run build
```

产物位于 `dist/` 目录，可直接部署到静态服务器。生产构建可设置站点 URL：

```bash
# Windows PowerShell
$env:SITE_URL="https://your-domain.com"; npm run build

# Linux / macOS
SITE_URL=https://your-domain.com npm run build
```

## 项目结构

- `src/` - 源码
- `dist/` - 构建输出（部署用）
- `docs/` - 设计文档与规范
- `.cursor/rules/` - 代码与打包规范

---

*项目说明：本项目脱胎自某在线目录生成器原型，经改进后独立发布，可自行部署与二次开发。*
