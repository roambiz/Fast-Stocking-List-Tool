# 功能块与交互逻辑拆解

## 一、功能块总览

```
┌─────────────────────────────────────────────────────────────────────────────┐
│ TopNav: 主题 | 项目名 | 语言 | 使用指南 | 导出 PDF                              │
├──────────────┬───────────────────────────────────────┬──────────────────────┤
│ Sidebar      │ MainCanvas + Filmstrip                 │ CellEditor           │
│ 批量/预设/全局  │ 画布 + 页面缩略图                      │ 卡片/页面设置         │
└──────────────┴───────────────────────────────────────┴──────────────────────┘
```

---

## 二、独立功能块（无关联依赖）

| 功能块 | 位置 | 作用 | 关联 |
|--------|------|------|------|
| **使用指南** | TopNav | 打开 Modal 显示占位文案 | 无，仅 i18n |
| **语言切换** | TopNav | en/zh，写入 localStorage | 无，仅 i18n |
| **主题切换** | TopNav | blue/black，写入 settings 草稿 | 影响全 UI 配色 |
| **网格开关** | CanvasControls | showGrid | 仅 MainCanvas 背景 |
| **预览模式** | CanvasControls | previewMode | 隐藏 CellEditor、页面工具栏 |
| **缩放/适配** | CanvasControls | zoom, isFit | 仅 MainCanvas 缩放 |

---

## 三、依赖功能块与交互矩阵

### 3.1 预设与布局

| 操作 | 触发位置 | 画布变化 | 其它影响 |
|------|----------|----------|----------|
| 切换默认预设（A4/A3） | Sidebar 批量 → 填充目标上方的默认预设 | 若无内容：所有空标准页 + 封面 pageSize 统一迁移 | 有内容时：禁止切换，toast 提示 |
| 切换当前页布局 | Sidebar 预设 → 点击布局卡片 | 当前页 layoutId、pageSize 更新 | 仅同系列内可切换；有内容且跨系列则锁定 |
| 应用到全部页 | Sidebar 预设 →「将当前布局应用到全部页」 | 所有非封面页 layoutId 更新 | 有内容且跨系列页跳过 |
| 添加标准页 | Filmstrip「+页面」 | 新页插入，activePageId 指向新页 | 使用 defaultSeriesId |
| 添加封面 | Filmstrip「+封面」 | 新封面插入最前，activePageId 指向 | 使用 defaultSeriesId 的 pageSize；需先选 A4/A3 |

### 3.2 内容与选择

| 操作 | 触发位置 | 画布变化 | 其它影响 |
|------|----------|----------|----------|
| 点击页面 | MainCanvas / Filmstrip | activePageId 更新，selectedItemId 清空 | CellEditor 显示页面设置 |
| 点击产品卡片 | MainCanvas PageRenderer | activePageId、selectedItemId 更新 | CellEditor 显示卡片编辑 |
| 点击空白区域 | PageRenderer 容器 | 同上（选页） |  |
| 批量上传图片 | Sidebar 批量 → 上传 | 按目标填充/新建页，跳过封面 | 依赖 defaultSeriesId、autoNumbering |
| 应用编号 | Sidebar 批量 | 所有/当前页产品重新编号 | 「当前页面」需 activePageId |
| 批量填充 | Sidebar 批量 | 价格、角标、颜色写入 | 同上 |
| 批量清除 | Sidebar 批量 | 清除编号或文本 | 同上 |
| 编辑卡片 | CellEditor 卡片 tab | 更新对应 Item | 需 selectedItemId |
| 删除产品 | CellEditor 卡片 tab | Item 从 page 移除 | 若删除当前选中，selectedItemId 清空 |

### 3.3 页面操作

| 操作 | 触发位置 | 画布变化 | 其它影响 |
|------|----------|----------|----------|
| 上移/下移 | PageRenderer 工具栏 | 与相邻页交换顺序 |  |
| 删除页面 | PageRenderer / Filmstrip | 页移除，activePageId 回退 | 最后一页时新建默认页（已知 bug：固定 A4） |
| 清空内容 | PageRenderer 工具栏 | 当前页 items 清空 |  |
| 拖拽排序卡片 | PageRenderer（拖拽模式开启后） | items 重排 | 仅标准页 |
| 拖拽排序页面 | Filmstrip | pages 重排 |  |

### 3.4 封面与全局设置

| 操作 | 触发位置 | 画布变化 | 其它影响 |
|------|----------|----------|----------|
| 编辑封面 HTML | CellEditor 页面 tab | 封面档 htmlContent 更新 | 三档切换、格式化、复制等 |
| 页眉/页脚/Logo | Sidebar 全局 / CellEditor 页面 | globalConfig 更新，所有页重渲染 |  |
| 图片铺满/居中 | CellEditor 页面 / Sidebar 全局 | 单页或全局 imageFit |  |
| 显示槽位 | Sidebar 全局 | showEmptySlots | PageRenderer 渲染空槽 DashedBox |

### 3.5 重置与导出

| 操作 | 触发位置 | 画布变化 | 其它影响 |
|------|----------|----------|----------|
| 清空所有 | Sidebar 批量 | 全部重置，单页默认 | 需确认框 |
| 封面重置为默认 | CellEditor 页面 tab | 当前封面档恢复默认 HTML | 需确认框 |
| 导出 PDF | TopNav | 无，isExporting 期间禁用多数操作 | 节流、同步检查 |

---

## 四、切换/变体影响汇总

| 切换项 | 受影响的 UI / 逻辑 |
|--------|---------------------|
| defaultSeriesId (A4↔A3) | 空页迁移；有内容时禁止切换 |
| theme (blue↔black) | 全 UI 主题色、focus ring、按钮 variant 配色 |
| previewMode | CellEditor 隐藏、PageRenderer 工具栏隐藏 |
| showGrid | MainCanvas 背景网格 |
| activePageId | CellEditor 内容、Filmstrip 高亮、CanvasControls 的页操作 |
| selectedItemId | CellEditor 卡片 tab 显示编辑/空状态 |
| 布局变体 (同系列) | 当前页/多页 layoutId、pageSize、每页 maxItems |

---

## 五、导入导出与项目设置

见 [IMPORT_EXPORT.md](./IMPORT_EXPORT.md)。

---

## 六、今日工作小结 / 明日计划

| 今日 | 捉虫计划编写、Sidebar 上传错误处理、Modal 高度修复、功能块文档 |
|------|----------------------------------------------------------------|
| 明日 | **主要：完善使用指南内容**；其它：按需修 PRESET 相关 bug、翻译校对 |
