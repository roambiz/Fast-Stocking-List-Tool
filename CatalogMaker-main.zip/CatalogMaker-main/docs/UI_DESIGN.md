# 目录生成器 - UI 设计规范

## 1. 布局结构

### 1.1 整体布局

```
┌─────────────────────────────────────────────────────────────────────────────────────────────┐
│  TopNav (h-16)                                                                               │
│  主题切换 | 项目名 | Export PDF                                                              │
├──────────────┬─────────────────────────────────────────────────────┬─────────────────────────┤
│   Sidebar    │              MainCanvas (flex-1)                     │      CellEditor        │
│   (w-80)     │                                                      │       (w-80)           │
│   320px      │   Zoom / Pan  controls                              │       320px            │
│              │                                                      │                        │
│  左：批量    │   页 面 预 览 区                                      │  右：卡片/页面设置      │
│  预设       │                                                      │  选中项编辑或 HTML     │
│  全局       │                                                      │                        │
│              │                                                      │                        │
├──────────────┴─────────────────────────────────────────────────────┴─────────────────────────┤
│  Filmstrip (h-32)                                                                             │
│  页面缩略图 | New | 添加封面                                                                   │
└─────────────────────────────────────────────────────────────────────────────────────────────┘
```

### 1.2 区域职责

| 区域 | 职责 | 固定宽度 |
|------|------|----------|
| TopNav | 项目名、主题、导出 | 全宽 |
| Sidebar | 批量处理、预设方案、全局设置 | 320px (w-80) |
| MainCanvas | 画布、缩放、平移、页面渲染 | flex-1 |
| CellEditor | 卡片/页面编辑、封面 HTML | 320px (w-80) |
| Filmstrip | 页面列表、新建、封面 | 全宽 |

---

## 2. 配色与主题

### 2.1 主题体系

| 主题 | 主色 | 辅助色 | 用途 |
|------|------|--------|------|
| blue | blue-600 / blue-500 | blue-50, blue-100 | 默认亮色主题 |
| black | zinc-900 / zinc-800 | zinc-100, zinc-200 | 暗色主题 |

**一致性要求**：所有交互元素（按钮、边框、焦点环、选中态）需同时支持 blue 和 black 主题，避免硬编码单一蓝色。

### 2.2 语义色

| 用途 | 颜色 | 示例 |
|------|------|------|
| 成功 / 确认 | green-600 | 完成、通过 |
| 警告 | amber-500 / amber-600 | 锁定提示、注意事项 |
| 错误 / 危险 | red-500 / red-600 | 删除、错误信息 |
| 中性 | gray-500 / gray-600 | 次要文字、占位 |

### 2.3 背景层次

| 层级 | 用途 | 类名 |
|------|------|------|
| 页面背景 | 画布外围 | bg-slate-200 |
| 面板背景 | Sidebar、CellEditor 内容区 | bg-gray-50 |
| 卡片背景 | 区块、输入区 | bg-white |
| 高亮 | 激活 tab、选中 | bg-blue-50 / bg-zinc-100 |

---

## 3. 组件规范

### 3.1 Tab 导航（Sidebar / CellEditor 顶部）

- 未选中：`text-gray-600 hover:bg-gray-100`
- 选中：`bg-white` + `border-b-2 border-b-{theme}` + `text-{theme}-600` 或 `text-zinc-900`
- 分隔：`border-r border-gray-200`

### 3.2 主按钮 (CTA)

- 默认：`bg-{theme}-600 text-white` + `hover:bg-{theme}-700`
- 禁用：`disabled:bg-gray-400` 或 `disabled:opacity-50 cursor-not-allowed`
- 图标 + 文案，适当 padding（如 `px-4 py-2`）

### 3.3 次要按钮

- 边框：`border border-gray-200` + `bg-white` + `hover:bg-gray-50`
- 或浅色填充：`bg-{theme}-50 text-{theme}-600 border-{theme}-200` + `hover:bg-{theme}-100`

### 3.4 选择器（填充目标、预设系列）

- 容器：`rounded-lg border border-gray-200 bg-gray-50 p-1`
- 选项：`py-1.5 text-xs font-medium rounded-md`
- 选中：`bg-white shadow-sm` + `text-{theme}-600` 或 `text-zinc-900`
- 未选中：`text-gray-600 hover:text-gray-900`

### 3.5 输入框

- 默认：`border border-gray-200 rounded-lg px-3 py-2 text-sm`
- 焦点：`focus:ring-2 focus:ring-{theme}-500 focus:border-transparent`
- 占位：`placeholder:text-gray-400`

### 3.6 区块标题

- 标题：`text-sm font-bold text-gray-900`
- 图标：18px，`text-{theme}-500` 或 `text-zinc-800`
- 底部分隔：`border-b border-gray-100 pb-3 mb-5`

---

## 4. 图标与字体

### 4.1 图标

- 使用 `lucide-react`，保持风格统一
- 常用尺寸：14 / 16 / 18 / 20 / 24

### 4.2 字体

- 正文：`Inter`（或项目配置的 sans）
- 代码 / 编号：`JetBrains Mono`（若需要）

---

## 5. 响应式与可访问性

### 5.1 当前

- 左中右布局为固定宽度，适合桌面端
- 暂不强制移动端适配

### 5.2 可访问性建议

- 按钮提供 `title` 或 `aria-label`
- 表单控件有 `label` 关联
- 焦点态清晰（`focus:ring-2`）

---

## 6. 待改进项（与体验文档联动）

| 项目 | 说明 |
|------|------|
| 批量上传按钮 | 改为 CTA 主色填充，增加拖拽区域，提升可见性 |
| 预设锁定提示 | 使用统一提示样式，避免重复 alert |
| 画布选中态 | ring 颜色随 theme 变化，避免硬编码 blue |
| 空状态 | 统一占位文案与图标风格 |
