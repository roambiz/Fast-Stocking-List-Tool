# 预设系列与添加页/封面 交互逻辑说明

本文档详细说明「批量处理」中的默认预设系列、添加页面、添加封面在**未上传内容时**的交互逻辑，以及是否存在 A3/A4 混用的 bug。

---

## 一、核心概念

### 1.1 默认预设系列（defaultSeriesId）

- **定义**：用户在「批量处理」标签页中选中的预设系列（A4 - 标准目录 / A3 - 横版目录）
- **存储位置**：`store.defaultSeriesId`，可选值 `'a4-standard'` | `'a3-standard'`
- **持久化**：会写入 `localStorage` 的 `catalogMaker:settings:v1` 草稿中，刷新页面后会恢复

### 1.2 内容锁定（hasAnyStandardItems）

- **定义**：是否存在**任意一页**标准页（非封面/尾页/海报）拥有至少 1 个产品项
- **判定**：`pages.some(p => (!p.type || p.type === 'standard') && p.items.length > 0)`
- **作用**：为 true 时，**不允许**切换默认预设系列，避免已有内容与另一系列布局不兼容

---

## 二、关键操作的数据来源

| 操作 | 数据来源 | 说明 |
|------|----------|------|
| **+页面**（addPage） | `state.defaultSeriesId` | 通过 `getDefaultLayoutForSeries(defaultSeriesId)` 取该系列第一个布局，新页使用该 layout 的 pageSize |
| **+封面**（addCover） | `state.defaultSeriesId` | 根据 seriesId 推导 pageSize：`a3-standard` → A3，其余 → A4 |
| **批量上传图片** | `defaultSeriesId` 参数（来自 Sidebar 传入的 `defaultSeriesId`） | 新建页、空页填充时使用此系列 |

---

## 三、未上传时的完整交互流程

### 3.1 场景：先选 A4 → 添加封面和页面 → 修改预设为 A3 → 再添加

**步骤 1**：用户选择 A4 预设  
- `defaultSeriesId = 'a4-standard'`

**步骤 2**：用户点击「+封面」  
- `addCover()` 读取 `state.defaultSeriesId`（A4）  
- 创建 A4 封面，插入到 pages 最前面  
- 结果：`[A4 封面, ...]`

**步骤 3**：用户点击「+页面」  
- `addPage()` 用 `getDefaultLayoutForSeries('a4-standard')`  
- 新建 A4 标准页  
- 结果：`[A4 封面, A4 标准页]`

**步骤 4**：用户切换默认预设为 A3  
- 调用 `setDefaultSeriesId('a3-standard')`  
- `hasAnyStandardItems = false`（标准页无内容）  
- 进入「全部空页可统一迁移」逻辑：
  - 空标准页 → `layoutId`、`pageSize` 均改为 A3 系列
  - 封面/尾页/海报 → 仅 `pageSize` 改为 A3（layoutId 保持 `cover-layout`）

**步骤 5**：迁移后状态  
- 结果：`[A3 封面, A3 标准页]` ✓ **无 A3/A4 混用**

**步骤 6**：用户再点击「+页面」  
- `addPage()` 读取 `state.defaultSeriesId`（A3）  
- 新建 A3 标准页 ✓

**步骤 7**：用户再点击「+封面」  
- `addCover()` 读取 `state.defaultSeriesId`（A3）  
- 创建 A3 封面 ✓

**结论**：在未上传场景下，上述流程**不会**产生 A3/A4 混用。

---

## 四、上传后为何无法切换系列

- 一旦任意标准页有 `items.length > 0`，`hasAnyStandardItems = true`
- 切换预设时，Sidebar 会拦截并 `showAlert(t('sidebar.alertCannotSwitchSeries'))`
- `setDefaultSeriesId` 即使被调用，也**只会**更新 `defaultSeriesId`，**不会**改动任何已有页面
- 因此上传内容后，系列无法切换，属于**设计行为**，而非 bug

---

## 五、潜在 Bug 与边界情况

### 5.1 【Bug】从草稿恢复时的首次页面

**现象**：刷新页面后，若草稿中 `defaultSeriesId = 'a3-standard'`，首屏会有一页是 A4。

**原因**：  
- 草稿只保存 `defaultSeriesId`、`globalConfig`、`theme`，**不保存 pages**
- 初始 `pages` 由 `getDefaultLayout()` 创建，该函数固定返回 A4 系列首布局
- 因此出现：`defaultSeriesId = A3`，但唯一一页是 A4

**复现**：  
1. 选 A3 → 添加封面+页面（或任意操作触发 `saveSettingsDraft`）  
2. 刷新页面  
3. 观察：批量处理显示 A3 选中，但 filmstrip 第一页为 A4

**影响**：若用户未发现，直接点「+页面」，会得到 A3 页，从而出现 `[A4 页, A3 页]` 的 A3/A4 混用。

---

### 5.2 【Bug】删除到最后一页时的默认页

**现象**：当删除到只剩一页时，该页会被替换为使用 `getDefaultLayout()` 创建的新页，即 A4，无视当前 `defaultSeriesId`。

**代码位置**：`store.ts` - `deletePage`  
```ts
pages: newPages.length > 0 ? newPages : [{ id: uuidv4(), layoutId: getDefaultLayout().id, pageSize: getDefaultLayout().pageSize, ... }]
```

**复现**：  
1. 选 A3，添加若干页，全部为 A3  
2. 逐页删除直到只剩一页  
3. 删除最后一页  
4. 结果：新建的「唯一页」为 A4，而 `defaultSeriesId` 仍是 A3

**影响**：出现单页 A4 + 预设显示 A3 的混用现象。

---

### 5.3 【设计一致】+封面 的启用条件

- `canAddCover = defaultSeriesId === 'a4-standard' || defaultSeriesId === 'a3-standard'`
- 若未来扩展其他系列（如占位用 `coming-soon`），且 `defaultSeriesId` 指向它们，+封面 会被禁用，并显示「请先在批量处理中选择 A4 或 A3 预设」

---

### 5.4 【无 Bug】批量上传时 defaultSeriesId 的传递

- Sidebar 调用 `addProducts(images, uploadTarget, autoNumbering, defaultSeriesId)`
- 新建页、空页统一布局时均使用传入的 `defaultSeriesId`
- 不会出现上传时用错系列的情况

---

## 六、总结表

| 场景 | 是否会出现 A3/A4 混用 | 说明 |
|------|----------------------|------|
| 选 A4 → 加封面+页 → 改 A3 → 再加 | ❌ 否 | `setDefaultSeriesId` 会迁移所有空页 |
| 选 A4 → 上传 → 改 A3 | — | 改 A3 被拦截，无法切换 |
| 刷新页面（草稿为 A3） | ⚠️ 可能 | 首页由 `getDefaultLayout()` 固定为 A4 |
| 删除到最后一页 | ⚠️ 可能 | 最后一页由 `getDefaultLayout()` 固定为 A4 |

**建议修复**：  
1. 初始化/恢复时：若 `defaultSeriesId` 来自草稿，首页应使用 `getDefaultLayoutForSeries(defaultSeriesId)` 而非 `getDefaultLayout()`  
2. `deletePage` 在「创建替代空页」时，应使用 `getDefaultLayoutForSeries(state.defaultSeriesId)` 而非 `getDefaultLayout()`
