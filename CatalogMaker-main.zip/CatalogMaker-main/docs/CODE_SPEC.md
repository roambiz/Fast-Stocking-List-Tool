# 目录生成器 - 代码修改规范

## 1. 目标

- 功能完整、逻辑清晰、易维护
- 清除冗余代码
- 修复已识别 Bug
- 提升性能与生产体验

---

## 2. Bug 修复清单

### 2.1 海报封面类型错误（高）

**文件**：`src/components/Filmstrip.tsx`

**问题**：`handleAddCover` 中 `type === 'poster'` 时错误传入 `'cover'`，导致海报页被创建为普通封面。

**修改**：

```tsx
// 修改前
addCoverPage(type === 'poster' ? 'cover' : type, pageSize);

// 修改后
addCoverPage(type, pageSize);
```

Store 的 `addCoverPage` 已支持 `'poster'` 类型，无需映射。

### 2.2 主题未应用到预设与画布（高）

**文件**：`src/presets/a4-standard.tsx`、`src/presets/a3-standard.tsx`、`src/components/PageRenderer.tsx`

**问题**：硬编码 `ring-blue-500`、`text-blue-600`、`hover:border-blue-300` 等，切换 black 主题时不一致。

**修改**：
- 预设的 `renderItem` 需接收 `theme` 参数，或通过 Context/Store 获取
- `SortableItemWrapper` 的 `ring-blue-500` 改为根据 theme 使用 `ring-blue-500` 或 `ring-zinc-800`
- `PageRenderer` 中 `ring-4 ring-blue-500` 改为 `ring-4 ring-{theme}-500`

**建议**：在 `GlobalConfig` 或 store 中提供 `theme`，在 preset 的 renderItem 中注入，或使用 CSS 变量统一管理。

### 2.3 PDF 导出尺寸（中）

**文件**：`src/components/TopNav.tsx`

**说明**：A4 为 210×297mm，A3  landscape 为 420×297mm。当前实现基本正确，建议在注释中明确尺寸，并处理混合 A4/A3 时每页单独设置 `addPage` 的 orientation。

### 2.4 小标题逻辑与布局 ID 耦合（中）

**文件**：`src/components/CellEditor.tsx`

**问题**：`layout?.id.includes('v3')` 依赖 ID 命名，不利于扩展。

**修改**：
- 在 `LayoutPreset` 中增加 `hasPageSubtitles?: boolean`
- 在 a3-v3 等需要小标题的 layout 上设置 `hasPageSubtitles: true`
- CellEditor 中改为：`layout?.hasPageSubtitles`

---

## 3. 冗余与清理

### 3.1 未使用导入

**文件**：`src/components/Sidebar.tsx`

移除未使用的：`Mail`、`Link as LinkIcon`（lucide-react）

### 3.2 cover-layout 占位

**说明**：封面页使用 `layoutId: 'cover-layout'`，preset 中无此定义，实际渲染依赖 `htmlContent`。建议：
- 在 `getLayoutById` 中对 `'cover-layout'` 返回占位或明确标记为 cover 专用，避免歧义；
- 或保持现状，在文档中说明 cover 不依赖 preset。

---

## 4. 逻辑完善

### 4.1 预设系列切换

**现状**：已有内容时锁定其他系列，同系列内可切换变体，符合需求。

**可选增强**：
- 锁定原因提示更清晰
- 提供「清空并切换系列」的二次确认

### 4.2 批量上传按钮

**现状**：样式偏弱，易被忽略。

**修改**（参考 `EXPERIENCE_OPTIMIZATION.md`）：
- 使用主色填充 CTA 样式（与「添加封面」等主操作一致）
- 可选：增加拖拽上传区域

### 4.3 编号「当前页面」语义

**现状**：`applyNumbering('current')` 仅对当前页编号，且从 `startNumber` 重新开始。

**修改**：在 UI 中增加说明文案，如「仅重编当前页，编号从起始值重新开始」。

### 4.4 无激活页时的降级

**现状**：`activePageId` 为空时，部分操作可能无效。

**修改**：在 `addProducts`、`applyNumbering`、`batchFill` 等使用 `activePageId` 的逻辑中，当 target 为 `'current'` 且 `activePageId` 为空时，自动 fallback 到第一页或给出提示。

---

## 5. 代码风格与结构

### 5.1 主题工具

建议抽取主题判断为工具或 hook，减少重复：

```ts
// utils/theme.ts 或 store 中
export const useThemeClasses = () => {
  const theme = useStore(s => s.theme);
  const isBlue = theme === 'blue';
  return {
    primary: isBlue ? 'blue' : 'zinc',
    ring: isBlue ? 'ring-blue-500' : 'ring-zinc-800',
    // ...
  };
};
```

### 5.2 预设渲染复用

A4/A3 各变体的 `renderItem` 存在大量重复（图片区、角标、编号、价格、imageFit 等）。可考虑：
- 抽取 `BaseProductCard` 或 `renderProductImage` 等公共函数；
- 通过参数区分胶囊/方块/边框等样式，减少重复代码。

### 5.3 类型安全

- 避免 `any`，如 `batchFill` 中的 `dataToFill: any`
- 为 `batchFill` 的 data 使用 `Partial<Item>` 或明确接口

---

## 6. 文件与目录规范

### 6.1 结构

```
src/
├── components/     # UI 组件
├── presets/       # 预设定义
├── store.ts       # 全局状态
├── types.ts       # 类型定义
├── utils/         # 工具函数（可新增）
└── main.tsx
```

### 6.2 命名

- 组件：PascalCase
- 文件：与组件名一致或 kebab-case
- 预设：`{series}-standard.tsx`（如 a4-standard, a3-standard）

### 6.3 导入顺序

1. React
2. 第三方库
3. 内部模块（store、presets、types）
4. 相对路径组件

---

## 7. 修改优先级建议

| 优先级 | 项 | 说明 |
|--------|----|------|
| P0 | 海报 type 传递 | 直接影响功能正确性 |
| P0 | 主题一致性 | 影响整体视觉一致 |
| P1 | 移除未使用导入 | 保持代码整洁 |
| P1 | `hasPageSubtitles` 替代 `includes('v3')` | 提高可维护性 |
| P1 | 批量上传按钮样式 | 提升核心流程体验 |
| P2 |  preset 渲染复用 | 减少重复，便于扩展 |
| P2 | 主题工具/hook | 统一主题处理 |
| P3 | cover-layout 说明 | 文档或代码注释 |
