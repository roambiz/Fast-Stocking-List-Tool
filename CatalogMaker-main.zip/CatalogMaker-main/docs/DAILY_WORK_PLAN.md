# CatalogMaker 今日/明日工作计划

## 今日已完成

- [x] 捉虫计划：`docs/BUG_HUNT_PLAN.md`
- [x] 功能块与交互文档：`docs/FEATURE_BLOCKS_AND_INTERACTIONS.md`
- [x] Bug 修复：草稿恢复首页使用 defaultSeriesId（Bug 5.1）
- [x] Bug 修复：Sidebar 批量上传 try-catch 与 toast（先前已完成）
- [x] 翻译校对：`docs/TRANSLATION_REVIEW.md`（无缺失，建议微调 alertCannotSwitchOtherSeries）
- [x] Lint + build 通过

---

## 明日主任务：完善使用指南

1. **撰写使用指南正文**
   - 位置：TopNav 中「使用指南」按钮打开的 Modal 内容
   - 当前：`topNav.userGuidePlaceholder` 占位文案
   - 建议结构：
     - 快速开始（新建 → 选预设 → 上传 → 导出）
     - 预设与布局（A4/A3 系列、变体切换、锁定规则）
     - 全局设置（页眉页脚、Logo、联系方式、自动编号）
     - 批量与单卡编辑（填充目标、编号、多用途填充、卡片编辑）
     - 封面与 HTML（三档切换、AI 提示语、格式化）
     - 导入导出（设置/项目/ZIP、PDF 导出）
   - 可复用：`docs/WORKFLOW.md`、`docs/FEATURE_BLOCKS_AND_INTERACTIONS.md`

2. **可选收尾**
   - 若 `alertCannotSwitchOtherSeries` 需统一风格，可微调 en.json
   - 按 BUG_HUNT_PLAN 做一轮手动回归测试

---

## 参考文档

| 文档 | 用途 |
|------|------|
| `docs/WORKFLOW.md` | 核心工作流、典型场景 |
| `docs/PRESET_SERIES_LOGIC.md` | 预设与添加页逻辑 |
| `docs/FEATURE_BLOCKS_AND_INTERACTIONS.md` | 功能块与交互矩阵 |
| `docs/BUG_HUNT_PLAN.md` | 捉虫清单与回归项 |
| `docs/IMPORT_EXPORT.md` | 导入导出说明 |
