# CatalogMaker 发布前最终检测计划

版本：v1.2.1（发布前请按需更新本清单与文件列表）  
检测日期：2026-03-27

---

## 1. 必要检查项目 + 改动删减确认 + 功能关联同步

### 1.1 本次改动文件清单（19 个已修改）

| 文件 | 改动概要 |
|------|----------|
| `src/App.tsx` | 导出遮罩、无障碍标签 |
| `src/components/CanvasControls.tsx` | 备份菜单、导出限频、PIXEL_RATIO |
| `src/components/CellEditor.tsx` | 图片旋转/恢复/下载、Tab 卡片/页面、封面 HTML 编辑器、HintCard |
| `src/components/Filmstrip.tsx` | 小改动 |
| `src/components/MainCanvas.tsx` | 小改动 |
| `src/components/PageRenderer.tsx` | 空槽位、拖拽模式、headerFooterStyle |
| `src/components/Sidebar.tsx` | TabBar、HintCard 封面模式、导出优化、校验逻辑 |
| `src/components/TopNav.tsx` | 用户指南、Compass 入口、PIXEL_RATIO |
| `src/components/ui/IconButton.tsx` | variant、ariaLabel |
| `src/components/ui/index.ts` | 导出 HintCard |
| `src/locales/en.json` | 新增/调整文案 |
| `src/locales/zh.json` | 新增/调整文案 |
| `src/store.ts` | isExporting、clearAll、addProducts 逻辑 |
| `src/types.ts` | 类型扩展 |
| `src/utils/exportZip.ts` | PIXEL_RATIO、压缩配置 |
| `src/utils/importProject.ts` | 封面 HTML 三档、迁移逻辑 |

### 1.2 新增文件

| 文件 | 用途 |
|------|------|
| `src/components/ui/HintCard.tsx` | 空状态提示（未选卡片、封面模式） |
| `src/components/ui/TabBar.tsx` | 侧边栏/编辑区 Tab 切换 |
| `src/utils/exportImageConfig.ts` | PIXEL_RATIO 统一配置 |
| `src/utils/imageRotate.ts` | 图片旋转（Canvas 实现） |

### 1.3 功能关联检查

- [ ] **CellEditor**：旋转/恢复/下载 依赖 `imageRotate`、`imageOriginal`；未选卡片时显示 HintCard
- [ ] **Sidebar**：封面页选中时显示 HintCard，不显示批量/预设/全局 Tab
- [ ] **TopNav**：导出 PDF 使用 `PIXEL_RATIO`；用户指南入口
- [ ] **CanvasControls**：导出 ZIP/单页 JPG 使用 `PIXEL_RATIO`、`exportImageConfig`
- [ ] **exportZip**：使用 `PIXEL_RATIO`、`pdfCompressionEnabled`、`pdfJpegQuality`
- [ ] **importProject**：封面三档 `htmlContentSlots`、`htmlContentActiveSlot` 正确迁移

### 1.4 改动删减确认

- [ ] 无遗留的调试代码（console.log、debugger 等）
- [ ] 移除调试/测试用 console 输出：`console.error` 等仅用于排错的控制台输出（如 TopNav 导出 PDF、CanvasControls 导出 JPG/ZIP 的 catch 中），用户已有 toast 提示
- [ ] 关闭第三方推广输出：i18n 设置 `showSupportNotice: false`（关闭 i18next Locize 控制台消息）
- [ ] 无未使用的 import
- [ ] 无注释掉的废弃逻辑需恢复

---

## 2. 冗余代码与语法检查

### 2.1 已验证

- [x] **TypeScript 检查**：`npm run lint` 通过（tsc --noEmit）
- [x] **构建**：`npm run build` 成功

### 2.2 建议复查

- [ ] `Sidebar.tsx` 中 `SegmentedControl` 的 `label={t('sidebar.fillTarget')}` 在多个 Tab 下复用，确认语义正确
- [x] `store.ts` 新建页显式设置 `type: 'standard'`（已修复：deletePage fallback、addProducts 2 处、clearAll、初始 state 共 5 处）

### 2.3 潜在重复

- [x] `imageProcess` 构建警告（已修复：Sidebar 改为静态 import，消除动态+静态混用）

---

## 3. 安全问题

### 3.1 已确认

- [x] **封面 HTML 渲染**：`PageRenderer` 使用 `sanitizeCoverHtml`（DOMPurify），白名单标签和属性
- [x] **用户输入**：number、price、badge 有 `maxLength` 限制；batchFill 有 `BATCH_FILL_MAX_LENGTH`
- [x] **导出限频**：`exportThrottle` 10 分钟内最多 15 次 PDF/ZIP

### 3.2 建议复查

- [ ] 封面 HTML 允许的 `href`、`src` 是否为外部 URL，确认无 `javascript:` 等危险协议（DOMPurify 默认会过滤）
- [ ] `mailto:`、`https://wa.me/` 等链接由用户配置，需确认无 XSS 注入点

---

## 4. 文案校对与翻译校对

### 4.1 结构一致性

- [ ] `en.json` 与 `zh.json` 的 key 一一对应（建议用脚本或手工 diff 校验）
- [ ] `aiPromptTemplate` 等长文案在两种语言下含义一致

### 4.2 重点文案

- [ ] `cellEditor.coverSlot1/2/3`：中文为「档1/档2/档3」，英文为「1/2/3」，语义是否足够清晰
- [ ] `guideFeaturesEditorCard`：描述旋转、恢复、下载等新功能
- [ ] `importExport.*`：导入/导出提示完整且无错别字

### 4.3 占位符

- [ ] `aiPromptTemplate` 中 `{{pageSize}}` 在 i18n 中正确插值

---

## 5. 打包 dist/ 准备部署

### 5.1 构建命令

```bash
# 生产环境建议设置 SITE_URL
SITE_URL=https://catalog-maker.roambiz.com npm run build
```

### 5.2 构建产物检查

- [ ] `dist/index.html`：title、description、canonical、og:*、twitter:*
- [ ] `dist/.htaccess`：SPA 路由、缓存、安全头
- [ ] `dist/robots.txt`：Sitemap 指向正确
- [ ] `dist/sitemap.xml`：URL、lastmod 正确
- [ ] `dist/ai.txt`：产品名、功能、请勿滥用说明
- [ ] `dist/config.json`：name、version、buildTime

### 5.3 部署禁止项（build-packaging 规则）

- [ ] 无第三方 AI 平台名称或链接
- [ ] 无大型语言模型 API 品牌引用
- [ ] 字体使用非 Google 源（如 Bunny Fonts）

---

## 6. 更新至 GitHub

### 6.1 提交前

- [ ] 本地 `npm run lint` 通过
- [ ] 本地 `npm run build` 通过
- [ ] `package.json` 中 `version` 为 `1.1.0`（或目标版本）

### 6.2 提交建议

```bash
git add .
git status   # 确认无多余文件（如 node_modules、.env）
git commit -m "CatalogMaker v1.1.0 - [更新摘要]"
git push origin main
```

### 6.3 dist/ 是否纳入版本控制

- [ ] 若项目通过 GitHub Actions 等 CI 构建部署，则通常不提交 `dist/`
- [ ] 若需手动部署，可选择性提交 `dist/` 或配置 `.gitignore` 排除

### 6.4 Git 打 tag（稳定版）

- [ ] 提交后执行：`git tag v1.1.0`，`git push origin v1.1.0`

### 6.5 发布说明

- [ ] 在 GitHub 创建 Release，标签选 `v1.1.0`
- [ ] 标题：**CatalogMaker v1.1.0 稳定版**
- [ ] 正文：简述稳定版特性与使用说明

---

## 7. 补充检查项

### 7.1 浏览器兼容性

- [ ] Chrome / Edge 最新版
- [ ] 如支持 Safari/Firefox，做一次基础功能验证

### 7.2 导出流程

- [ ] 导出 PDF：多页、封面页、A3/A4 混排
- [ ] 导出 ZIP：包含 settings.json、project.json、所有 page_*.jpg
- [ ] 导出单页 JPG：选中页正确导出
- [ ] 导入设置 / 导入项目：旧版本项目可正常迁移

### 7.3 关键交互

- [ ] 图片旋转、恢复原图、下载图片
- [ ] 封面三档切换、HTML 编辑、格式化/复制/撤销
- [ ] 用户指南弹窗、Tab 切换
- [ ] 预览/编辑模式、画布缩放、拖拽排序

### 7.4 行尾与路径

- [ ] Git 提示 CRLF 替换时，确认团队约定（可配置 `.gitattributes`）
- [ ] 路径统一使用 `/`，避免 `src\` 与 `src/` 混用带来的歧义

### 7.5 调试/测试用冗余代码（控制台洁净）

| 类别 | 说明 | 涉及文件 |
|------|------|----------|
| 第三方推广 | i18n `showSupportNotice: false` 关闭 i18next Locize 消息 | `src/i18n.ts` |
| 调试用 console | catch 中 `console.error`，用户已有 toast，可移除 | `TopNav.tsx`（导出 PDF）、`CanvasControls.tsx`（导出 JPG/ZIP） |
| 注意 | 仅移除「仅用于调试/测试 bug」的输出，不移除业务必需的错误处理逻辑 | - |

### 7.6 生产环境控制台复查

- [ ] 部署后打开线上站点，检查控制台无多余报错、推广信息、调试输出

---

## 执行记录

| 步骤 | 执行人 | 日期 | 结果 |
|------|--------|------|------|
| 1 |  |  |  |
| 2 |  |  |  |
| 3 |  |  |  |
| 4 |  |  |  |
| 5 |  |  |  |
| 6 |  |  |  |
| 7 |  |  |  |
