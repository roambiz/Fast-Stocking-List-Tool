# CatalogMaker 捉虫计划

## 一、重构后潜在 Bug 清单

### 1.1 已修复

| Bug | 位置 | 修复 |
|-----|------|------|
| 封面 HTML 展开窗口变小 | Modal 使用 maxHeight 导致内容收缩 | 增加 `height` 属性，封面模态用固定 `height="85vh"` |
| 批量上传图片读取失败无提示 | Sidebar `handleFileUpload` 无 try-catch | 添加 try-catch，失败时 `showToast(toastImageUploadFailed)` |

### 1.2 待验证（回归测试）

| 场景 | 检查点 |
|------|--------|
| 上传图片 → 产品卡片显示 | 批量上传、单卡片替换图片，验证 base64 正常渲染 |
| 封面 HTML 编辑 | 展开/收起、格式化、复制、撤销、清空、重置为默认、确认框 |
| 清空所有 / 重置为默认 | 红色按钮样式一致，点击后均弹出确认框 |
| 主题切换 | 蓝/黑主题下，PrimaryButton/SecondaryButton/IconButton 颜色正确 |
| 预览模式 | 隐藏 CellEditor、隐藏页面工具栏，画布正常 |
| 网格开关 | MainCanvas 背景显示/隐藏网格 |
| Modal 弹窗 | 封面 HTML 展开、使用指南，ESC 关闭、遮罩点击（指南可关、封面不可关） |
| DashedBox | 未选卡片空状态、空白产品槽位，布局正常 |
| IconButton | PageRenderer 工具栏（上移、下移、清空、删除）、TopNav 关闭指南 |

### 1.3 已知 Bug（来自 PRESET_SERIES_LOGIC）

| Bug | 描述 | 状态 |
|-----|------|------|
| 草稿恢复首页 A4 | 刷新后若 defaultSeriesId=A3，首页仍为 A4（getDefaultLayout 固定） | ✓ 已修复：初始化时用 getDefaultLayoutForSeries(draft?.defaultSeriesId) |
| 删除到最后一页 | 唯一页被替换时用 getDefaultLayout() 固定 A4 | ✓ 已实现：deletePage 已使用 getDefaultLayoutForSeries(state.defaultSeriesId) |

### 1.4 漏斗与边界

| 漏斗 | 说明 | 建议 |
|------|------|------|
| 无 activePageId 时「当前页面」操作 | applyNumbering/batchFill/batchClear 选「当前页面」会 toast 提示 | 已处理 |
| selectedItemId 指向已删除项 | findItemInPages 返回 null，CellEditor 显示「选择卡片」 | 已处理 |
| isExporting 期间操作 | store 内多数 mutation 会 return 原 state | 已处理 |
| 50 页上限 | addPage/addProducts 超限会 toast | 已处理 |
| HTML 超 50KB | updatePageHtml 会 toast | 已处理 |
| 导出节流 | exportThrottle 限制 10 分钟内 15 次 | 已处理 |

---

## 二、检查工作流

1. **语法**：`npm run lint`
2. **构建**：`npm run build`
3. **手动回归**：按「待验证」清单逐项操作
4. **翻译**：对比 zh.json / en.json，检查缺失或错译

---

## 三、修复优先级

1. 高：影响核心流程（上传、编辑、导出）
2. 中：已知 PRESET 相关 bug（5.1、5.2）
3. 低：文案、样式微调
