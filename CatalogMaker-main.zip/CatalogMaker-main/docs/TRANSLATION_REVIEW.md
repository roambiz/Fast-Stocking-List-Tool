# 翻译校对记录

## 校对说明

逐键对比 zh.json 与 en.json，检查：
- 缺失键
- 不一致/错译
- 建议改进

---

## 校对结果（按模块）

### common
| 键 | 中文 | 英文 | 备注 |
|----|------|------|------|
| confirm | 确定 | OK | ✓ |
| cancel | 取消 | Cancel | ✓ |
| exportThrottled | 导出过于频繁... | Export rate limited... | ✓ |
| exportingLocked | 正在导出... | Exporting, please wait | ✓ |
| noImage | 暂无图片 | No image | ✓ |

### sidebar
| 键 | 中文 | 英文 | 备注 |
|----|------|------|------|
| alertCannotSwitchOtherSeries | 页面已有内容，不能切换到其他预设系列 | Clear page to switch preset | ⚠ 英意略简，可考虑 "Page has content, cannot switch preset" 更贴近中文 |
| toastImageUploadFailed | 部分图片读取失败... | Some images failed to load... | ✓ |
| 其余 | — | — | 一一对应，无缺失 |

### cellEditor
| 键 | 中文 | 英文 | 备注 |
|----|------|------|------|
| coverSlot1/2/3 | 档1/档2/档3 | 1/2/3 | ✓ 英文简化为数字 |
| imageFitCover | 铺满 | Cover | ✓ |
| imageFitContain | 居中 | Contain | ✓ |

### layouts
| 键 | 中文 | 英文 | 备注 |
|----|------|------|------|
| a4V2Name | 便签风格 | Sticky | ✓ |
| a3V1Name | 卖点风格 | Selling points | ✓ |
| a3V2Name | 参数风格 | Parameters | ✓ |
| a3V3Name | 亮点风格 | Highlights | ✓ |

### 缺失键检查
- 无缺失：zh 与 en 的 top-level 键及子键一一对应。

### 建议
1. `sidebar.alertCannotSwitchOtherSeries` 英译可统一为 "Page has content, cannot switch preset" 与 `alertCannotSwitchSeries` 风格一致（如需要）。
2. 其余翻译无明显错误。

---

## 结论

- **结构**：两语言键完全对应，无缺失。
- **内容**：仅 `alertCannotSwitchOtherSeries` 英译略简，可酌情微调。
- **状态**：通过 ✓
