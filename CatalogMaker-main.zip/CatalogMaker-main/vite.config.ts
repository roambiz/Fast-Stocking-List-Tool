import tailwindcss from '@tailwindcss/vite';
import react from '@vitejs/plugin-react';
import path from 'path';
import { readFileSync } from 'fs';
import { defineConfig, loadEnv } from 'vite';
import { runPostBuild } from './scripts/post-build.ts';

function getVersion(): string {
  const pkg = JSON.parse(readFileSync(path.resolve(__dirname, 'package.json'), 'utf-8'));
  return (pkg.version ?? '0.0.0').replace(/\./g, '-');
}

export default defineConfig(({ mode }) => {
  const env = loadEnv(mode, '.', '');
  const version = getVersion();
  return {
    build: {
      rollupOptions: {
        output: {
          chunkFileNames: `assets/catalogmaker-v${version}-[name]-[hash].js`,
          assetFileNames: `assets/catalogmaker-v${version}-[name]-[hash][extname]`,
          entryFileNames: `assets/catalogmaker-v${version}-[name]-[hash].js`,
          manualChunks(id) {
            if (id.includes('node_modules/react/') || id.includes('node_modules/react-dom/')) {
              return 'vendor-react';
            }
            if (id.includes('lucide-react') || id.includes('clsx') || id.includes('tailwind-merge')) {
              return 'vendor-ui';
            }
            if (id.includes('jspdf') || id.includes('html-to-image') || id.includes('jszip')) {
              return 'vendor-export';
            }
            if (id.includes('@dnd-kit')) {
              return 'vendor-dnd';
            }
            if (id.includes('i18next') || id.includes('react-i18next')) {
              return 'vendor-i18n';
            }
          },
        },
      },
    },
    plugins: [
      react(),
      tailwindcss(),
      {
        name: 'catalogmaker-post-build',
        closeBundle() {
          runPostBuild({ siteUrl: env.SITE_URL });
        },
      },
    ],
    define: {},
    resolve: {
      alias: {
        '@': path.resolve(__dirname, '.'),
      },
    },
    server: {
      hmr: process.env.DISABLE_HMR !== 'true',
    },
  };
});
