---
name: PDF 元数据 1.2
overview: 全局「检索优化」+ PDF setProperties；defaultGlobalConfig/clearAll 对齐；emailFormat 与 Sidebar 共用；导出侧 trim/截断/净化；Producer 固定；注入关闭时不写四项；i18n 键清单、测试矩阵、指南与 v1.2.0 发布。
todos:
  - id: types-store
    content: GlobalConfig + defaultGlobalConfig + migrate 可选 boolean 规范化
    status: pending
  - id: email-util
    content: emailFormat.ts 与 Sidebar validateEmail 共用
    status: pending
  - id: pdf-metadata-util
    content: pdfMetadata.ts（sanitize + applyPdfDocumentMetadata）+ TopNav
    status: pending
  - id: sidebar-ui
    content: 检索优化 Panel、FormField、maxLength、a11y
    status: pending
  - id: i18n-guide
    content: 按 §4 键表更新 zh/en + 指南 + 澄清仅 PDF
    status: pending
  - id: release
    content: lint/build、§7 测试矩阵、RELEASE_CHECKLIST、1.2.0 打包与 GitHub
    status: pending
isProject: true
---

# PDF 检索优化（元数据注入）与 v1.2 发布计划

> 与 `C:\Users\Administrator\.cursor\plans\pdf_元数据_1.2_957e7ca8.plan.md` 同步；以仓库内本文件为准参与协作。

## 1. 数据模型与默认值

在 [`src/types.ts`](src/types.ts) 的 `GlobalConfig` 中新增字段（均可选；旧 JSON 无此键即兼容）：

| 字段 | 类型 | 含义 |
|------|------|------|
| `pdfMetadataInjectionEnabled` | `boolean` | 默认 `false`：未勾选时仅注入 Creator + Producer（见 §2） |
| `pdfMetadataTitle` | `string \| undefined` | 用户填写的 PDF 标题 |
| `pdfMetadataSubject` | `string \| undefined` | PDF Subject（主题/说明） |
| `pdfMetadataAuthor` | `string \| undefined` | PDF Author（机构名等） |
| `pdfMetadataKeywords` | `string \| undefined` | PDF Keywords |

**代码内常量（不写进用户 JSON）：**

| 常量 | 值 | 说明 |
|------|-----|------|
| Creator | `https://roambiz.com/` | 固定 |
| Producer | **`CatalogMaker x.y.z`**（`x.y.z` = [`package.json`](package.json) `version`） | 固定一种：带版本便于支持排查 |

[`src/store.ts`](src/store.ts)：`defaultGlobalConfig` 须含 `pdfMetadataInjectionEnabled: false` 与四字符串字段 **`''`**。`clearAll` 使用整份 `defaultGlobalConfig`。

### 1.1 旧 JSON 与导入 / 新导出

- 浅合并；缺键 ⇒ `false` + 空串。
- **schemaVersion** 维持 `1`；新键可选。
- **可选**：`migrateGlobalConfig` 将 `pdfMetadataInjectionEnabled` 的字符串 `"true"`/`"false"` 规范为 boolean；异常类型 ⇒ `false`。
- 新导出可含新键；[`projectSchema.ts`](src/schema/projectSchema.ts) 或 docs 注释：`1.2+ optional: pdfMetadata*`。

### 1.2 Store / UI 对齐

| 场景 | 期望 |
|------|------|
| 新用户 / `clearAll` | `pdfMetadataInjectionEnabled === false`，四字段 `''` |
| 旧 JSON | 缺键合并后同上 |

---

## 2. 导出逻辑（[`TopNav.tsx`](src/components/TopNav.tsx)）

在 `pdf.output('blob')` **之前**调用 `applyPdfDocumentMetadata`。

### 2.1 注入开关

| `pdfMetadataInjectionEnabled` | 行为 |
|-------------------------------|------|
| **非 `true`** | **仅** `creator`、`producer`；**不**传 title/subject/author/keywords（避免空串；若库有残留默认行为需实测） |
| **`true`** | §2.3 净化后按 §2.2 §2.4 写入 |

### 2.2 优先级

| 字段 | 规则 |
|------|------|
| 标题 | 净化后非空 ⇒ 用户值；否则 §2.4 默认 `Product Catalog YYYY-MM-DD` |
| 作者 | 净化后非空 ⇒ **仅用户值**；为空 ⇒ 邮箱回退（`isValidEmailFormat`） |
| 主题/关键词 | 净化后非空才写入 |

### 2.3 `sanitizePdfMetadataString(s, maxLen)`

trim；`\r`/`\n` → 空格；可选压缩连续空白；按 `maxLen` 截断。

### 2.4 注入开启且字段净化后为空

| 字段 | 行为 |
|------|------|
| 标题 | 默认英文 + 本地日期 |
| 作者 | 邮箱有效则写入；否则省略 |
| 主题/关键词 | 不注入 |

---

## 3. UI（[`Sidebar.tsx`](src/components/Sidebar.tsx)）

品牌标志 Panel 后新增「检索优化」Panel；Toggle + 四字段；`maxLength`：128 / 256 / 128 / 512；占位符见 §4；a11y 与现有 FormField 一致。

---

## 4. i18n 键清单

见主计划文件 §4（`sidebar.searchOptimization`、`sidebar.pdfMetadataInjection`、`sidebar.pdfMetadata*` label/placeholder、`sidebar.pdfMetadataHint`、指南 v1.2.0、**仅 PDF 含文件属性**）。

---

## 5. 手动测试矩阵

见主计划 §5（未勾选、全空+邮箱、仅关键词、空格标题、中文、旧 JSON、关注入后导出）。

---

## 6–8. 版本、发布、数据流、风险

见主计划 §6–§9。
